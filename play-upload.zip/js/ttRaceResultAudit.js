import { parseTournamentPortalXml, validateTournamentPortal } from "./clicktt.js";
import { createTournamentStateFromClickttPortal } from "./clickttBridge.js";
import { normalizeTtRaceTournament, validateTableTennisSetScores } from "./ttRace.js";

const DEFAULT_EXPECTED_ROUNDS = 6;
const DEFAULT_SETS_TO_WIN = 3;
const SWISS_ROUND_LABEL = /^Schweizer System \(Runde (\d+)\)$/;
const RANK_PAIRING_COST_BASE = 100n;
const RANK_PAIRING_REMATCH_COST = 1_000_000_000_000_000n;
const RANK_PAIRING_REPEAT_BYE_COST = 1_000_000_000_000_000n;

export function auditTtRaceResultXml(xmlText, options = {}) {
  const portal = parseTournamentPortalXml(xmlText);
  const competition = selectCompetition(portal, options.competitionSelector);
  const issues = [];
  const warnings = [];

  addPortalValidationIssues(issues, validateTournamentPortal(portal));

  if (!competition) {
    issues.push(createFinding("missing-competition", "Die XML enthaelt keinen pruefbaren Wettbewerb."));
    return createAuditResult(portal, null, [], issues, warnings, options);
  }

  if (competition.matches.length === 0 && options.allowEmpty !== true) {
    issues.push(createFinding("missing-results", "Die XML enthaelt keine Ergebnis-Matches."));
  }

  const rounds = groupMatchesByRound(competition.matches);
  const playerById = new Map(competition.players.map((player) => [player.id, player]));
  const matchParticipantIds = collectMatchParticipantIds(competition.matches);
  const activePlayerIds = collectActivePlayerIds(competition, matchParticipantIds);
  const setsToWin = getSetsToWin(portal, competition);
  const auditState = createAuditState(activePlayerIds);

  auditCompetitionShape(issues, warnings, competition, rounds, activePlayerIds, options);
  auditRoundLabelsAndNumbers(issues, rounds, options);
  auditFirstRoundTtrSeeding(issues, warnings, rounds[0], activePlayerIds, playerById, options);

  rounds.forEach((round, roundIndex) => {
    auditRoundPairingAndScores(issues, warnings, round, roundIndex, auditState, playerById, setsToWin, options);
    rememberRoundResults(round, auditState);
  });

  auditFinalPlacements(issues, competition, portal, options);

  return createAuditResult(portal, competition, rounds, issues, warnings, options);
}

export function createTtRacePairingProofXml(xmlText, options = {}) {
  const auditOptions = {
    ...options,
    requireRankAwarePairing: options.requireRankAwarePairing ?? true
  };
  const audit = auditTtRaceResultXml(xmlText, auditOptions);
  const portal = parseTournamentPortalXml(xmlText);
  const competition = selectCompetition(portal, options.competitionSelector);

  if (!competition) {
    return {
      ok: false,
      audit,
      summary: audit.summary,
      checks: [createProofCheck("competition-present", false, "Die XML enthaelt keinen pruefbaren Wettbewerb.")],
      firstRoundTtr: null,
      rounds: []
    };
  }

  const rounds = groupMatchesByRound(competition.matches);
  const playerById = new Map(competition.players.map((player) => [player.id, player]));
  const matchParticipantIds = collectMatchParticipantIds(competition.matches);
  const activePlayerIds = collectActivePlayerIds(competition, matchParticipantIds);
  const setsToWin = getSetsToWin(portal, competition);
  const auditState = createAuditState(activePlayerIds);
  const firstRoundTtr = createFirstRoundTtrProof(rounds[0], activePlayerIds, playerById);
  const roundProofs = rounds.map((round, roundIndex) =>
    createRoundProof(round, roundIndex, auditState, playerById, setsToWin)
  );
  const checks = [
    createProofCheck("audit-ok", audit.ok, "Der harte TT-Race Ergebnis-Audit ist fehlerfrei.", {
      issues: audit.issues,
      warnings: audit.warnings
    }),
    createProofCheck("six-swiss-rounds", rounds.length === DEFAULT_EXPECTED_ROUNDS, "Es sind genau 6 Schweizer Runden vorhanden.", {
      rounds: rounds.length
    }),
    createProofCheck("first-round-ttr-seeding", firstRoundTtr?.ok === true, "Runde 1 paart gesetzte TTR-Spieler gegen den Gegnerpool.", firstRoundTtr),
    createProofCheck(
      "next-rounds-use-current-standings",
      roundProofs.slice(1).every((round) => round.scoreGroupPairingOptimal && round.rankAwarePairingOptimal),
      "Folgerunden werden aus dem Zwischenstand vor der Runde rekonstruiert und optimal nach Sieggruppen/Rangkosten gepaart.",
      {
        rounds: roundProofs.slice(1).map((round) => ({
          roundNumber: round.roundNumber,
          scoreGroupPairingOptimal: round.scoreGroupPairingOptimal,
          rankAwarePairingOptimal: round.rankAwarePairingOptimal,
          observedTopDownCost: round.observedTopDownCost,
          bestTopDownCost: round.bestTopDownCost,
          observedRankAwareCost: round.observedRankAwareCost,
          bestRankAwareCost: round.bestRankAwareCost
        }))
      }
    ),
    createProofCheck("no-rematches", roundProofs.every((round) => round.rematches.length === 0), "Keine Paarung kommt zweimal vor.", {
      rematches: roundProofs.flatMap((round) => round.rematches)
    }),
    createProofCheck("no-double-bookings", roundProofs.every((round) => round.doubleBookedPlayers.length === 0), "Kein Spieler ist in einer Runde doppelt angesetzt.", {
      doubleBookedPlayers: roundProofs.flatMap((round) => round.doubleBookedPlayers)
    }),
    createProofCheck("bye-rules-ok", roundProofs.every((round) => round.byeRuleOk), "Freilose passen zur Feldgroesse und wiederholen sich nicht, solange Alternativen existieren.", {
      byes: roundProofs.map((round) => ({ roundNumber: round.roundNumber, byes: round.byes }))
    }),
    createProofCheck("all-scores-valid", roundProofs.every((round) => round.matches.every((match) => match.score.valid)), "Alle exportierten Satzpunkte sind tischtennisgueltig.", {
      invalidMatches: roundProofs.flatMap((round) => round.matches.filter((match) => !match.score.valid))
    })
  ];

  return {
    ok: checks.every((check) => check.status === "pass"),
    audit,
    summary: {
      ...audit.summary,
      proofRounds: roundProofs.length,
      proofMatches: roundProofs.reduce((total, round) => total + round.matches.length, 0)
    },
    ruleBasis: [
      "Runde 1: TTR-staerkere Haelfte wird gesetzt; bei ungerader Feldgroesse liegt das Freilos auf dem TTT2020/Bavarian-Rasterplatz.",
      "Folgerunden: erst nach vollstaendiger Vorrunde sinnvoll; Paarung aus aktuellem Zwischenstand nach Sieggruppen und Rang-/Buchholz-Reihenfolge.",
      "Keine Wiederholungspaarungen und keine doppelten Freilose, solange andere Kandidaten ohne Freilos existieren.",
      "Satzpunkte muessen echte Tischtennissaetze bis 3 Gewinnsaetze bilden."
    ],
    checks,
    firstRoundTtr,
    rounds: roundProofs
  };
}

function createAuditResult(portal, competition, rounds, issues, warnings, options) {
  return {
    ok: issues.length === 0,
    issues,
    warnings,
    summary: {
      tournamentName: portal.tournament.name,
      competition: competition ? getCompetitionName(competition) : null,
      listedPlayers: competition?.players.length ?? 0,
      activePlayers: competition ? collectActivePlayerIds(competition, collectMatchParticipantIds(competition.matches)).size : 0,
      matches: competition?.matches.length ?? 0,
      rounds: rounds.length,
      strictTtrFirstRound: options.requireFirstRoundTtrSeeding !== false
    }
  };
}

function createFinding(code, message, details = {}) {
  return { code, message, details };
}

function createProofCheck(id, condition, evidence, details = {}) {
  return {
    id,
    status: condition ? "pass" : "fail",
    evidence,
    details
  };
}

function addPortalValidationIssues(issues, validationIssues) {
  validationIssues.forEach((issue) => {
    issues.push(
      createFinding("validation-issue", `click-TT Validator: ${issue.message}`, {
        code: issue.code,
        path: issue.path
      })
    );
  });
}

function selectCompetition(portal, selector) {
  if (typeof selector === "number") {
    return portal.competitions[selector] ?? null;
  }

  if (selector) {
    const byId = portal.competitions.find((competition) => competition.id === selector);
    if (byId) {
      return byId;
    }
  }

  return (
    portal.competitions.find((competition) => competition.matches.length > 0) ||
    portal.competitions.find((competition) => competition.players.length > 0) ||
    portal.competitions[0] ||
    null
  );
}

function getCompetitionName(competition) {
  return [competition.ageGroup, competition.type].filter(Boolean).join(" ") || competition.id || "Wettbewerb";
}

function collectMatchParticipantIds(matches) {
  const ids = new Set();

  matches.forEach((match) => {
    if (match.playerA) {
      ids.add(match.playerA);
    }

    if (match.playerB) {
      ids.add(match.playerB);
    }
  });

  return ids;
}

function collectActivePlayerIds(competition, matchParticipantIds) {
  const activeIds = new Set(matchParticipantIds);

  competition.players.forEach((player) => {
    if (toPositiveInteger(player.placement, null)) {
      activeIds.add(player.id);
    }
  });

  return activeIds;
}

function getSetsToWin(portal, competition) {
  return (
    toPositiveInteger(competition.attrs["winning-sets"], null) ||
    toPositiveInteger(portal.tournament.attrs["winning-sets"], null) ||
    DEFAULT_SETS_TO_WIN
  );
}

function toPositiveInteger(value, fallback) {
  const number = Number(value);
  return Number.isInteger(number) && number > 0 ? number : fallback;
}

function toFiniteNumber(value, fallback = null) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function groupMatchesByRound(matches) {
  const roundByLabel = new Map();
  const rounds = [];

  matches.forEach((match) => {
    const label = normalizeLabel(match.group) || "Ergebnisse";
    if (!roundByLabel.has(label)) {
      const parsedRoundNumber = parseSwissRoundNumber(label);
      const round = {
        index: rounds.length,
        label,
        parsedRoundNumber,
        matches: []
      };
      roundByLabel.set(label, round);
      rounds.push(round);
    }

    roundByLabel.get(label).matches.push(match);
  });

  return rounds;
}

function normalizeLabel(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function parseSwissRoundNumber(label) {
  const match = normalizeLabel(label).match(SWISS_ROUND_LABEL);
  return match ? Number(match[1]) : null;
}

function auditCompetitionShape(issues, warnings, competition, rounds, activePlayerIds, options) {
  const expectedRounds = toPositiveInteger(options.expectedRounds, DEFAULT_EXPECTED_ROUNDS);
  const playmode = normalizeLabel(competition.attrs["final-round-playmode"]);

  if (playmode && !/Schweizer System/i.test(playmode)) {
    warnings.push(
      createFinding("unexpected-playmode", "Der Wettbewerb ist nicht als Schweizer System markiert.", {
        finalRoundPlaymode: playmode
      })
    );
  }

  if (rounds.length !== expectedRounds) {
    issues.push(
      createFinding("round-count-mismatch", "Ein BTTV TT-Race im Schweizer System muss 6 Runden enthalten.", {
        expected: expectedRounds,
        actual: rounds.length
      })
    );
  }

  if (activePlayerIds.size >= 1 && (activePlayerIds.size < 9 || activePlayerIds.size > 16)) {
    issues.push(
      createFinding("invalid-swiss-field-size", "BTTV TT-Race im Schweizer System braucht 9 bis 16 aktive Teilnehmer.", {
        activePlayers: activePlayerIds.size
      })
    );
  }
}

function auditRoundLabelsAndNumbers(issues, rounds, options) {
  const expectedRounds = toPositiveInteger(options.expectedRounds, DEFAULT_EXPECTED_ROUNDS);
  const seenRoundNumbers = new Set();

  rounds.forEach((round, index) => {
    const expectedLabel = `Schweizer System (Runde ${index + 1})`;

    if (round.parsedRoundNumber === null) {
      issues.push(
        createFinding("invalid-round-label", "Ein Rundenlabel entspricht nicht dem TTT2020-Stil.", {
          label: round.label,
          expectedExample: "Schweizer System (Runde 1)"
        })
      );
    } else if (seenRoundNumbers.has(round.parsedRoundNumber)) {
      issues.push(
        createFinding("duplicate-round-label", "Eine Schweizer Runde kommt mehrfach vor.", {
          label: round.label,
          roundNumber: round.parsedRoundNumber
        })
      );
    }

    seenRoundNumbers.add(round.parsedRoundNumber);

    if (options.strictRoundLabels !== false && round.label !== expectedLabel) {
      issues.push(
        createFinding("round-label-sequence-mismatch", "Die Rundenlabels muessen fortlaufend im TTT2020-Stil stehen.", {
          expected: expectedLabel,
          actual: round.label
        })
      );
    }

    round.matches.forEach((match, matchIndex) => {
      if (Number(match.nr) !== matchIndex + 1) {
        issues.push(
          createFinding("per-round-match-number-mismatch", "TTT2020 nummeriert Spiele je Runde wieder ab 1.", {
            round: round.label,
            expected: matchIndex + 1,
            actual: match.nr
          })
        );
      }
    });
  });

  if (options.strictRoundLabels !== false) {
    for (let roundNumber = 1; roundNumber <= expectedRounds; roundNumber += 1) {
      if (!seenRoundNumbers.has(roundNumber)) {
        issues.push(
          createFinding("missing-round-label", "Eine erwartete Schweizer Runde fehlt.", {
            roundNumber
          })
        );
      }
    }
  }
}

function auditFirstRoundTtrSeeding(issues, warnings, firstRound, activePlayerIds, playerById, options) {
  if (!firstRound || options.requireFirstRoundTtrSeeding === false || activePlayerIds.size === 0) {
    return;
  }

  const ratings = new Map();
  const missingRatings = [];

  activePlayerIds.forEach((playerId) => {
    const rating = getPlayerRating(playerById.get(playerId));
    if (Number.isFinite(rating)) {
      ratings.set(playerId, rating);
    } else {
      missingRatings.push(playerId);
    }
  });

  if (missingRatings.length > 0) {
    issues.push(
      createFinding("missing-ttr-values", "Die TTR-Setzung der ersten Runde kann nicht vollstaendig geprueft werden.", {
        playerIds: missingRatings
      })
    );
    return;
  }

  const slotCount = activePlayerIds.size + (activePlayerIds.size % 2);
  const seededCount = slotCount / 2;
  const sortedByTtr = [...activePlayerIds].sort(
    (leftId, rightId) =>
      (ratings.get(rightId) ?? 0) - (ratings.get(leftId) ?? 0) ||
      getPlayerName(playerById.get(leftId)).localeCompare(getPlayerName(playerById.get(rightId)), "de") ||
      leftId.localeCompare(rightId)
  );
  const seededIds = new Set(sortedByTtr.slice(0, seededCount));
  const firstRoundByes = inferRoundByes([...activePlayerIds], firstRound.matches);

  if (activePlayerIds.size % 2 === 0 && firstRoundByes.length > 0) {
    issues.push(
      createFinding("first-round-unexpected-bye", "Ein gerades TT-Race-Feld darf in Runde 1 kein Freilos haben.", {
        inferredByes: firstRoundByes
      })
    );
  }

  if (activePlayerIds.size % 2 === 1) {
    const expectedByePlayerId = sortedByTtr[seededCount - 1];

    if (firstRoundByes.length !== 1 || firstRoundByes[0] !== expectedByePlayerId) {
      issues.push(
        createFinding("first-round-ttr-bye-mismatch", "Bei ungerader Teilnehmerzahl muss im TTT2020/Bavarian-Raster der vorletzte gesetzte Platz das Freilos erhalten.", {
          expected: expectedByePlayerId,
          actual: firstRoundByes,
          seededPlayers: [...seededIds]
        })
      );
    }
  }

  firstRound.matches.forEach((match) => {
    const leftSeeded = seededIds.has(match.playerA);
    const rightSeeded = seededIds.has(match.playerB);

    if (leftSeeded === rightSeeded) {
      issues.push(
        createFinding("first-round-ttr-seeding-mismatch", "Runde 1 muss gesetzte TTR-Spieler gegen ungesetzte Spieler paaren.", {
          match: describeMatch(match),
          seededPlayers: [...seededIds]
        })
      );
    }
  });
}

function createFirstRoundTtrProof(firstRound, activePlayerIds, playerById) {
  if (!firstRound || activePlayerIds.size === 0) {
    return {
      ok: false,
      status: "missing-first-round",
      activePlayers: activePlayerIds.size,
      matches: []
    };
  }

  const ratings = new Map();
  const missingRatings = [];

  activePlayerIds.forEach((playerId) => {
    const rating = getPlayerRating(playerById.get(playerId));
    if (Number.isFinite(rating)) {
      ratings.set(playerId, rating);
    } else {
      missingRatings.push(playerId);
    }
  });

  const slotCount = activePlayerIds.size + (activePlayerIds.size % 2);
  const seededCount = slotCount / 2;
  const sortedByTtr = [...activePlayerIds].sort(
    (leftId, rightId) =>
      (ratings.get(rightId) ?? 0) - (ratings.get(leftId) ?? 0) ||
      getPlayerName(playerById.get(leftId)).localeCompare(getPlayerName(playerById.get(rightId)), "de") ||
      leftId.localeCompare(rightId)
  );
  const seededPlayerIds = sortedByTtr.slice(0, seededCount);
  const drawPoolPlayerIds = sortedByTtr.slice(seededCount);
  const seededIds = new Set(seededPlayerIds);
  const firstRoundByes = inferRoundByes([...activePlayerIds], firstRound.matches);
  const expectedByePlayerId = activePlayerIds.size % 2 === 1 ? sortedByTtr[seededCount - 1] : "";
  const byeOk =
    activePlayerIds.size % 2 === 0
      ? firstRoundByes.length === 0
      : firstRoundByes.length === 1 && firstRoundByes[0] === expectedByePlayerId;
  const matches = firstRound.matches.map((match) => {
    const playerASeeded = seededIds.has(match.playerA);
    const playerBSeeded = seededIds.has(match.playerB);

    return {
      nr: match.nr,
      playerA: describeProofPlayer(playerById, null, match.playerA),
      playerB: describeProofPlayer(playerById, null, match.playerB),
      playerASeeded,
      playerBSeeded,
      seededVsDrawPool: playerASeeded !== playerBSeeded
    };
  });

  return {
    ok: missingRatings.length === 0 && byeOk && matches.every((match) => match.seededVsDrawPool),
    status: "checked",
    activePlayers: activePlayerIds.size,
    slotCount,
    seededCount,
    seededPlayers: seededPlayerIds.map((playerId) => describeProofPlayer(playerById, null, playerId)),
    drawPoolPlayers: drawPoolPlayerIds.map((playerId) => describeProofPlayer(playerById, null, playerId)),
    expectedByePlayer: expectedByePlayerId ? describeProofPlayer(playerById, null, expectedByePlayerId) : null,
    inferredByes: firstRoundByes.map((playerId) => describeProofPlayer(playerById, null, playerId)),
    byeOk,
    missingRatings,
    matches
  };
}

function getPlayerRating(player) {
  return toFiniteNumber(player?.persons?.[0]?.attrs?.ttr, null);
}

function getPlayerName(player) {
  return player?.displayName || player?.id || "";
}

function createAuditState(activePlayerIds) {
  return {
    activePlayerIds: new Set(activePlayerIds),
    pointsById: new Map([...activePlayerIds].map((playerId) => [playerId, 0])),
    winsById: new Map([...activePlayerIds].map((playerId) => [playerId, 0])),
    headToHeadWinsById: new Map([...activePlayerIds].map((playerId) => [playerId, new Map()])),
    opponentIdsById: new Map([...activePlayerIds].map((playerId) => [playerId, []])),
    playedPairs: new Set(),
    byeCounts: new Map([...activePlayerIds].map((playerId) => [playerId, 0])),
    retiredBeforeRound: new Set()
  };
}

function auditRoundPairingAndScores(issues, warnings, round, roundIndex, auditState, playerById, setsToWin, options) {
  const eligibleIds = [...auditState.activePlayerIds].filter((playerId) => !auditState.retiredBeforeRound.has(playerId));
  const expectedMatches = Math.floor(eligibleIds.length / 2);
  const expectedByes = eligibleIds.length % 2;
  const participantCounts = new Map();
  const inferredByes = inferRoundByes(eligibleIds, round.matches);

  if (round.matches.length !== expectedMatches) {
    issues.push(
      createFinding("round-match-count-mismatch", "Die Matchzahl passt nicht zur aktiven Teilnehmerzahl dieser Runde.", {
        round: round.label,
        eligiblePlayers: eligibleIds.length,
        expected: expectedMatches,
        actual: round.matches.length
      })
    );
  }

  if (inferredByes.length !== expectedByes) {
    issues.push(
      createFinding("round-bye-count-mismatch", "Die Freiloszahl passt nicht zur aktiven Teilnehmerzahl dieser Runde.", {
        round: round.label,
        expected: expectedByes,
        actual: inferredByes.length,
        inferredByes
      })
    );
  }

  inferredByes.forEach((playerId) => {
    const previousByes = auditState.byeCounts.get(playerId) ?? 0;
    const alternativesWithoutBye = eligibleIds.filter((eligibleId) => eligibleId !== playerId && (auditState.byeCounts.get(eligibleId) ?? 0) === 0);

    if (previousByes > 0 && alternativesWithoutBye.length > 0) {
      issues.push(
        createFinding("repeated-bye", "Ein Spieler erhaelt ein zweites Freilos, obwohl andere noch keines hatten.", {
          round: round.label,
          playerId,
          previousByes
        })
      );
    }
  });

  if (roundIndex > 0) {
    const observedCost = observedTopDownScoreCost(round.matches, auditState.pointsById);
    const bestCost = optimalTopDownScoreCost(eligibleIds, auditState.pointsById, auditState.playedPairs, auditState.byeCounts);

    if (bestCost !== null && observedCost !== bestCost) {
      issues.push(
        createFinding("round-pairing-score-gap-not-optimal", "Die Runde paart die Sieggruppen nicht optimal nach Schweizer System.", {
          round: round.label,
          observedTopDownCost: observedCost.toString(),
          bestTopDownCost: bestCost.toString()
        })
      );
    }

    if (options.checkRankAwarePairing !== false) {
      const observedRankCost = observedRankAwarePairingCost(
        round.matches,
        inferredByes,
        eligibleIds,
        auditState,
        playerById
      );
      const bestRankCost = optimalRankAwarePairingCost(eligibleIds, auditState, playerById);

      if (observedRankCost && bestRankCost !== null && observedRankCost.cost !== bestRankCost) {
        const collection = options.requireRankAwarePairing === true ? issues : warnings;

        collection.push(
          createFinding("round-pairing-rank-not-optimal", "Die Runde folgt nicht optimal der Buchholz-/Rangfolge des aktuellen Zwischenstands.", {
            round: round.label,
            observedRankCost: observedRankCost.cost.toString(),
            bestRankCost: bestRankCost.toString(),
            inferredByes,
            standingsBeforeRound: observedRankCost.standings.map((standing) => ({
              playerId: standing.playerId,
              points: standing.matchPoints,
              buchholz: standing.buchholz,
              rank: standing.rank
            }))
          })
        );
      }
    }
  }

  round.matches.forEach((match) => {
    [match.playerA, match.playerB].forEach((playerId) => {
      participantCounts.set(playerId, (participantCounts.get(playerId) ?? 0) + 1);
    });

    if (!playerById.has(match.playerA) || !playerById.has(match.playerB)) {
      return;
    }

    const pairKey = createPairKey(match.playerA, match.playerB);
    if (auditState.playedPairs.has(pairKey)) {
      issues.push(
        createFinding("rematch", "Im Schweizer System darf dieselbe Paarung nicht erneut angesetzt werden.", {
          round: round.label,
          pairKey,
          match: describeMatch(match)
        })
      );
    }

    auditMatchScore(issues, round, match, setsToWin);
  });

  participantCounts.forEach((count, playerId) => {
    if (count > 1) {
      issues.push(
        createFinding("player-double-booked", "Ein Spieler ist in derselben Runde mehrfach angesetzt.", {
          round: round.label,
          playerId,
          count
        })
      );
    }
  });
}

function createRoundProof(round, roundIndex, auditState, playerById, setsToWin) {
  const eligibleIds = [...auditState.activePlayerIds].filter((playerId) => !auditState.retiredBeforeRound.has(playerId));
  const expectedMatches = Math.floor(eligibleIds.length / 2);
  const expectedByes = eligibleIds.length % 2;
  const beforeStandings = createAuditStandings(eligibleIds, auditState, playerById);
  const beforeStandingById = new Map(beforeStandings.map((standing) => [standing.playerId, standing]));
  const inferredByes = inferRoundByes(eligibleIds, round.matches);
  const validByeCandidates = expectedByes === 1
    ? new Set(selectLowestScoreByeCandidates(eligibleIds, auditState.pointsById, auditState.byeCounts))
    : new Set();
  const participantCounts = new Map();
  const rematches = [];

  const matches = round.matches.map((match) => {
    [match.playerA, match.playerB].forEach((playerId) => {
      participantCounts.set(playerId, (participantCounts.get(playerId) ?? 0) + 1);
    });

    const pairKey = createPairKey(match.playerA, match.playerB);
    const priorPairing = auditState.playedPairs.has(pairKey);
    if (priorPairing) {
      rematches.push({
        round: round.label,
        pairKey,
        match: describeMatch(match)
      });
    }

    const scoreValidation = validateTableTennisSetScores(extractPlayedSets(match), {
      setsToWin,
      requireCompleteMatch: match.state !== "retired-a" && match.state !== "retired-b"
    });
    const playerAStanding = beforeStandingById.get(match.playerA);
    const playerBStanding = beforeStandingById.get(match.playerB);

    return {
      nr: Number(match.nr),
      pairKey,
      priorPairing,
      playerA: describeProofPlayer(playerById, beforeStandingById, match.playerA),
      playerB: describeProofPlayer(playerById, beforeStandingById, match.playerB),
      scoreGapBefore: Math.abs((playerAStanding?.matchPoints ?? 0) - (playerBStanding?.matchPoints ?? 0)),
      rankGapBefore: Math.abs((playerAStanding?.rank ?? 0) - (playerBStanding?.rank ?? 0)),
      sameScoreGroupBefore: (playerAStanding?.matchPoints ?? 0) === (playerBStanding?.matchPoints ?? 0),
      winner: describeProofPlayer(playerById, null, getWinnerId(match)),
      state: match.state || "played",
      score: {
        valid: scoreValidation.valid,
        errors: scoreValidation.errors,
        sets: formatPlayedSets(match),
        setScore: `${match.setsA ?? 0}:${match.setsB ?? 0}`,
        games: `${match.gamesA ?? 0}:${match.gamesB ?? 0}`
      }
    };
  });

  const doubleBookedPlayers = [...participantCounts.entries()]
    .filter(([, count]) => count > 1)
    .map(([playerId, count]) => ({
      player: describeProofPlayer(playerById, beforeStandingById, playerId),
      count
    }));
  const byes = inferredByes.map((playerId) => {
    const previousByes = auditState.byeCounts.get(playerId) ?? 0;
    const alternativesWithoutBye = eligibleIds.filter(
      (eligibleId) => eligibleId !== playerId && (auditState.byeCounts.get(eligibleId) ?? 0) === 0
    );

    return {
      player: describeProofPlayer(playerById, beforeStandingById, playerId),
      previousByes,
      validCandidate: expectedByes === 1 ? validByeCandidates.has(playerId) : false,
      repeatedWhileAlternativesExist: previousByes > 0 && alternativesWithoutBye.length > 0
    };
  });
  const observedTopDownCost = roundIndex > 0
    ? observedTopDownScoreCost(round.matches, auditState.pointsById)
    : null;
  const bestTopDownCost = roundIndex > 0
    ? optimalTopDownScoreCost(eligibleIds, auditState.pointsById, auditState.playedPairs, auditState.byeCounts)
    : null;
  const observedRankAwarePairing = roundIndex > 0
    ? observedRankAwarePairingCost(round.matches, inferredByes, eligibleIds, auditState, playerById)
    : null;
  const bestRankAwareCost = roundIndex > 0
    ? optimalRankAwarePairingCost(eligibleIds, auditState, playerById)
    : null;
  const scoreGroupPairingOptimal =
    roundIndex === 0 ||
    bestTopDownCost === null ||
    observedTopDownCost === bestTopDownCost;
  const rankAwarePairingOptimal =
    roundIndex === 0 ||
    bestRankAwareCost === null ||
    observedRankAwarePairing?.cost === bestRankAwareCost;
  const byeRuleOk =
    inferredByes.length === expectedByes &&
    byes.every((bye) => !bye.repeatedWhileAlternativesExist) &&
    (expectedByes === 0 || byes.every((bye) => bye.validCandidate));

  rememberRoundResults(round, auditState);

  const afterEligibleIds = [...auditState.activePlayerIds].filter(
    (playerId) => !auditState.retiredBeforeRound.has(playerId)
  );
  const afterStandings = createAuditStandings(afterEligibleIds, auditState, playerById);

  return {
    roundNumber: round.parsedRoundNumber ?? roundIndex + 1,
    label: round.label,
    expectedMatches,
    actualMatches: round.matches.length,
    expectedByes,
    actualByes: inferredByes.length,
    scoreGroupPairingOptimal,
    rankAwarePairingOptimal,
    observedTopDownCost: formatCost(observedTopDownCost),
    bestTopDownCost: formatCost(bestTopDownCost),
    observedRankAwareCost: formatCost(observedRankAwarePairing?.cost ?? null),
    bestRankAwareCost: formatCost(bestRankAwareCost),
    byeRuleOk,
    rematches,
    doubleBookedPlayers,
    standingsBefore: beforeStandings.map((standing) => describeProofStanding(standing, playerById)),
    matches,
    byes,
    standingsAfter: afterStandings.map((standing) => describeProofStanding(standing, playerById))
  };
}

function inferRoundByes(eligibleIds, matches) {
  const participants = new Set(matches.flatMap((match) => [match.playerA, match.playerB]));
  return eligibleIds.filter((playerId) => !participants.has(playerId));
}

function observedTopDownScoreCost(matches, pointsById) {
  return calculateTopDownScoreCost(matches.map((match) => [match.playerA, match.playerB]), pointsById);
}

function observedRankAwarePairingCost(matches, inferredByes, eligibleIds, auditState, playerById) {
  const context = createRankAwarePairingContext(eligibleIds, auditState, playerById);

  if (inferredByes.length > 1) {
    return null;
  }

  const pairCost = calculateRankAwarePairsCost(
    matches.map((match) => [match.playerA, match.playerB]),
    context
  );
  const byeCost = inferredByes.length === 1
    ? calculateRankAwareByeCost(inferredByes[0], context, auditState, true)
    : 0n;

  return {
    cost: pairCost + byeCost,
    standings: context.standings
  };
}

function optimalRankAwarePairingCost(eligibleIds, auditState, playerById) {
  const context = createRankAwarePairingContext(eligibleIds, auditState, playerById);

  if (context.rankedIds.length % 2 === 0) {
    return minRankAwarePairingCost(context.rankedIds, context);
  }

  const byeCandidates = selectLowestScoreByeCandidates(
    context.rankedIds,
    auditState.pointsById,
    auditState.byeCounts
  );
  const costs = byeCandidates
    .map((byePlayerId) => {
      const pairCost = minRankAwarePairingCost(
        context.rankedIds.filter((playerId) => playerId !== byePlayerId),
        context
      );

      return pairCost === null ? null : pairCost + calculateRankAwareByeCost(byePlayerId, context, auditState, false);
    })
    .filter((cost) => cost !== null);

  return costs.length > 0 ? costs.reduce((best, cost) => (cost < best ? cost : best), costs[0]) : null;
}

function createRankAwarePairingContext(eligibleIds, auditState, playerById) {
  const standings = createAuditStandings(eligibleIds, auditState, playerById);
  const rankIndexById = new Map(standings.map((standing, index) => [standing.playerId, index]));

  return {
    standings,
    rankedIds: standings.map((standing) => standing.playerId),
    rankIndexById,
    pointsById: auditState.pointsById,
    scoreWeightById: createRankScoreWeightById(auditState.pointsById, eligibleIds),
    playedPairs: auditState.playedPairs
  };
}

function createAuditStandings(eligibleIds, auditState, playerById) {
  const activeScores = eligibleIds.map((playerId) => auditState.pointsById.get(playerId) ?? 0);
  const lastActiveScore = activeScores.length > 0 ? Math.min(...activeScores) : 0;
  const standings = eligibleIds.map((playerId) => {
    const opponentIds = auditState.opponentIdsById.get(playerId) ?? [];
    const buchholz = opponentIds.reduce(
      (total, opponentId) => total + (auditState.pointsById.get(opponentId) ?? 0),
      0
    ) + (auditState.byeCounts.get(playerId) ?? 0) * lastActiveScore;

    return {
      playerId,
      matchPoints: auditState.pointsById.get(playerId) ?? 0,
      wins: auditState.winsById.get(playerId) ?? 0,
      headToHeadWins: auditState.headToHeadWinsById.get(playerId) ?? new Map(),
      buchholz,
      rating: getPlayerRating(playerById.get(playerId)),
      name: getPlayerName(playerById.get(playerId))
    };
  });

  standings.splice(0, standings.length, ...sortAuditStandings(standings));
  standings.forEach((standing, index) => {
    standing.rank = index + 1;
  });

  return standings;
}

function comparePrimaryAuditStandings(left, right) {
  return (
    right.matchPoints - left.matchPoints ||
    right.wins - left.wins ||
    right.buchholz - left.buchholz
  );
}

function compareAuditDirectComparison(left, right) {
  const leftWins = left.headToHeadWins?.get(right.playerId) ?? 0;
  const rightWins = right.headToHeadWins?.get(left.playerId) ?? 0;
  return rightWins - leftWins;
}

function compareAuditStableFallback(left, right) {
  return (
    compareNullableRatingLowerFirst(left.rating, right.rating) ||
    left.name.localeCompare(right.name, "de") ||
    left.playerId.localeCompare(right.playerId)
  );
}

function hasSamePrimaryAuditTieBreak(left, right) {
  return (
    left.matchPoints === right.matchPoints &&
    left.wins === right.wins &&
    left.buchholz === right.buchholz
  );
}

function sortAuditStandings(standings) {
  const sorted = [...standings].sort(
    (left, right) => comparePrimaryAuditStandings(left, right) || compareAuditStableFallback(left, right)
  );
  const resolved = [];
  let index = 0;

  while (index < sorted.length) {
    const group = [sorted[index]];
    index += 1;

    while (index < sorted.length && hasSamePrimaryAuditTieBreak(group[0], sorted[index])) {
      group.push(sorted[index]);
      index += 1;
    }

    if (group.length === 2) {
      group.sort(
        (left, right) =>
          compareAuditDirectComparison(left, right) || compareAuditStableFallback(left, right)
      );
    } else {
      group.sort(compareAuditStableFallback);
    }

    resolved.push(...group);
  }

  return resolved;
}

function compareNullableRatingLowerFirst(leftRating, rightRating) {
  const leftHasRating = Number.isFinite(leftRating);
  const rightHasRating = Number.isFinite(rightRating);

  if (leftHasRating && rightHasRating) {
    return leftRating - rightRating;
  }

  if (leftHasRating) {
    return -1;
  }

  if (rightHasRating) {
    return 1;
  }

  return 0;
}

function createRankScoreWeightById(pointsById, eligibleIds) {
  const orderedScores = [...new Set(eligibleIds.map((playerId) => pointsById.get(playerId) ?? 0))].sort(
    (left, right) => right - left
  );
  const weightByScore = new Map(
    orderedScores.map((score, index) => [
      score,
      RANK_PAIRING_COST_BASE ** BigInt(orderedScores.length - index - 1)
    ])
  );

  return new Map(eligibleIds.map((playerId) => [playerId, weightByScore.get(pointsById.get(playerId) ?? 0) ?? 1n]));
}

function minRankAwarePairingCost(playerIds, context) {
  const memo = new Map();

  function search(remainingIds) {
    if (remainingIds.length === 0) {
      return 0n;
    }

    const key = remainingIds.join("|");
    if (memo.has(key)) {
      return memo.get(key);
    }

    const playerAId = remainingIds[0];
    let best = null;

    for (let index = 1; index < remainingIds.length; index += 1) {
      const playerBId = remainingIds[index];
      const rest = remainingIds.filter((playerId) => playerId !== playerAId && playerId !== playerBId);
      const restCost = search(rest);

      if (restCost === null) {
        continue;
      }

      const pairCost = calculateRankAwarePairCost(playerAId, playerBId, context);
      const totalCost = pairCost + restCost;
      best = best === null || totalCost < best ? totalCost : best;
    }

    memo.set(key, best);
    return best;
  }

  return search([...playerIds]);
}

function calculateRankAwarePairsCost(pairs, context) {
  return pairs.reduce(
    (total, [playerAId, playerBId]) => total + calculateRankAwarePairCost(playerAId, playerBId, context),
    0n
  );
}

function calculateRankAwarePairCost(playerAId, playerBId, context) {
  const scoreGap = BigInt(Math.abs((context.pointsById.get(playerAId) ?? 0) - (context.pointsById.get(playerBId) ?? 0)));
  const rankGap = BigInt(Math.abs(
    (context.rankIndexById.get(playerAId) ?? 0) - (context.rankIndexById.get(playerBId) ?? 0)
  ));
  const scoreWeight =
    (context.scoreWeightById.get(playerAId) ?? 1n) + (context.scoreWeightById.get(playerBId) ?? 1n);
  const rematchCost = context.playedPairs.has(createPairKey(playerAId, playerBId))
    ? RANK_PAIRING_REMATCH_COST
    : 0n;

  return rematchCost + scoreGap * scoreWeight + rankGap;
}

function calculateRankAwareByeCost(playerId, context, auditState, penalizeInvalidCandidate) {
  const validCandidates = new Set(
    selectLowestScoreByeCandidates(context.rankedIds, auditState.pointsById, auditState.byeCounts)
  );
  const invalidCandidateCost = penalizeInvalidCandidate && !validCandidates.has(playerId)
    ? RANK_PAIRING_REPEAT_BYE_COST
    : 0n;
  const repeatedByeCost = (auditState.byeCounts.get(playerId) ?? 0) > 0
    ? RANK_PAIRING_REPEAT_BYE_COST
    : 0n;
  const rankIndex = context.rankIndexById.get(playerId) ?? context.rankedIds.length;

  return invalidCandidateCost + repeatedByeCost + BigInt(context.rankedIds.length - rankIndex);
}

function optimalTopDownScoreCost(playerIds, pointsById, playedPairs, byeCounts) {
  const sortedIds = [...playerIds].sort(comparePlayerIdsByScore(pointsById));

  if (sortedIds.length % 2 === 0) {
    return minTopDownScoreCost(sortedIds, pointsById, playedPairs);
  }

  const byeCandidates = selectLowestScoreByeCandidates(sortedIds, pointsById, byeCounts);
  const costs = byeCandidates
    .map((byePlayerId) =>
      minTopDownScoreCost(
        sortedIds.filter((playerId) => playerId !== byePlayerId),
        pointsById,
        playedPairs
      )
    )
    .filter((cost) => cost !== null);

  return costs.length > 0 ? costs.reduce((best, cost) => (cost < best ? cost : best), costs[0]) : null;
}

function selectLowestScoreByeCandidates(playerIds, pointsById, byeCounts) {
  const neverHadBye = playerIds.filter((playerId) => (byeCounts.get(playerId) ?? 0) === 0);
  const candidatePool = neverHadBye.length > 0 ? neverHadBye : playerIds;
  const lowestScore = Math.min(...candidatePool.map((playerId) => pointsById.get(playerId) ?? 0));

  return candidatePool.filter((playerId) => (pointsById.get(playerId) ?? 0) === lowestScore);
}

function minTopDownScoreCost(playerIds, pointsById, playedPairs) {
  const memo = new Map();

  function search(remainingIds) {
    if (remainingIds.length === 0) {
      return 0n;
    }

    const key = remainingIds.join("|");
    if (memo.has(key)) {
      return memo.get(key);
    }

    const playerAId = remainingIds[0];
    let best = null;

    for (let index = 1; index < remainingIds.length; index += 1) {
      const playerBId = remainingIds[index];
      if (playedPairs.has(createPairKey(playerAId, playerBId))) {
        continue;
      }

      const rest = remainingIds.filter((playerId) => playerId !== playerAId && playerId !== playerBId);
      const restCost = search(rest);

      if (restCost === null) {
        continue;
      }

      const pairCost = calculateTopDownScoreCost([[playerAId, playerBId]], pointsById);
      const totalCost = pairCost + restCost;
      best = best === null || totalCost < best ? totalCost : best;
    }

    memo.set(key, best);
    return best;
  }

  return search([...playerIds].sort(comparePlayerIdsByScore(pointsById)));
}

function calculateTopDownScoreCost(pairs, pointsById) {
  const orderedScores = [...new Set([...pointsById.values()])].sort((left, right) => right - left);
  const exponentByScore = new Map(orderedScores.map((score, index) => [score, orderedScores.length - index - 1]));
  const base = 100n;

  return pairs.reduce((cost, [playerAId, playerBId]) => {
    const gap = BigInt(Math.abs((pointsById.get(playerAId) ?? 0) - (pointsById.get(playerBId) ?? 0)));
    const leftExponent = exponentByScore.get(pointsById.get(playerAId) ?? 0);
    const rightExponent = exponentByScore.get(pointsById.get(playerBId) ?? 0);

    if (leftExponent === undefined || rightExponent === undefined) {
      return cost;
    }

    return cost + gap * base ** BigInt(leftExponent) + gap * base ** BigInt(rightExponent);
  }, 0n);
}

function comparePlayerIdsByScore(pointsById) {
  return (leftId, rightId) =>
    (pointsById.get(rightId) ?? 0) - (pointsById.get(leftId) ?? 0) ||
    String(leftId).localeCompare(String(rightId), "de");
}

function auditMatchScore(issues, round, match, setsToWin) {
  const playedSets = extractPlayedSets(match);
  const validation = validateTableTennisSetScores(playedSets, {
    setsToWin,
    requireCompleteMatch: match.state !== "retired-a" && match.state !== "retired-b"
  });

  if (!validation.valid) {
    issues.push(
      createFinding("invalid-set-score", "Ein Matchergebnis enthaelt unzulaessige Satzpunkte.", {
        round: round.label,
        match: describeMatch(match),
        errors: validation.errors
      })
    );
  }

  if ((Number(match.matchesA) || 0) + (Number(match.matchesB) || 0) !== 1) {
    issues.push(
      createFinding("missing-match-winner", "Ein exportiertes Spiel muss genau einen Sieger haben.", {
        round: round.label,
        match: describeMatch(match)
      })
    );
  }
}

function extractPlayedSets(match) {
  return match.setPoints
    .map((set) => [Number(set.a), Number(set.b)])
    .filter(([left, right]) => left > 0 || right > 0);
}

function rememberRoundResults(round, auditState) {
  const eligibleIds = [...auditState.activePlayerIds].filter((playerId) => !auditState.retiredBeforeRound.has(playerId));
  const inferredByes = inferRoundByes(eligibleIds, round.matches);
  const retiredAfterRound = [];

  inferredByes.forEach((playerId) => {
    auditState.pointsById.set(playerId, (auditState.pointsById.get(playerId) ?? 0) + 1);
    auditState.winsById.set(playerId, (auditState.winsById.get(playerId) ?? 0) + 1);
    auditState.byeCounts.set(playerId, (auditState.byeCounts.get(playerId) ?? 0) + 1);
  });

  round.matches.forEach((match) => {
    auditState.playedPairs.add(createPairKey(match.playerA, match.playerB));
    auditState.opponentIdsById.get(match.playerA)?.push(match.playerB);
    auditState.opponentIdsById.get(match.playerB)?.push(match.playerA);

    const winnerId = getWinnerId(match);
    if (winnerId) {
      auditState.pointsById.set(winnerId, (auditState.pointsById.get(winnerId) ?? 0) + 1);
      auditState.winsById.set(winnerId, (auditState.winsById.get(winnerId) ?? 0) + 1);
      const loserId = winnerId === match.playerA ? match.playerB : match.playerA;
      const winnerHeadToHead = auditState.headToHeadWinsById.get(winnerId);
      winnerHeadToHead?.set(loserId, (winnerHeadToHead.get(loserId) ?? 0) + 1);
    }

    const retiredPlayerId = getRetiredPlayerId(match);
    if (retiredPlayerId) {
      retiredAfterRound.push(retiredPlayerId);
    }
  });

  retiredAfterRound.forEach((playerId) => {
    auditState.retiredBeforeRound.add(playerId);
  });
}

function getWinnerId(match) {
  if (Number(match.matchesA) === 1) {
    return match.playerA;
  }

  if (Number(match.matchesB) === 1) {
    return match.playerB;
  }

  return "";
}

function getRetiredPlayerId(match) {
  if (match.state === "retired-a") {
    return match.playerA;
  }

  if (match.state === "retired-b") {
    return match.playerB;
  }

  return "";
}

function createPairKey(playerAId, playerBId) {
  return [playerAId, playerBId].sort().join("::");
}

function describeMatch(match) {
  return {
    nr: match.nr,
    group: match.group,
    playerA: match.playerA,
    playerB: match.playerB
  };
}

function describeProofPlayer(playerById, standingById, playerId) {
  if (!playerId) {
    return null;
  }

  const player = playerById.get(playerId);
  const standing = standingById?.get(playerId);

  return {
    id: playerId,
    name: getPlayerName(player),
    ttr: getPlayerRating(player),
    rank: standing?.rank ?? null,
    matchPoints: standing?.matchPoints ?? null,
    wins: standing?.wins ?? null,
    buchholz: standing?.buchholz ?? null
  };
}

function describeProofStanding(standing, playerById) {
  return {
    rank: standing.rank,
    player: describeProofPlayer(playerById, null, standing.playerId),
    matchPoints: standing.matchPoints,
    wins: standing.wins,
    buchholz: standing.buchholz
  };
}

function formatPlayedSets(match) {
  return match.setPoints
    .map((set) => [Number(set.a), Number(set.b)])
    .filter(([left, right]) => left > 0 || right > 0)
    .map(([left, right]) => `${left}:${right}`);
}

function formatCost(cost) {
  if (cost === null || cost === undefined) {
    return null;
  }

  return cost.toString();
}

function auditFinalPlacements(issues, competition, portal, options) {
  if (options.checkPlacements === false) {
    return;
  }

  try {
    const { state } = createTournamentStateFromClickttPortal(portal, {
      competitionSelector: competition.id || competition.index
    });
    const normalized = normalizeTtRaceTournament(state.ttRace);
    const standingById = new Map(normalized.standings.map((standing) => [standing.playerId, standing]));

    state.ttRace.players.forEach((player) => {
      const standing = standingById.get(player.id);
      const expectedPlacement = standing?.rank ?? null;

      if (standing?.status === "missing" || standing?.played === 0 && standing?.byes === 0) {
        return;
      }

      if (!player.placement) {
        issues.push(
          createFinding("missing-placement", "Ein aktiver Spieler hat keine Endplatzierung im Export.", {
            playerId: player.id,
            expectedPlacement
          })
        );
        return;
      }

      if (expectedPlacement && Number(player.placement) !== expectedPlacement) {
        issues.push(
          createFinding("placement-mismatch", "Die Endplatzierung passt nicht zur Schweizer-System-Wertung.", {
            playerId: player.id,
            expected: expectedPlacement,
            actual: Number(player.placement)
          })
        );
      }
    });
  } catch (error) {
    issues.push(
      createFinding("placement-audit-failed", "Die Endplatzierungen konnten nicht berechnet werden.", {
        message: error instanceof Error ? error.message : String(error)
      })
    );
  }
}
