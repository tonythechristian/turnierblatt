(function () {
  const {
    MODES,
    MATCH_MODES,
    MATCH_MODE_ORDER,
    MATCH_STATUSES,
    MATCH_STATUS_ORDER,
    PLAYER_STATUSES,
    PLAYER_STATUS_ORDER,
    TIE_BREAK_CRITERIA,
    VALID_SCORES,
    buildMatchSchedule,
    clampCount,
    clampPositiveInteger,
    createDefaultState,
    getDefaultWinScore,
    getMatchStatusLabel,
    getPlayerStatusLabel,
    getValidScoresForMode,
    isFixedSetMatchMode,
    isDefaultScoringRules,
    isScoreCompatibleWithMode,
    isWinningMatchMode,
    matchModeAllowsDraw,
    normalizeScoringRules,
    analyzeRoundRobin,
    analyzeTeamCompetition,
    analyzeGroupsKnockout,
    shuffleRoundRobinDraw,
    shuffleGroupsKnockoutDraw,
    getRoundRobinRoundCount,
    getTeamRoundCount,
    getGroupsKnockoutGroupRoundCount,
    getGroupsKnockoutKnockoutRoundCount,
    normalizeState,
    reverseScore
  } = window.TournamentLogic;

  const {
    downloadBlob,
    exportRoundRobinCsv,
    exportRoundRobinRoundCsv,
    exportRoundRobinXlsx,
    exportRoundRobinRoundXlsx,
    sanitizeFilename,
    exportTeamCsv,
    exportTeamRoundCsv,
    exportTeamRoundXlsx,
    exportTeamXlsx,
    exportGroupsKnockoutCsv,
    exportGroupsKnockoutRoundCsv,
    exportGroupsKnockoutRoundXlsx,
    exportGroupsKnockoutXlsx
  } = window.TournamentExport;

  const { exampleRoundRobinState, exampleTeamState, exampleGroupsKnockoutState } = window.TournamentExamples;

  // Wie viele Zeilen der Stand in der Randspalte zeigt. Bis acht Teilnehmern
  // steht alles da — ein Verweis auf "die ganze Liste" lohnt nicht für ein
  // oder zwei Zeilen.
  const RAIL_STANDINGS_SHORT = 6;
  const RAIL_STANDINGS_ALWAYS_FULL = 8;

  const STORAGE_KEY = "tournament-workspace-state-v1";
  const TEMPLATE_STORAGE_KEY = "tournament-templates-v1";
  const LEGACY_STORAGE_KEYS = [
    "table-tennis-tournament-state-v2",
    "table-tennis-tournament-state-v1"
  ];
  const VIEW_STORAGE_KEY = "tournament-workspace-view-v1";
  const LEGACY_VIEW_STORAGE_KEY = "table-tennis-tournament-view-v1";
  const PLAYER_STATS_FONT_SIZE_KEY = "tournament-player-stats-font-size-v1";
  const LEGACY_PLAYER_STATS_FONT_SIZE_KEY = "table-tennis-player-stats-font-size-v1";
  const ROUND_CHECKPOINTS_KEY = "tournament-round-checkpoints-v1";
  /** B112: Unlesbarer Altstand wird hierher gerettet, bevor er überschrieben wird. */
  const RESCUE_STORAGE_KEY = "tournament-unreadable-state-v1";
  // Inhaltsstempel je gesichertem Rundenstand. Eigener, winziger Schlüssel:
  // Er passt auch dann noch in den Speicher, wenn der große Checkpoint-Schlüssel
  // längst platzt — und genau dann darf kein zweiter Download entstehen (B045).
  const ROUND_CHECKPOINT_STAMPS_KEY = "tournament-round-checkpoint-stamps-v1";
  const ROUND_CHECKPOINT_STAMP_LIMIT = 200;
  const BACKUP_KIND = "tournament-workspace-backup";
  const LEGACY_BACKUP_KIND = "table-tennis-workspace-backup";
  const UNDO_LIMIT = 5;
  const ROUND_CHECKPOINT_LIMIT = 20;
  const BTTV_TT_RACE_NAME = `BTTV Bavarian TT-Race ${new Date().getFullYear()}`;
  const NORMAL_SET_SCORE_INPUT_HINT =
    "Satzdetails als 11:7, 9:11 oder kurz 7, -9 eingeben.";
  // Am Feld selbst steht auch der kurze Weg zum Sonderstatus — die „!"-Klappe
  // daneben ist klein und auf Tastatur schwer zu treffen.
  const QUICK_RESULT_INPUT_HINT =
    "Satzdetails als 11:7, 9:11 oder kurz 7, -9 eingeben. Enter springt zum nächsten offenen Spiel. Kurzformen: w.o. 1 / w.o. 2 (kampflos), auf 1 / auf 2 (Aufgabe), n.a. (nicht gewertet) — die Ziffer nennt den Sieger.";
  // ── Fokus überlebt das Neuzeichnen (B020/B078) ────────────────────────────
  //
  // Jeder Commit tauscht das ganze Blatt per innerHTML aus. Vorher stand der
  // Fokus danach auf BODY: blind weitergetippte Ergebnisse verpufften, Tab
  // sprang an den Seitenanfang und ein blindes Enter drückte fremde Knöpfe
  // (gemessen: 1 von 8 Feldern gefüllt). Gemerkt wird das Feld über seinen
  // Schlüssel — der Index ist nötig, weil derselbe Schlüssel doppelt auf dem
  // Screen steht (Rundenliste und Matrix).
  const FOCUS_MEMO_FIELDS = [
    { prop: "quickKey", attribute: "data-quick-key", scopeProp: "quickScope" },
    { prop: "ttRaceSets", attribute: "data-tt-race-sets", scopeProp: null },
    { prop: "matchStatusKey", attribute: "data-match-status-key", scopeProp: "matchStatusScope" },
    { prop: "resultKey", attribute: "data-result-key", scopeProp: "resultScope" }
  ];
  /** Felder, durch die Enter weiterspringt: die Ergebnisfelder selbst. */
  const CHAIN_FIELD_SELECTOR = "[data-quick-key], [data-tt-race-sets]";
  const CHAIN_CONTAINER_SELECTOR = "ul.match-list, .matrix-table, .double-match-list";
  let pendingChainFocus = null;
  /** Zählt die Neuzeichnungen des Blattes — daran erkennt Enter, ob eines kam. */
  let sheetRenderCount = 0;
  const PLAYER_STATS_FONT_SIZES = ["small", "medium", "large"];
  const LIVE_RANKING_LIMIT_KEY = "tournament-live-ranking-limit-v1";
  const LIVE_RANKING_LIMIT_OPTIONS = [3, 5, 10, "all"];
  // F003: Die Live-Bühne hat feste Maße; alles darauf ist in px des Entwurfs
  // gerechnet und wird als Ganzes skaliert.
  const LIVE_STAGE_WIDTH = 1920;
  const LIVE_STAGE_HEIGHT = 1080;
  // Gemessene Obergrenzen, ab denen Zeilen auf 1080 px nicht mehr lesbar
  // bleiben. Wird eine überschritten, sagt die Bühne, wie viele fehlen (G6).
  const LIVE_STANDING_MAX_ROWS = 22;
  const LIVE_FINAL_MAX_ROWS = 20;
  const INFO_MESSAGE_DURATION_MS = 5000;
  const BACKUP_FILE_VERSION = 1;
  const DYNAMIC_MODULE_VERSION = "tt-race-random-draw-all-rounds-20260523";
  // Kein eigener Namensschritt mehr: der Name steht im Formatschritt und ist
  // freiwillig, weil eine click-TT XML ihn ohnehin ersetzt.
  const TOURNAMENT_WIZARD_STEPS = ["Format", "Teilnehmer", "Spielmodus", "Zusammenfassung"];
  const SPORT_PRESETS = [
    {
      id: "tischtennis",
      label: "Tischtennis",
      sport: "Tischtennis",
      format: "roundRobin",
      playerCount: 8,
      teamACount: 4,
      teamBCount: 4,
      matchMode: "win3"
    }
  ];
  const WIZARD_FORMATS = [
    {
      id: "roundRobin",
      label: "Jeder-gegen-jeden",
      description: "Tischtennis-Einzel mit Rundenplan, Tischverteilung und Rangliste.",
      available: true,
      official: false
    },
    {
      id: "team",
      label: "Teamwettbewerb",
      description: "Zwei Mannschaften mit Einzeln, optionalen Doppeln und Teamwertung.",
      available: true,
      official: false
    },
    {
      id: "groupsKnockout",
      label: "Gruppen + KO",
      description: "Gruppenphase mit anschließender KO-Runde für die Bestplatzierten.",
      available: true,
      official: false
    },
    {
      id: "ttRace",
      label: "BTTV TT-Race",
      description:
        "3 Gewinnsätze, TTR-Auslosung und 6 Schweizer Runden. click-TT XML möglich, aber nicht nötig.",
      available: true,
      official: true
    },
    {
      id: "knockout",
      label: "KO-System",
      description: "Platzhalter für ein reines KO-Turnier.",
      available: false,
      official: false
    }
  ];

  let workspace = loadWorkspace();
  let roundCheckpoints = loadRoundCheckpoints();
  let tournamentTemplates = loadTournamentTemplates();
  let activeTournament = getActiveTournament();
  let analysis = computeAnalysis();
  let activeWorkspaceView = loadWorkspaceView();
  let playerStatsFontSize = loadPlayerStatsFontSize();
  let liveRankingLimit = loadLiveRankingLimit();
  /** Beobachtet die Bühnenfläche, damit der Skalierungsfaktor mitläuft. */
  let liveViewportObserver = null;
  // Merkt sich, ob das letzte Schreiben fehlgeschlagen ist — die Warnung darf
  // nicht beim naechsten Neuzeichnen verschwinden.
  let storageFailed = false;
  /** B112/B117: Was beim Laden nicht gelesen werden konnte — nie stillschweigend. */
  let unreadableStateNotice = null;
  /** B117: Die Checkpoint-Liste war da, ließ sich aber nicht lesen. */
  let roundCheckpointsUnreadable = false;
  // Konnte die Checkpoint-Liste nicht abgelegt werden? Das ist ein Dauerzustand
  // in der Randspalte, kein Toast, der nach fuenf Sekunden verschwindet (B054).
  let roundCheckpointStorageFailed = false;
  // Notnagel fuer den Inhaltsstempel: Wenn selbst der kleine Stempelschluessel
  // nicht mehr geschrieben werden kann, haelt diese Karte ihn wenigstens fuer
  // dieses Fenster fest — damit derselbe Stand nie zweimal heruntergeladen wird.
  const roundCheckpointStampFallback = new Map();
  // Hat ein anderes Fenster den Arbeitsbereich geaendert? Dann wird hier nicht
  // mehr blind darueber geschrieben (B019).
  let externalWorkspaceChange = null;
  // Randspalte aufgeklappt? Gilt je Sitzung, nicht je Turnier.
  let railStandingsExpanded = false;
  let tournamentHistories = createTournamentHistories();
  let participantImportDrafts = new Map();
  let clickTtImportDraft = null;
  let clickTtBridgeModule = null;
  let clickTtBridgePromise = null;
  let ttRaceEngineModule = null;
  let ttRaceEnginePromise = null;
  let infoMessageTimeoutId = null;
  let draggedTournamentState = null;
  let tournamentWizardState = null;
  let tournamentWizardPlayerCountRenderTimer = null;

  const tabsElement = document.querySelector("#tournamentTabs");
  const workspaceViewTabs = document.querySelector("#workspaceViewTabs");
  const switcherButton = document.querySelector("#tournamentSwitcherBtn");
  const switcherPanel = document.querySelector("#tournamentSwitcherPanel");
  const switcherName = document.querySelector("#tournamentSwitcherName");
  const screenKicker = document.querySelector("#screenKicker");
  const screenFacts = document.querySelector("#screenFacts");
  const screenMeta = document.querySelector("#screenMeta");
  const startView = document.querySelector("#startView");
  const startTournamentList = document.querySelector("#startTournamentList");
  const mainLayout = document.querySelector("main.layout");
  const inputView = document.querySelector("#inputView");
  const outputView = document.querySelector("#outputView");
  const liveView = document.querySelector("#liveView");
  const configForm = document.querySelector("#configForm");
  const configDetails = document.querySelector("#configDetails");
  const raceDayShell = document.querySelector("#raceDayShell");
  const tournamentSheet = document.querySelector("#tournamentSheet");
  const appTitle = document.querySelector("#appTitle");
  const messageArea = document.querySelector("#messageArea");
  const sheetMeta = document.querySelector("#sheetMeta");
  const printDocument = document.querySelector("#printDocument");
  const printRail = document.querySelector("#printRail");
  const printDocumentButtons = document.querySelector("#printDocumentButtons");
  const printScopeRow = document.querySelector("#printScopeRow");
  const printScopeSelect = document.querySelector("#printScopeSelect");
  const printKeyboardNote = document.querySelector("#printKeyboardNote");
  // ── Drucken und PDF ───────────────────────────────────────────────────────
  //
  // Die Auswahl lebt in der Randspalte, nicht in einem versteckten Feld: jeder
  // sichtbare Knopf trägt sein Dokument als `data-print-mode` und druckt genau
  // das. Vorher stand die Wahl in einem `<div hidden>`; sie blieb immer auf der
  // ersten Option stehen, und deshalb druckte auch „Startliste drucken" den
  // Spielplan (B021/B057). Cmd+P nimmt dieselbe Wahl — `beforeprint` liest
  // `printSelection`, nicht ein Formularfeld.
  //
  // Die Deklaration steht bewusst hier oben bei den DOM-Verweisen und nicht
  // bei den Druckfunktionen: die Ereignisbindung läuft beim Start, und ein
  // `const` weiter unten warf dort „Cannot access before initialization" —
  // dieselbe Klasse wie B014 (G0), die schon einmal die halbe Randspalte
  // ungerendert ließ.
  const printSelection = { mode: "schedule", scope: "all" };
  const autosaveState = document.querySelector("#autosaveState");
  const autosaveDetail = document.querySelector("#autosaveDetail");
  const roundBackupStatusTargets = [...document.querySelectorAll("[data-round-backup-status]")];
  // Zwei Ankerpunkte, ein Renderer: Startansicht und Ergebnisansicht. Am
  // Turniertag steht niemand in „Alle Turniere" — dort war der einzige Weg
  // zurück zu einem gesicherten Rundenstand (B056).
  const roundCheckpointPanels = [...document.querySelectorAll("[data-round-checkpoint-panel]")];
  const backupFileInput = document.querySelector("#backupFileInput");
  const clickTtFileInput = document.querySelector("#clickTtFileInput");
  const templateSelect = document.querySelector("#templateSelect");
  const templateIncludeResults = document.querySelector("#templateIncludeResults");
  const tournamentWizardDialog = document.querySelector("#tournamentWizardDialog");
  const tournamentWizardContent = document.querySelector("#tournamentWizardContent");
  const duplicateTournamentDialog = document.querySelector("#duplicateTournamentDialog");
  const duplicateTournamentText = document.querySelector("#duplicateTournamentText");
  const tieDecisionDialog = document.querySelector("#tieDecisionDialog");
  const tieDecisionContent = document.querySelector("#tieDecisionContent");

  // Die Überschrift trägt die Aufgabe des Reiters, nicht den Turniernamen.
  const VIEW_TITLES = {
    input: "Teilnehmer",
    output: "Ergebniseingabe",
    live: "Live-Ansicht"
  };

  /** Reines Gesamtergebnis wie 3:1 — wird als Ergebnis erkannt, nicht als Satz. */
  const TOTAL_SCORE_PATTERN = /^[0-5]\s*:\s*[0-5]$/;
  const QUICK_RESULT_PLACEHOLDER = "8, 3, 5 oder 3:1";
  const QUICK_RESULT_ERROR = "Nicht erkannt. Sätze als 11:7, 9:11 oder kurz 7, -9 eintragen.";

  /** Satzdetail-Schalter, getrennt je Screen. */
  const setDetailsByScreen = Object.create(null);

  /** Zeile der Startliste, die gerade bearbeitet wird. */
  let ttRaceEditingPlayerId = null;

  /** Ob die Turnierübersicht statt eines Turniers gezeigt wird. */
  let startViewOpen = false;

  initialize();

  function initialize() {
    const startupNotice = applyWorkspaceSeedFromUrl();
    seedRoundCheckpointStamps();
    renderAll();
    updateAutosaveStatus();
    primeOptionalModules();
    if (startupNotice) {
      showInfo(startupNotice);
    }
    // B112: Die Warnung über einen nicht lesbaren Stand steht zuletzt, damit
    // keine Erfolgsmeldung sie überschreibt — sie ist die wichtigste Nachricht
    // dieses Starts.
    renderUnreadableStateAlert();

    document
      .querySelector("#openTournamentWizardBtn")
      .addEventListener("click", () => {
        closeTournamentSwitcher();
        handleOpenTournamentWizard();
      });
    document.querySelector("#startNewTournamentBtn").addEventListener("click", () => {
      hideStartView();
      handleOpenTournamentWizard();
    });
    switcherButton.addEventListener("click", toggleTournamentSwitcher);
    document.querySelector("#showAllTournamentsBtn").addEventListener("click", showStartView);
    document.querySelector("#closeStartViewBtn").addEventListener("click", hideStartView);

    // Klick daneben und Escape schließen den Schalter.
    document.addEventListener("click", (event) => {
      if (switcherPanel.hidden) {
        return;
      }

      if (!switcherPanel.contains(event.target) && !switcherButton.contains(event.target)) {
        closeTournamentSwitcher();
      }
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !switcherPanel.hidden) {
        closeTournamentSwitcher();
      }
    });
    document
      .querySelector("#addRoundRobinTournamentBtn")
      .addEventListener("click", () => handleAddTournamentTab("roundRobin"));
    document
      .querySelector("#addTtRaceTournamentBtn")
      .addEventListener("click", () => handleAddTournamentTab("ttRace"));
    document
      .querySelector("#addTeamTournamentBtn")
      .addEventListener("click", () => handleAddTournamentTab("team"));
    document
      .querySelector("#addGroupsKnockoutTournamentBtn")
      .addEventListener("click", () => handleAddTournamentTab("groupsKnockout"));
    document.querySelector("#newTournamentBtn").addEventListener("click", handleClearCurrentTournament);
    document.querySelector("#resetResultsBtn").addEventListener("click", handleResetResults);
    document.querySelector("#loadExampleBtn").addEventListener("click", handleLoadExample);
    document.querySelector("#saveBackupBtn").addEventListener("click", handleSaveBackup);
    document.querySelector("#loadBackupBtn").addEventListener("click", handleLoadBackup);
    document.querySelector("#duplicateTournamentBtn").addEventListener("click", handleDuplicateTournament);
    document.querySelector("#saveTemplateBtn").addEventListener("click", handleSaveTemplate);
    document.querySelector("#loadTemplateBtn").addEventListener("click", handleLoadTemplate);
    document.querySelector("#deleteTemplateBtn").addEventListener("click", handleDeleteTemplate);
    backupFileInput.addEventListener("change", handleBackupFileSelection);
    clickTtFileInput.addEventListener("change", handleClickTtFileSelection);
    raceDayShell.addEventListener("click", (event) => {
      const druck = event.target.closest("[data-print-mode]");
      if (druck) {
        handlePrintDocument(druck.dataset.printMode);
        return;
      }
      handleRaceDayShellClick(event);
    });
    raceDayShell.addEventListener("change", handleRaceDayShellChange);
    tournamentWizardDialog.addEventListener("click", handleTournamentWizardBackdropClick);
    tournamentWizardContent.addEventListener("click", handleTournamentWizardClick);
    duplicateTournamentDialog.addEventListener("click", handleDuplicateTournamentDialogClick);
    tieDecisionDialog.addEventListener("click", handleTieDecisionDialogClick);
    tieDecisionContent.addEventListener("change", handleTieDecisionDialogChange);
    tournamentWizardContent.addEventListener("input", handleTournamentWizardInput);
    tournamentWizardContent.addEventListener("change", handleTournamentWizardInput);
    document
      .querySelector("#exportCurrentRoundCsvBtn")
      .addEventListener("click", handleExportCurrentRoundCsv);
    document
      .querySelector("#exportCurrentRoundXlsxBtn")
      .addEventListener("click", handleExportCurrentRoundXlsx);
    document.querySelector("#exportCsvBtn").addEventListener("click", handleExportCsv);
    document.querySelector("#exportXlsxBtn").addEventListener("click", handleExportXlsx);
    printDocumentButtons.addEventListener("click", (event) => {
      const knopf = event.target.closest("[data-print-mode]");
      if (knopf) handlePrintDocument(knopf.dataset.printMode);
    });
    printScopeSelect.addEventListener("change", () => {
      printSelection.scope = printScopeSelect.value;
      renderPrintRail();
    });
    window.addEventListener("beforeprint", preparePrintDocument);
    window.addEventListener("afterprint", cleanupPrintDocument);
    workspaceViewTabs.querySelectorAll("[data-workspace-view]").forEach((button) => {
      button.addEventListener("click", () => {
        activeWorkspaceView = ["input", "output", "live"].includes(button.dataset.workspaceView)
          ? button.dataset.workspaceView
          : "input";
        saveWorkspaceView();
        hideStartView();
        renderWorkspacePanels();
        renderAppTitle();
      });
    });
    liveView.addEventListener("click", handleLiveViewClick);
    liveView.addEventListener("change", handleLiveViewChange);
    // Vollbild ändert die Fläche, ohne dass etwas neu gezeichnet wird.
    document.addEventListener("fullscreenchange", updateLiveStageScale);
    window.addEventListener("resize", updateLiveStageScale);
    window.addEventListener("storage", handleWorkspaceStorageEvent);
  }

  function loadClickTtBridge() {
    if (!clickTtBridgePromise) {
      clickTtBridgePromise = import("./clickttBridge.js").then((module) => {
        clickTtBridgeModule = module;
        return module;
      });
    }

    return clickTtBridgePromise;
  }

  function loadTtRaceEngine() {
    if (!ttRaceEnginePromise) {
      ttRaceEnginePromise = import(`./ttRace.js?v=${DYNAMIC_MODULE_VERSION}`).then((module) => {
        ttRaceEngineModule = module;
        return module;
      });
    }

    return ttRaceEnginePromise;
  }

  function primeOptionalModules() {
    if (activeTournament?.clicktt?.rawXml) {
      loadClickTtBridge()
        .then(() => renderRaceDayShell())
        .catch((error) => console.warn("click-TT Adapter konnte nicht geladen werden.", error));
    }

    if (isTtRaceTournament()) {
      loadTtRaceEngine()
        .then(() => {
          renderRaceDayShell();
          renderLiveView();
        })
        .catch((error) => console.warn("TT-Race Engine konnte nicht geladen werden.", error));
    }
  }

  function cloneValue(value) {
    if (typeof structuredClone === "function") {
      return structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value));
  }

  function createTournamentId() {
    return `turnier-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }

  function createDoubleId() {
    return `doppel-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }

  function createStateForMode(modeId) {
    const state = createDefaultState();
    state.mode =
      modeId === "team"
        ? "team"
        : modeId === "groupsKnockout"
          ? "groupsKnockout"
          : "roundRobin";
    return state;
  }

  function createBttvTtRaceStarterState(tournamentName = BTTV_TT_RACE_NAME) {
    const state = createStateForMode("roundRobin");
    const cleanName = tournamentName.trim() || BTTV_TT_RACE_NAME;

    state.tabName = cleanName;
    state.tournamentName = cleanName;
    state.matchMode = "win3";
    state.schedule = {
      ...state.schedule,
      fieldCount: 8,
      startTime: "09:00",
      matchDurationMinutes: 18,
      breakMinutes: 2,
      fieldNames: Array.from({ length: 8 }, (_, index) => `Tisch ${index + 1}`)
    };
    state.roundRobin = {
      ...state.roundRobin,
      playerCount: 2,
      playerNames: ["Spieler 1", "Spieler 2"],
      playerStatuses: ["active", "active"],
      currentRound: 1,
      results: {},
      matchStatuses: {}
    };
    state.ttRace = {
      id: "bttv-tt-race",
      name: cleanName,
      settings: {
        maxRounds: 6,
        bttvRaceRules: true,
        regardTtrValues: true
      },
      players: [],
      rounds: []
    };
    return state;
  }

  function createTournamentRecord(seed, explicitId) {
    const normalizedState = normalizeState(seed || createDefaultState());
    upgradeLegacyTtRaceState(normalizedState);

    return {
      id: explicitId || createTournamentId(),
      ...normalizedState
    };
  }

  function upgradeLegacyTtRaceState(state) {
    if (state.ttRace || !looksLikeTtRaceState(state)) {
      return state;
    }

    const names = ensureLength(
      state.roundRobin?.playerNames ?? [],
      state.roundRobin?.playerCount ?? 0,
      "Teilnehmer"
    );
    const statuses = ensureLength(
      state.roundRobin?.playerStatuses ?? [],
      names.length,
      "active"
    );
    const hasNamedPlayers = names.some((name, index) => name && name !== `Teilnehmer ${index + 1}` && name !== `Spieler ${index + 1}`);

    state.mode = "roundRobin";
    state.matchMode = "win3";
    state.ttRace = {
      id: state.id || "bttv-tt-race",
      name: state.tournamentName || state.tabName || BTTV_TT_RACE_NAME,
      settings: {
        maxRounds: 6,
        bttvRaceRules: true,
        regardTtrValues: true
      },
      players: hasNamedPlayers
        ? names.map((name, index) => ({
            id: `legacy-player-${index + 1}`,
            name,
            seed: null,
            rating: null,
            status: PLAYER_STATUSES[statuses[index]] ? statuses[index] : "active"
          }))
        : [],
      rounds: []
    };
    state.roundRobin.results = {};
    state.roundRobin.setScores = {};
    state.roundRobin.matchStatuses = {};
    state.roundRobin.currentRound = 1;

    return state;
  }

  /**
   * Erkennt Altstände, die vor dem eigenen TT-Race-Modell angelegt wurden.
   *
   * Der Treffer stellt das Format um und leert dabei `roundRobin.results` —
   * deshalb greift er nur bei Ständen **ohne** erfasste Ergebnisse. Vorher
   * genügte „tt" und „race" irgendwo im Namen, und weil „tt" in Wettkampf,
   * Mittwoch, Platte und Dritte steckt, hat „Wettkampf gegen TTC Nachbar –
   * Race Cup" beim Laden still den ganzen Spielstand gelöscht.
   */
  function looksLikeTtRaceState(state) {
    if (hasStoredRoundRobinResults(state)) {
      return false;
    }
    // B111: Die dritte Klausel („irgendwo tt UND irgendwo race") machte die
    // beiden strengen davor wirkungslos und traf genau den Fehlalarm, den der
    // Kommentar oben beschreibt. Der Fund von Lauf 002 war damit nur halb
    // geschlossen: der Ergebnisverlust war verhindert, die stille
    // Formatumstellung auf TT-Race (samt erzwungenem win3) nicht.
    const name = `${state.tabName || ""} ${state.tournamentName || ""}`.toLowerCase();
    return name.includes("tt-race") || name.includes("tt race") || name.includes("ttrace");
  }

  function hasStoredRoundRobinResults(state) {
    const roundRobin = state?.roundRobin;
    if (!roundRobin) {
      return false;
    }
    return [roundRobin.results, roundRobin.setScores, roundRobin.matchStatuses].some(
      (bucket) => bucket && Object.keys(bucket).length > 0
    );
  }

  function createDefaultWorkspace() {
    const tournament = createTournamentRecord(createDefaultState());
    return {
      activeTournamentId: tournament.id,
      tournaments: [tournament]
    };
  }

  function createTournamentHistories() {
    const histories = new Map();
    workspace.tournaments.forEach((tournament) => {
      histories.set(tournament.id, { undo: [], redo: [] });
    });
    return histories;
  }

  function normalizeWorkspace(rawWorkspace) {
    if (rawWorkspace && Array.isArray(rawWorkspace.tournaments)) {
      const tournaments = rawWorkspace.tournaments.map((entry) =>
        createTournamentRecord(entry, entry?.id)
      );
      const safeTournaments = tournaments.length > 0 ? tournaments : createDefaultWorkspace().tournaments;
      const activeExists = safeTournaments.some((entry) => entry.id === rawWorkspace.activeTournamentId);

      return {
        activeTournamentId: activeExists ? rawWorkspace.activeTournamentId : safeTournaments[0].id,
        tournaments: safeTournaments
      };
    }

    if (rawWorkspace && (rawWorkspace.mode || rawWorkspace.roundRobin || rawWorkspace.team)) {
      const migratedTournament = createTournamentRecord(rawWorkspace, rawWorkspace.id);
      return {
        activeTournamentId: migratedTournament.id,
        tournaments: [migratedTournament]
      };
    }

    return createDefaultWorkspace();
  }

  function readStorage(key) {
    try {
      return window.localStorage.getItem(key);
    } catch (error) {
      console.warn("localStorage ist in diesem Browser-Kontext nicht verfügbar.", error);
      return null;
    }
  }

  function loadWorkspace() {
    const savedWorkspace =
      readStorage(STORAGE_KEY) || LEGACY_STORAGE_KEYS.map(readStorage).find(Boolean);
    if (!savedWorkspace) {
      return createDefaultWorkspace();
    }

    try {
      return normalizeWorkspace(JSON.parse(savedWorkspace));
    } catch (error) {
      // B112: Vorher startete die App hier still mit einem leeren
      // Arbeitsbereich — und der naechste Schreibvorgang ueberschrieb den
      // Schluessel, in dem der rettbare Altstand noch lag. Danach war er
      // endgueltig weg. Jetzt wird er zuerst zur Seite gelegt, und der Nutzer
      // erfaehrt, dass etwas nicht gelesen werden konnte.
      console.warn("Gespeicherter Turnierstand konnte nicht gelesen werden.", error);
      rescueUnreadableState(savedWorkspace, error);
      return createDefaultWorkspace();
    }
  }

  /**
   * Legt einen unlesbaren Stand unter einem eigenen Schluessel ab und merkt
   * sich, dass darueber berichtet werden muss. Schlaegt auch das fehl, bleibt
   * wenigstens die Meldung — geschwiegen wird nicht.
   */
  function rescueUnreadableState(rawValue, error) {
    let gerettet = false;
    try {
      window.localStorage.setItem(
        RESCUE_STORAGE_KEY,
        JSON.stringify({ savedAt: new Date().toISOString(), raw: String(rawValue ?? "") })
      );
      gerettet = true;
    } catch (rescueError) {
      console.warn("Unlesbarer Turnierstand konnte nicht gesichert werden.", rescueError);
    }

    unreadableStateNotice = {
      gerettet,
      schluessel: RESCUE_STORAGE_KEY,
      grund: String(error?.message || "unbekannter Lesefehler")
    };
  }

  function renderUnreadableStateAlert() {
    if (!unreadableStateNotice || !messageArea) {
      return;
    }

    messageArea.innerHTML = `
      <div class="storage-alert" role="alert" data-unreadable-state>
        <strong>Der gespeicherte Turnierstand konnte nicht gelesen werden.</strong>
        <p>Die App startet deshalb mit einem leeren Arbeitsbereich. ${
          unreadableStateNotice.gerettet
            ? `Der alte Inhalt wurde vorher unter <code>${escapeHtml(unreadableStateNotice.schluessel)}</code> gesichert und wird nicht überschrieben.`
            : "Der alte Inhalt konnte nicht gesichert werden — bitte nichts eintragen, bevor der Stand geprüft ist."
        } Grund: ${escapeHtml(unreadableStateNotice.grund)}.</p>
      </div>
    `;
  }

  function loadWorkspaceView() {
    const savedView = readStorage(VIEW_STORAGE_KEY) || readStorage(LEGACY_VIEW_STORAGE_KEY);
    return ["input", "output", "live"].includes(savedView) ? savedView : "input";
  }

  function decodeBase64UrlJson(value) {
    const base64 = String(value ?? "").replaceAll("-", "+").replaceAll("_", "/");
    const padded = `${base64}${"=".repeat((4 - (base64.length % 4)) % 4)}`;
    const binary = window.atob(padded);
    const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
    return JSON.parse(new TextDecoder().decode(bytes));
  }

  function applyWorkspaceSeedFromUrl() {
    const url = new URL(window.location.href);
    const encodedSeed = url.searchParams.get("workspaceSeed");
    if (!encodedSeed) {
      return "";
    }

    try {
      const parsedSeed = decodeBase64UrlJson(encodedSeed);
      const seededWorkspace =
        parsedSeed.workspace ||
        (parsedSeed.activeTournamentId && Array.isArray(parsedSeed.tournaments) ? parsedSeed : null);

      if (!seededWorkspace) {
        throw new Error("Workspace-Seed enthält keinen gültigen Turnierstand.");
      }

      workspace = normalizeWorkspace(seededWorkspace);
      activeWorkspaceView = ["input", "output", "live"].includes(parsedSeed.activeWorkspaceView)
        ? parsedSeed.activeWorkspaceView
        : "output";
      tournamentHistories = createTournamentHistories();
      syncDerivedState();
      saveWorkspace(parsedSeed.saveNote || "Turnierstand geladen");
      saveWorkspaceView();

      url.searchParams.delete("workspaceSeed");
      window.history.replaceState(null, "", `${url.pathname}${url.search}${url.hash}`);

      return parsedSeed.notice || "Turnierstand wurde geladen.";
    } catch (error) {
      console.warn("Workspace-Seed konnte nicht geladen werden.", error);
      return "Turnierstand aus Link konnte nicht geladen werden.";
    }
  }

  function loadPlayerStatsFontSize() {
    const savedSize =
      readStorage(PLAYER_STATS_FONT_SIZE_KEY) || readStorage(LEGACY_PLAYER_STATS_FONT_SIZE_KEY);
    return PLAYER_STATS_FONT_SIZES.includes(savedSize) ? savedSize : "medium";
  }

  function loadLiveRankingLimit() {
    return normalizeLiveRankingLimit(readStorage(LIVE_RANKING_LIMIT_KEY));
  }

  function normalizeLiveRankingLimit(value) {
    if (value === "all") {
      return "all";
    }

    const numericLimit = Number.parseInt(value, 10);
    // B072: Der Beamer zeigt den ganzen Stand. Wer auf Platz 4 steht, soll das
    // in der Halle sehen — Top 3 war die falsche Voreinstellung.
    return LIVE_RANKING_LIMIT_OPTIONS.includes(numericLimit) ? numericLimit : "all";
  }
  /**
   * Schreibt den Arbeitsbereich und sagt die Wahrheit darüber. Vorher stand
   * der Zeitstempel außerhalb des catch: nach einem fehlgeschlagenen Schreiben
   * meldete die Randspalte trotzdem „Ergebnis gespeichert um 13:24" — und die
   * einzige Warnung landete in einem versteckten Element, das niemand liest.
   * Am Turniertag ist das der teuerste denkbare Fehler.
   */
  function saveWorkspace(note) {
    // Ein anderes Fenster hat denselben Schluessel geschrieben. Frueher gewann
    // hier stumm der letzte Schreiber und die Korrektur aus dem anderen Fenster
    // war weg (B019). Jetzt bleibt der fremde Stand stehen und die Warnleiste
    // sagt, was zu tun ist.
    if (externalWorkspaceChange) {
      renderExternalWorkspaceChangeAlert();
      return false;
    }

    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(workspace));
    } catch (error) {
      console.warn("Turnierstand konnte nicht gespeichert werden.", error);
      reportStorageFailure(error);
      return false;
    }

    storageFailed = false;
    autosaveState.textContent = "Automatische Speicherung aktiv";
    const now = new Date();
    autosaveDetail.textContent = `${note} um ${now.toLocaleTimeString("de-DE", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    })}`;
    return true;
  }

  /**
   * Ein fehlgeschlagenes Speichern muss dort stehen, wo gearbeitet wird —
   * sichtbar, stehend, mit dem einzigen Ausweg daneben: Sicherung herunterladen.
   */
  function reportStorageFailure(error) {
    if (infoMessageTimeoutId) {
      window.clearTimeout(infoMessageTimeoutId);
      infoMessageTimeoutId = null;
    }
    storageFailed = true;
    autosaveState.textContent = "NICHT gespeichert";
    autosaveDetail.textContent = "Der Browser nimmt keine Daten mehr an — Sicherung herunterladen.";

    if (!messageArea) {
      return;
    }
    messageArea.innerHTML = `
      <div class="storage-alert" role="alert">
        <strong>Der Turnierstand wird nicht mehr gespeichert.</strong>
        <p>${escapeHtml(
          String(error && error.name === "QuotaExceededError"
            ? "Der Speicher dieses Browsers ist voll."
            : "Dieser Browser lässt kein Speichern zu (privates Fenster oder gesperrte Website-Daten).")
        )} Alles Weitere geht beim Schließen verloren. Lade jetzt eine Sicherung herunter und arbeite dort weiter.</p>
        <button class="primary-button" type="button" data-storage-alert="backup">Sicherung herunterladen</button>
      </div>
    `;
    messageArea.querySelectorAll("[data-storage-alert]").forEach((button) => {
      button.addEventListener("click", () => document.querySelector("#saveBackupBtn")?.click());
    });
  }

  /**
   * Zwei Fenster auf demselben Turnier: Wer zuletzt schrieb, gewann — die
   * Korrektur aus dem anderen Fenster verschwand still, und beide Fenster
   * meldeten „Ergebnis gespeichert um …" (B019). Ein `storage`-Ereignis
   * kommt nur aus fremden Fenstern, nie vom eigenen Schreiben; es ist damit
   * das ehrlichste Signal, das der Browser hergibt.
   */
  function handleWorkspaceStorageEvent(event) {
    if (!event) {
      return;
    }

    // key === null heißt: ein anderes Fenster hat den ganzen Speicher geleert.
    const touchesWorkspace =
      event.key === null || event.key === STORAGE_KEY || LEGACY_STORAGE_KEYS.includes(event.key);
    if (!touchesWorkspace || externalWorkspaceChange) {
      return;
    }

    // Ein zweites Fenster, das denselben Stand zurückschreibt (etwa direkt nach
    // dem Öffnen), ist kein Konflikt. Gesperrt wird nur bei echtem Unterschied.
    if (event.newValue && isSameWorkspaceContent(event.newValue)) {
      return;
    }

    externalWorkspaceChange = { at: new Date() };
    autosaveState.textContent = "NICHT gespeichert";
    autosaveDetail.textContent = "In einem anderen Fenster geändert — neu laden.";
    renderExternalWorkspaceChangeAlert();
    renderTournamentSheet();
  }

  function isSameWorkspaceContent(rawValue) {
    try {
      return computeContentStamp(JSON.parse(rawValue)) === computeContentStamp(workspace);
    } catch (error) {
      return false;
    }
  }

  function formatClockTime(value) {
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) {
      return "unbekannter Zeit";
    }
    return date.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
  }

  function renderExternalWorkspaceChangeAlert() {
    if (infoMessageTimeoutId) {
      window.clearTimeout(infoMessageTimeoutId);
      infoMessageTimeoutId = null;
    }
    if (!messageArea || !externalWorkspaceChange) {
      return;
    }

    messageArea.innerHTML = `
      <div class="storage-alert" role="alert" data-external-change>
        <strong>In einem anderen Fenster geändert — neu laden.</strong>
        <p>Um ${escapeHtml(formatClockTime(externalWorkspaceChange.at))} hat ein anderes Fenster
        denselben Turnierstand gespeichert. Dieses Fenster schreibt ab jetzt nichts mehr,
        damit die dortige Eingabe nicht überschrieben wird. Lade neu, um den aktuellen Stand
        zu sehen — oder sichere vorher, was du hier noch eingetragen hast.</p>
        <div class="storage-alert-actions">
          <button class="primary-button" type="button" data-external-change-action="reload">Neu laden</button>
          <button class="ghost-button" type="button" data-external-change-action="backup">Sicherung herunterladen</button>
        </div>
      </div>
    `;
    messageArea.querySelectorAll("[data-external-change-action]").forEach((button) => {
      button.addEventListener("click", () => {
        if (button.dataset.externalChangeAction === "reload") {
          window.location.reload();
          return;
        }
        handleSaveBackup();
      });
    });
  }

  function saveWorkspaceView() {
    try {
      window.localStorage.setItem(VIEW_STORAGE_KEY, activeWorkspaceView);
    } catch (error) {
      console.warn("Ansicht konnte nicht gespeichert werden.", error);
    }
  }

  function savePlayerStatsFontSize() {
    try {
      window.localStorage.setItem(PLAYER_STATS_FONT_SIZE_KEY, playerStatsFontSize);
    } catch (error) {
      console.warn("Schriftgröße für die Spielerstatistik konnte nicht gespeichert werden.", error);
    }
  }

  function saveLiveRankingLimit() {
    try {
      window.localStorage.setItem(LIVE_RANKING_LIMIT_KEY, String(liveRankingLimit));
    } catch (error) {
      console.warn("Live-Ranglistenlänge konnte nicht gespeichert werden.", error);
    }
  }

  function updateAutosaveStatus() {
    if (readStorage(STORAGE_KEY) || LEGACY_STORAGE_KEYS.some((key) => readStorage(key))) {
      autosaveDetail.textContent = "Vorheriger Stand wurde geladen.";
    }
  }

  function loadRoundCheckpoints() {
    const savedCheckpoints = readStorage(ROUND_CHECKPOINTS_KEY);
    if (!savedCheckpoints) {
      return [];
    }

    try {
      const parsed = JSON.parse(savedCheckpoints);
      const entries = Array.isArray(parsed) ? parsed : parsed?.checkpoints;
      if (!Array.isArray(entries)) {
        return [];
      }

      return entries
        .filter((entry) => entry?.id && entry?.checkpointKey && entry?.payload?.workspace)
        .slice(0, ROUND_CHECKPOINT_LIMIT);
    } catch (error) {
      // B117: Ein kaputter Eintrag liess das Panel „keine Checkpoints" melden —
      // als haette es nie welche gegeben. Die heruntergeladenen JSON-Dateien
      // lagen die ganze Zeit im Download-Ordner, nur sagte das niemand.
      console.warn("Gespeicherte Runden-Checkpoints konnten nicht gelesen werden.", error);
      roundCheckpointsUnreadable = true;
      return [];
    }
  }

  /**
   * Führt die Liste im Fenster mit der im Speicher zusammen. Ein zweites
   * Fenster darf die Sicherungen des ersten nicht wegschreiben, und ein
   * vorheriger Speicherfehler darf sie nicht verschlucken.
   */
  function mergeRoundCheckpointLists(...lists) {
    const seen = new Set();
    const merged = [];

    lists.flat().forEach((checkpoint) => {
      if (!checkpoint?.id || seen.has(checkpoint.id)) {
        return;
      }
      seen.add(checkpoint.id);
      merged.push(checkpoint);
    });

    return merged.sort((left, right) =>
      String(right.completedAt ?? "").localeCompare(String(left.completedAt ?? ""))
    );
  }

  /**
   * Vorher wurde bei einem Speicherfehler die Liste im Fenster geleert
   * (B054): Das Panel „Rundenstände" stand leer da, das nächste erfolgreiche
   * Schreiben legte die Leere über die alten Sicherungen, und weil die Liste
   * zugleich als Dedup-Grundlage diente, lud jede Korrektur die Runde erneut
   * herunter. Jetzt bleibt die Liste stehen; gespeichert wird zusammengeführt.
   */
  function saveRoundCheckpoints() {
    roundCheckpoints = mergeRoundCheckpointLists(roundCheckpoints, loadRoundCheckpoints()).slice(
      0,
      ROUND_CHECKPOINT_LIMIT
    );

    let checkpointsToSave = roundCheckpoints;

    while (checkpointsToSave.length > 0) {
      try {
        window.localStorage.setItem(
          ROUND_CHECKPOINTS_KEY,
          JSON.stringify({
            version: 1,
            checkpoints: checkpointsToSave
          })
        );
        // Passte nur ein Teil hinein, bleibt der Rest im Fenster sichtbar —
        // aber die App sagt es, statt es zu verschweigen.
        roundCheckpointStorageFailed = checkpointsToSave.length < roundCheckpoints.length;
        return !roundCheckpointStorageFailed;
      } catch (error) {
        checkpointsToSave = checkpointsToSave.slice(0, -1);
        if (checkpointsToSave.length === 0) {
          console.warn("Runden-Checkpoints konnten nicht gespeichert werden.", error);
        }
      }
    }

    roundCheckpointStorageFailed = true;
    return false;
  }

  /**
   * Serialisierung mit fester Schlüsselreihenfolge. Ohne sie wäre „derselbe
   * Stand" eine Frage der Eintragereihenfolge: Ein Ergebnis löschen und
   * identisch neu erfassen schiebt seinen Schlüssel ans Ende des Objekts, und
   * die Runde würde ein zweites Mal heruntergeladen, obwohl sich nichts
   * geändert hat. Reihenfolgen in Listen bleiben erhalten — dort tragen sie
   * Bedeutung.
   */
  function stableStringify(value) {
    if (Array.isArray(value)) {
      return `[${value.map(stableStringify).join(",")}]`;
    }
    if (value && typeof value === "object") {
      return `{${Object.keys(value)
        .sort()
        .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
        .join(",")}}`;
    }
    return JSON.stringify(value ?? null);
  }

  /**
   * Inhaltsstempel: Länge plus djb2-Streuwert. Kurz genug, dass er auch in
   * einen vollen Speicher passt, und genau genug, um „derselbe Stand" von
   * „neuer Stand" zu unterscheiden.
   */
  function computeContentStamp(value) {
    const text = typeof value === "string" ? value : stableStringify(value);
    let hash = 5381;
    for (let index = 0; index < text.length; index += 1) {
      hash = ((hash * 33) ^ text.charCodeAt(index)) >>> 0;
    }
    return `${text.length}-${hash.toString(36)}`;
  }

  function readRoundCheckpointStamps() {
    const stamps = new Map();
    const saved = readStorage(ROUND_CHECKPOINT_STAMPS_KEY);

    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const entries = parsed?.stamps && typeof parsed.stamps === "object" ? parsed.stamps : null;
        if (entries) {
          Object.entries(entries).forEach(([key, stamp]) => {
            if (key && typeof stamp === "string") {
              stamps.set(key, stamp);
            }
          });
        }
      } catch (error) {
        console.warn("Checkpoint-Stempel konnten nicht gelesen werden.", error);
      }
    }

    // Der Notnagel gewinnt: Was dieses Fenster bereits heruntergeladen hat,
    // wird nicht noch einmal geladen, auch wenn der Stempel nirgends landete.
    roundCheckpointStampFallback.forEach((stamp, key) => stamps.set(key, stamp));
    return stamps;
  }

  function writeRoundCheckpointStamps(stamps) {
    const entries = [...stamps.entries()].slice(-ROUND_CHECKPOINT_STAMP_LIMIT);

    try {
      window.localStorage.setItem(
        ROUND_CHECKPOINT_STAMPS_KEY,
        JSON.stringify({ version: 1, stamps: Object.fromEntries(entries) })
      );
      return true;
    } catch (error) {
      console.warn("Checkpoint-Stempel konnte nicht gespeichert werden.", error);
      return false;
    }
  }

  function rememberRoundCheckpointStamp(checkpointKey, stamp) {
    // Erst der Notnagel, dann der Speicher: Auch wenn setItem gleich wirft,
    // weiß dieses Fenster ab hier, dass der Stand gesichert ist.
    roundCheckpointStampFallback.set(checkpointKey, stamp);
    const stamps = readRoundCheckpointStamps();
    stamps.set(checkpointKey, stamp);
    return writeRoundCheckpointStamps(stamps);
  }

  /**
   * Altstände kennen den Stempelschlüssel noch nicht. Ohne dieses Nachtragen
   * würde die erste Korrektur nach dem Update jede bereits gesicherte Runde
   * erneut herunterladen.
   */
  function seedRoundCheckpointStamps() {
    const stamps = readRoundCheckpointStamps();
    let added = false;

    roundCheckpoints.forEach((checkpoint) => {
      if (!checkpoint?.checkpointKey || checkpoint.roundKey === "safety") {
        return;
      }
      if (stamps.has(checkpoint.checkpointKey)) {
        return;
      }
      stamps.set(checkpoint.checkpointKey, computeContentStamp(checkpoint.payload?.workspace));
      added = true;
    });

    if (added) {
      writeRoundCheckpointStamps(stamps);
    }
  }

  function createTemplateId() {
    return `vorlage-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }

  function loadTournamentTemplates() {
    const savedTemplates = readStorage(TEMPLATE_STORAGE_KEY);
    if (!savedTemplates) {
      return [];
    }

    try {
      const parsed = JSON.parse(savedTemplates);
      const entries = Array.isArray(parsed) ? parsed : parsed?.templates;
      if (!Array.isArray(entries)) {
        return [];
      }

      return entries.map(normalizeTournamentTemplate).filter(Boolean);
    } catch (error) {
      console.warn("Gespeicherte Turnier-Vorlagen konnten nicht gelesen werden.", error);
      return [];
    }
  }

  function normalizeTournamentTemplate(entry) {
    if (!entry?.state) {
      return null;
    }

    try {
      const state = createReusableTournamentState(entry.state, Boolean(entry.includeResults));
      const name = String(entry.name || state.tabName || state.tournamentName || "Turnier-Vorlage").trim();

      return {
        id: entry.id || createTemplateId(),
        name: name || "Turnier-Vorlage",
        createdAt: entry.createdAt || new Date().toISOString(),
        updatedAt: entry.updatedAt || entry.createdAt || new Date().toISOString(),
        includeResults: Boolean(entry.includeResults),
        state
      };
    } catch (error) {
      console.warn("Eine Turnier-Vorlage wurde übersprungen.", error);
      return null;
    }
  }

  function saveTournamentTemplates() {
    try {
      window.localStorage.setItem(TEMPLATE_STORAGE_KEY, JSON.stringify(tournamentTemplates));
      return true;
    } catch (error) {
      console.warn("Turnier-Vorlagen konnten nicht gespeichert werden.", error);
      showInfo("Vorlagen konnten in diesem Browser-Kontext nicht gespeichert werden.");
      return false;
    }
  }

  function createReusableTournamentState(tournament, includeResults) {
    const state = normalizeState(cloneValue(tournament));
    delete state.id;

    if (!includeResults) {
      clearTournamentResults(state);
    }

    return state;
  }

  function clearTournamentResults(tournament) {
    tournament.roundRobin.results = {};
    tournament.roundRobin.setScores = {};
    tournament.roundRobin.matchStatuses = {};
    tournament.roundRobin.currentRound = 1;
    tournament.team.results = {};
    tournament.team.setScores = {};
    tournament.team.matchStatuses = {};
    tournament.team.doubleResults = {};
    tournament.team.doubleSetScores = {};
    tournament.team.doubleMatchStatuses = {};
    tournament.team.currentRound = 1;
    tournament.team.currentDoubleRound = 1;
    tournament.groupsKnockout.groupResults = {};
    tournament.groupsKnockout.groupSetScores = {};
    tournament.groupsKnockout.knockoutResults = {};
    tournament.groupsKnockout.knockoutSetScores = {};
    tournament.groupsKnockout.currentGroupRound = 1;
    tournament.groupsKnockout.currentKnockoutRound = 1;
    if (tournament.ttRace) {
      tournament.ttRace.rounds = [];
    }
    if (tournament.clicktt?.setScores) {
      tournament.clicktt.setScores = {};
    }
    return tournament;
  }

  function createTournamentFromReusableState(state) {
    const seed = cloneValue(state);
    delete seed.id;
    return createTournamentRecord(seed);
  }

  /**
   * Vorlagen und Rundenstände liegen in eigenen localStorage-Schlüsseln. Das
   * Backup behauptete früher, alles zu sichern, und ließ beide draußen (B028) —
   * wer nach einem Browserwechsel das Backup lud, stand ohne Vorlagen und ohne
   * Wiederherstellungspunkte da.
   *
   * Rundenstände tragen selbst ein vollständiges Workspace-Backup in sich.
   * Deshalb sind beide Felder abschaltbar: Ein Checkpoint-Payload darf keine
   * Checkpoints enthalten, sonst wächst jede Sicherung über die vorige hinaus.
   */
  function buildWorkspaceBackupPayload(workspaceSnapshot = workspace, options = {}) {
    const includeTemplates = options.includeTemplates === true;
    const includeRoundCheckpoints = options.includeRoundCheckpoints === true;

    return {
      kind: BACKUP_KIND,
      version: BACKUP_FILE_VERSION,
      exportedAt: new Date().toISOString(),
      workspace: cloneValue(workspaceSnapshot),
      preferences: {
        activeWorkspaceView,
        playerStatsFontSize,
        liveRankingLimit
      },
      templates: includeTemplates
        ? { included: true, entries: cloneValue(tournamentTemplates) }
        : {
            included: false,
            note: "Vorlagen stehen nur in der vollständigen Sicherung, nicht in einem Rundenstand."
          },
      roundCheckpoints: includeRoundCheckpoints
        ? { included: true, entries: cloneValue(roundCheckpoints) }
        : {
            included: false,
            note: "Rundenstände stehen nur in der vollständigen Sicherung."
          },
      summary: {
        tournamentCount: workspaceSnapshot.tournaments.length,
        tournamentLabels: workspaceSnapshot.tournaments.map((tournament, index) =>
          getTournamentLabel(tournament, index)
        ),
        templateCount: includeTemplates ? tournamentTemplates.length : 0,
        roundCheckpointCount: includeRoundCheckpoints ? roundCheckpoints.length : 0
      }
    };
  }

  /** „1 Turnier, 2 Vorlagen, 5 Rundenstände" — und nichts davon geraten. */
  function describeBackupContents(counts) {
    const parts = [
      `${counts.tournamentCount} Turnier${counts.tournamentCount === 1 ? "" : "e"}`
    ];
    if (counts.templateCount > 0) {
      parts.push(`${counts.templateCount} Vorlage${counts.templateCount === 1 ? "" : "n"}`);
    }
    if (counts.roundCheckpointCount > 0) {
      parts.push(
        counts.roundCheckpointCount === 1
          ? "1 Rundenstand"
          : `${counts.roundCheckpointCount} Rundenstände`
      );
    }
    return parts.join(", ");
  }

  function buildWorkspaceBackupFilename(payload, workspaceSnapshot = workspace) {
    const primaryLabel =
      workspaceSnapshot.tournaments.length === 1
        ? getTournamentLabel(activeTournament, getActiveTournamentIndex())
        : `turnier_dashboard_${getTournamentLabel(activeTournament, getActiveTournamentIndex())}_${workspaceSnapshot.tournaments.length}_turniere`;
    return `${sanitizeFilename(primaryLabel)}_backup_${formatBackupTimestamp(payload.exportedAt)}.json`;
  }

  function buildRoundCheckpointBackupFilename(checkpointEvent, exportedAt) {
    return `${sanitizeFilename(`${checkpointEvent.tournamentLabel}_${checkpointEvent.roundLabel}`)}_auto_backup_${formatBackupTimestamp(exportedAt)}.json`;
  }

  function formatBackupTimestamp(value) {
    const date = value instanceof Date ? value : new Date(value);
    const safeDate = Number.isNaN(date.getTime()) ? new Date() : date;
    const pad = (number) => String(number).padStart(2, "0");

    return [
      safeDate.getFullYear(),
      pad(safeDate.getMonth() + 1),
      pad(safeDate.getDate())
    ].join("-") +
      "_" +
      [pad(safeDate.getHours()), pad(safeDate.getMinutes()), pad(safeDate.getSeconds())].join("-");
  }

  function handleSaveBackup() {
    const payload = buildWorkspaceBackupPayload(workspace, {
      includeTemplates: true,
      includeRoundCheckpoints: true
    });
    const filename = buildWorkspaceBackupFilename(payload);
    const json = JSON.stringify(payload, null, 2);
    downloadBlob(filename, new Blob([json], { type: "application/json;charset=utf-8" }));
    showBackupInfo(`Backup gespeichert: ${describeBackupContents(payload.summary)} als JSON-Datei heruntergeladen.`);
  }

  /**
   * Die Sicherung ist der Ausweg aus beiden Sperrzuständen — ihre Bestätigung
   * muss auch dann sichtbar sein, wenn der Speicher blockiert oder ein anderes
   * Fenster übernommen hat. Die stehende Warnung kommt danach zurück.
   */
  function showBackupInfo(message) {
    if (!storageFailed && !externalWorkspaceChange) {
      showInfo(message);
      return;
    }

    const alertBox = messageArea?.querySelector(".storage-alert");
    if (!alertBox) {
      return;
    }
    // Eine Zeile, nicht eine je Klick.
    const note = alertBox.querySelector(".storage-alert-note") || document.createElement("p");
    note.className = "storage-alert-note";
    note.textContent = message;
    alertBox.append(note);
  }

  function handleLoadBackup() {
    backupFileInput.value = "";
    backupFileInput.click();
  }

  async function handleBackupFileSelection(event) {
    const file = event.target.files?.[0];
    backupFileInput.value = "";

    if (!file) {
      return;
    }

    try {
      const parsedBackup = parseWorkspaceBackup(await file.text());
      const shouldLoad = window.confirm(buildBackupLoadConfirmation(file.name, parsedBackup));

      if (!shouldLoad) {
        showInfo("Backup wurde nicht geladen.");
        return;
      }

      applyWorkspaceBackup(parsedBackup);
      showInfo(`Backup geladen. Wiederhergestellt: ${describeBackupContents(parsedBackup.summary)}.`);
    } catch (error) {
      console.error("Backup konnte nicht geladen werden.", error);
      showInfo("Backup konnte nicht geladen werden. Bitte eine gültige JSON-Sicherungsdatei wählen.");
    }
  }

  function parseWorkspaceBackup(rawText) {
    const parsed = JSON.parse(rawText);

    if ([BACKUP_KIND, LEGACY_BACKUP_KIND].includes(parsed?.kind) && parsed?.workspace) {
      const normalizedWorkspace = normalizeWorkspace(parsed.workspace);
      // Ältere Sicherungen kennen weder `templates.entries` noch
      // `roundCheckpoints` — sie bleiben ohne Zutun ladbar, nur eben leer.
      const templates = parseBackupTemplates(parsed);
      const roundCheckpoints = parseBackupRoundCheckpoints(parsed);

      return {
        workspace: normalizedWorkspace,
        preferences: {
          activeWorkspaceView: parsed.preferences?.activeWorkspaceView,
          playerStatsFontSize: parsed.preferences?.playerStatsFontSize,
          liveRankingLimit: parsed.preferences?.liveRankingLimit
        },
        templates,
        roundCheckpoints,
        exportedAt: parsed.exportedAt,
        // B118: Die Zusammenfassung wurde bisher aus dem `summary`-Feld der
        // Datei genommen. Der Dialog, der über das Überschreiben ALLER Daten
        // entscheidet, konnte damit etwas anderes nennen, als tatsächlich
        // geladen wird — bei fremden oder von Hand geänderten Dateien. Gezählt
        // wird jetzt am normalisierten Inhalt, so wie es der Legacy-Zweig
        // darunter immer schon tat.
        summary: {
          tournamentCount: normalizedWorkspace.tournaments.length,
          tournamentLabels: normalizedWorkspace.tournaments.map((tournament, index) =>
            getTournamentLabel(tournament, index)
          ),
          templateCount: templates ? templates.length : 0,
          roundCheckpointCount: roundCheckpoints ? roundCheckpoints.length : 0
        }
      };
    }

    if (parsed?.activeTournamentId && Array.isArray(parsed?.tournaments)) {
      const normalizedWorkspace = normalizeWorkspace(parsed);
      return {
        workspace: normalizedWorkspace,
        preferences: {},
        templates: null,
        roundCheckpoints: null,
        exportedAt: null,
        summary: {
          tournamentCount: normalizedWorkspace.tournaments.length,
          tournamentLabels: normalizedWorkspace.tournaments.map((tournament, index) =>
            getTournamentLabel(tournament, index)
          ),
          templateCount: 0,
          roundCheckpointCount: 0
        }
      };
    }

    throw new Error("Ungültiges Backup-Format");
  }

  /** `null` heißt „im Backup nicht enthalten" und lässt den Bestand stehen. */
  function parseBackupTemplates(parsed) {
    const entries = parsed?.templates?.entries;
    if (!Array.isArray(entries)) {
      return null;
    }
    return entries.map(normalizeTournamentTemplate).filter(Boolean);
  }

  function parseBackupRoundCheckpoints(parsed) {
    const entries = parsed?.roundCheckpoints?.entries;
    if (!Array.isArray(entries)) {
      return null;
    }
    return entries
      .filter((entry) => entry?.id && entry?.checkpointKey && entry?.payload?.workspace)
      .slice(0, ROUND_CHECKPOINT_LIMIT);
  }

  function buildBackupLoadConfirmation(filename, parsedBackup) {
    const exportedAtLabel = parsedBackup.exportedAt
      ? new Date(parsedBackup.exportedAt).toLocaleString("de-DE")
      : "unbekannt";
    const previewLabels = parsedBackup.summary.tournamentLabels.slice(0, 5);
    const remainingCount =
      parsedBackup.summary.tournamentLabels.length - previewLabels.length;
    const tournamentPreview = previewLabels.length
      ? `\n\nTurniere:\n- ${previewLabels.join("\n- ")}${remainingCount > 0 ? `\n- +${remainingCount} weitere` : ""}`
      : "";

    const extras = [];
    if (parsedBackup.templates) {
      extras.push(
        `${parsedBackup.templates.length} Vorlage${parsedBackup.templates.length === 1 ? "" : "n"} (ersetzen die vorhandenen)`
      );
    }
    if (parsedBackup.roundCheckpoints) {
      extras.push(
        parsedBackup.roundCheckpoints.length === 1
          ? "1 Rundenstand (kommt zu den vorhandenen hinzu)"
          : `${parsedBackup.roundCheckpoints.length} Rundenstände (kommen zu den vorhandenen hinzu)`
      );
    }

    return (
      `${filename} laden?\n\n` +
      `Gesichert am: ${exportedAtLabel}\n` +
      `Turniere im Backup: ${parsedBackup.summary.tournamentCount}` +
      `${tournamentPreview}\n\n` +
      `Enthalten: ${describeBackupContents(parsedBackup.summary)}\n` +
      (extras.length ? `${extras.join("\n")}\n` : "Vorlagen und Rundenstände sind nicht enthalten und bleiben unverändert.\n") +
      "\nDer aktuelle Stand im Dashboard wird durch dieses Backup ersetzt."
    );
  }

  function applyWorkspaceBackup(parsedBackup) {
    workspace = normalizeWorkspace(parsedBackup.workspace);
    if (Array.isArray(parsedBackup.templates)) {
      tournamentTemplates = parsedBackup.templates;
      saveTournamentTemplates();
    }
    if (Array.isArray(parsedBackup.roundCheckpoints)) {
      roundCheckpoints = parsedBackup.roundCheckpoints;
      saveRoundCheckpoints();
      seedRoundCheckpointStamps();
    }
    activeWorkspaceView =
      ["input", "output", "live"].includes(parsedBackup.preferences.activeWorkspaceView)
        ? parsedBackup.preferences.activeWorkspaceView
        : "input";
    playerStatsFontSize = PLAYER_STATS_FONT_SIZES.includes(
      parsedBackup.preferences.playerStatsFontSize
    )
      ? parsedBackup.preferences.playerStatsFontSize
      : "medium";
    liveRankingLimit = normalizeLiveRankingLimit(parsedBackup.preferences.liveRankingLimit);
    tournamentHistories = createTournamentHistories();
    syncDerivedState();
    renderAll();
    saveWorkspaceView();
    savePlayerStatsFontSize();
    saveLiveRankingLimit();
    saveWorkspace("Backup geladen");
  }

  function handleDownloadSelectedRoundCheckpoint(event) {
    const checkpoint = getSelectedRoundCheckpoint(event?.currentTarget);
    if (!checkpoint) {
      showInfo("Kein Runden-Checkpoint ausgewählt.");
      return;
    }

    downloadRoundCheckpoint(checkpoint);
    showInfo(`${checkpoint.roundLabel} wurde erneut als JSON-Backup heruntergeladen.`);
  }

  /**
   * Wiederherstellen ist der gefährlichste Knopf der App: Er wirft alles weg,
   * was seit dem Checkpoint erfasst wurde, und leert dabei den Undo-Verlauf
   * (B055). Deshalb liegt vorher ein eigener Checkpoint des jetzigen Standes
   * in der Liste — und der Bestätigungstext sagt konkret, was ersetzt wird.
   */
  function handleRestoreSelectedRoundCheckpoint(event) {
    const checkpoint = getSelectedRoundCheckpoint(event?.currentTarget);
    if (!checkpoint) {
      showInfo("Kein Runden-Checkpoint ausgewählt.");
      return;
    }

    const safetyLabel = `Vor Wiederherstellung ${formatClockTime(new Date())}`;
    const shouldRestore = window.confirm(
      `${checkpoint.roundLabel} laden?\n\n` +
        `Gesichert am: ${formatDateTime(checkpoint.completedAt)}\n\n` +
        `Ersetzt wird: ${describeCurrentWorkspaceForRestore()}\n` +
        "Alles, was seit diesem Checkpoint erfasst wurde, ist danach nicht mehr im Blatt — " +
        `auch „Rückgängig“ holt es nicht zurück.\n\n` +
        `Vorher wird der jetzige Stand als „${safetyLabel}“ in die Rundenstände gelegt.`
    );

    if (!shouldRestore) {
      showInfo("Checkpoint wurde nicht geladen.");
      return;
    }

    const safetyStored = storeRoundCheckpoint(safetyLabel, { quiet: true });

    applyWorkspaceBackup({
      workspace: checkpoint.payload.workspace,
      preferences: checkpoint.payload.preferences || {},
      templates: null,
      roundCheckpoints: null,
      exportedAt: checkpoint.payload.exportedAt,
      summary: checkpoint.payload.summary || {
        tournamentCount: checkpoint.payload.workspace?.tournaments?.length ?? 0,
        tournamentLabels: []
      }
    });
    showInfo(
      safetyStored
        ? `${checkpoint.roundLabel} wiederhergestellt. Der vorherige Stand liegt als Sicherung „${safetyLabel}“ in den Rundenständen.`
        : `${checkpoint.roundLabel} wiederhergestellt. Achtung: Die Sicherung „${safetyLabel}“ konnte nicht abgelegt werden.`
    );
  }

  /** Kurzform des Standes, der gleich ersetzt wird — Turnier, Runde, Spiele. */
  function describeCurrentWorkspaceForRestore() {
    const label = getTournamentLabel(activeTournament, getActiveTournamentIndex());
    try {
      const state = describeTournamentState(activeTournament);
      return `${label} — ${state.round || ""}${state.round && state.progress ? ", " : ""}${state.progress || ""}`
        .replace(/\s+/g, " ")
        .replace(/[—,]\s*$/, "")
        .trim();
    } catch (error) {
      console.warn("Aktueller Stand konnte nicht beschrieben werden.", error);
      return label;
    }
  }

  function downloadRoundCheckpoint(checkpoint) {
    const json = JSON.stringify(checkpoint.payload, null, 2);
    downloadBlob(
      checkpoint.backupFilename,
      new Blob([json], { type: "application/json;charset=utf-8" })
    );
  }

  function getActiveTournament() {
    return (
      workspace.tournaments.find((entry) => entry.id === workspace.activeTournamentId) ||
      workspace.tournaments[0]
    );
  }

  function syncDerivedState() {
    activeTournament = getActiveTournament();
    analysis = computeAnalysis();
    syncTournamentHistories();
  }

  function syncTournamentHistories() {
    const tournamentIds = new Set(workspace.tournaments.map((entry) => entry.id));

    tournamentHistories.forEach((_, tournamentId) => {
      if (!tournamentIds.has(tournamentId)) {
        tournamentHistories.delete(tournamentId);
      }
    });

    workspace.tournaments.forEach((tournament) => {
      if (!tournamentHistories.has(tournament.id)) {
        tournamentHistories.set(tournament.id, { undo: [], redo: [] });
      }
    });
  }

  function computeAnalysis() {
    if (activeTournament.mode === "team") {
      return withMatchSchedule(analyzeTeamCompetition({
        ...activeTournament.team,
        matchMode: activeTournament.matchMode,
        scoring: activeTournament.scoring,
        tournamentName: activeTournament.tournamentName
      }));
    }

    if (activeTournament.mode === "groupsKnockout") {
      return analyzeGroupsKnockout({
        ...activeTournament.groupsKnockout,
        matchMode: activeTournament.matchMode,
        scoring: activeTournament.scoring,
        tournamentName: activeTournament.tournamentName
      });
    }

    return withMatchSchedule(analyzeRoundRobin({
      ...activeTournament.roundRobin,
      matchMode: activeTournament.matchMode,
      scoring: activeTournament.scoring,
      tournamentName: activeTournament.tournamentName
    }));
  }

  function withMatchSchedule(analysisResult) {
    if (!activeTournament.schedule?.enabled) {
      return analysisResult;
    }

    return {
      ...analysisResult,
      schedule: buildMatchSchedule(analysisResult, activeTournament.schedule)
    };
  }

  function updateWorkspace(recipe, saveNote, options = {}) {
    const { clearRedo = false } = options;
    const previousWorkspace = cloneValue(workspace);
    const draft = cloneValue(workspace);
    recipe(draft);
    const nextWorkspace = normalizeWorkspace(draft);
    if (isSameWorkspace(previousWorkspace, nextWorkspace)) {
      return;
    }

    if (clearRedo) {
      clearAllRedoHistories();
    }
    workspace = nextWorkspace;
    syncDerivedState();
    renderAll();
    saveWorkspace(saveNote);
  }

  function updateTournamentById(tournamentId, recipe, saveNote, options = {}) {
    const { trackHistory = true, clearRedo = trackHistory, checkRoundBackups = false } = options;
    const sourceTournament = workspace.tournaments.find((entry) => entry.id === tournamentId);
    if (!sourceTournament) {
      return;
    }

    const previousWorkspace = cloneValue(workspace);
    const previousTournament = cloneValue(sourceTournament);
    const draft = cloneValue(workspace);
    const draftTournament = draft.tournaments.find((entry) => entry.id === tournamentId);

    if (!draftTournament) {
      return;
    }

    recipe(draftTournament, draft);

    const nextWorkspace = normalizeWorkspace(draft);
    const nextTournament = nextWorkspace.tournaments.find((entry) => entry.id === tournamentId);
    if (!nextTournament || isSameWorkspace(previousWorkspace, nextWorkspace)) {
      return;
    }

    if (trackHistory && !isSameWorkspace(previousTournament, nextTournament)) {
      pushTournamentHistorySnapshot(tournamentId, "undo", previousTournament, saveNote);
    }
    if (clearRedo) {
      clearTournamentRedoHistory(tournamentId);
    }

    workspace = nextWorkspace;
    syncDerivedState();
    if (checkRoundBackups) {
      const tournamentIndex = nextWorkspace.tournaments.findIndex((entry) => entry.id === tournamentId);
      createAutomaticRoundCheckpoints(previousTournament, nextTournament, tournamentIndex);
    }
    renderAll();
    saveWorkspace(saveNote);
  }

  function updateActiveTournament(recipe, saveNote, options) {
    const tournamentId = workspace.activeTournamentId;
    updateTournamentById(tournamentId, recipe, saveNote, options);
  }

  function renderAll() {
    renderAppTitle();
    renderWorkspacePanels();
    renderTemplateControls();
    renderRoundCheckpointPanel();
    renderRoundBackupStatus();
    renderTabs();
    renderRaceDayShell();
    renderConfig();
    renderTournamentSheet();
    renderLiveView();
  }

  /**
   * B048: Die Knöpfe stehen in zwei Behältern — im Blatt und in der Randspalte.
   * Wer nur das Blatt abfragt, lässt die Randspalte für immer klickbar und
   * stumm: ein Leerklick tat nichts, ein Klick nach dem Namensimport nahm alle
   * acht Namen zurück, ohne dass irgendetwas davon erzählte.
   */
  function renderHistoryButtons() {
    const history = getTournamentHistory(activeTournament?.id);
    const availableUndoSteps = history.undo.length;
    const availableRedoSteps = history.redo.length;
    [tournamentSheet, sheetMeta].forEach((container) => {
      container?.querySelectorAll("[data-history-action]").forEach((button) => {
        const isUndo = button.dataset.historyAction === "undo";
        const availableSteps = isUndo ? availableUndoSteps : availableRedoSteps;
        const nextNote = (isUndo ? history.undo : history.redo)[availableSteps - 1]?.note || "";
        button.disabled = availableSteps === 0;
        button.setAttribute("aria-disabled", availableSteps === 0 ? "true" : "false");
        button.title = isUndo
          ? availableSteps > 0
            ? `Zurücknehmen: ${nextNote} (${availableSteps} von ${UNDO_LIMIT} Schritten)`
            : "Noch nichts geändert — es gibt nichts zurückzunehmen"
          : availableSteps > 0
            ? `Wiederholen: ${nextNote} (${availableSteps} von ${UNDO_LIMIT} Schritten)`
            : "Noch nichts zurückgenommen — es gibt nichts zu wiederholen";
      });
    });
  }

  function getTournamentHistory(tournamentId) {
    if (!tournamentId) {
      return { undo: [], redo: [] };
    }

    if (!tournamentHistories.has(tournamentId)) {
      tournamentHistories.set(tournamentId, { undo: [], redo: [] });
    }

    return tournamentHistories.get(tournamentId);
  }

  /**
   * Jeder Schritt trägt seinen Namen mit („Ergebnis übernommen"). Ohne ihn
   * konnte weder der Tooltip noch die Meldung nach dem Klick sagen, WAS
   * zurückgenommen wird — der Screen behielt stattdessen die alte
   * Erfolgsmeldung und log damit (B048).
   */
  function pushTournamentHistorySnapshot(tournamentId, stackKey, snapshot, note = "") {
    const history = getTournamentHistory(tournamentId);
    history[stackKey].push({ tournament: cloneValue(snapshot), note: String(note || "Änderung") });
    if (history[stackKey].length > UNDO_LIMIT) {
      history[stackKey] = history[stackKey].slice(-UNDO_LIMIT);
    }
  }

  function clearTournamentRedoHistory(tournamentId) {
    const history = getTournamentHistory(tournamentId);
    history.redo = [];
  }

  function clearAllRedoHistories() {
    tournamentHistories.forEach((history) => {
      history.redo = [];
    });
  }

  function restoreTournamentSnapshot(tournamentId, snapshot, saveNote) {
    updateTournamentById(
      tournamentId,
      (tournament) => {
        const restoredTournament = createTournamentRecord(cloneValue(snapshot), tournamentId);
        Object.keys(tournament).forEach((key) => {
          delete tournament[key];
        });
        Object.assign(tournament, restoredTournament);
      },
      saveNote,
      { trackHistory: false, clearRedo: false }
    );
  }

  function isSameWorkspace(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
  }

  function collectCompletedRoundEvents(tournament, tournamentIndex = 0) {
    if (!tournament) {
      return [];
    }

    const tournamentLabel = getTournamentLabel(tournament, tournamentIndex);
    const base = {
      tournamentId: tournament.id,
      tournamentLabel,
      tournamentName: tournament.tournamentName || tournamentLabel,
      mode: isTtRaceTournament(tournament) ? "ttRace" : tournament.mode
    };

    if (isTtRaceTournament(tournament)) {
      const rounds = Array.isArray(tournament.ttRace?.rounds) ? tournament.ttRace.rounds : [];
      return rounds
        .filter((round) => Array.isArray(round.matches) && round.matches.length > 0 && isTtRaceRoundComplete(round))
        .map((round) => createCompletedRoundEvent(base, `tt-race-runde-${round.roundNumber}`, `Schweizer Runde ${round.roundNumber}`));
    }

    if (tournament.mode === "team") {
      const teamAnalysis = analyzeTeamCompetition({
        ...tournament.team,
        matchMode: tournament.matchMode,
        scoring: tournament.scoring,
        tournamentName: tournament.tournamentName
      });
      return [
        ...collectCompletedPairingRounds(
          base,
          teamAnalysis.rounds,
          "team-einzel",
          (round) => `Einzelrunde ${round.roundNumber}`
        ),
        ...collectCompletedPairingRounds(
          base,
          teamAnalysis.doubleRounds,
          "team-doppel",
          (round) => `Doppelrunde ${round.roundNumber}`
        )
      ];
    }

    if (tournament.mode === "groupsKnockout") {
      const groupsAnalysis = analyzeGroupsKnockout({
        ...tournament.groupsKnockout,
        matchMode: tournament.matchMode,
        scoring: tournament.scoring,
        tournamentName: tournament.tournamentName
      });
      return [
        ...collectCompletedPairingRounds(
          base,
          groupsAnalysis.groupRoundSchedule,
          "gruppenphase",
          (round) => `Gruppenrunde ${round.roundNumber}`
        ),
        ...collectCompletedKnockoutRounds(base, groupsAnalysis)
      ];
    }

    const roundRobinAnalysis = analyzeRoundRobin({
      ...tournament.roundRobin,
      matchMode: tournament.matchMode,
      scoring: tournament.scoring,
      tournamentName: tournament.tournamentName
    });
    return collectCompletedPairingRounds(
      base,
      roundRobinAnalysis.rounds,
      "jeder-gegen-jeden",
      (round) => `Runde ${round.roundNumber}`
    );
  }

  function collectCompletedPairingRounds(base, rounds, keyPrefix, getLabel) {
    return (rounds || [])
      .filter((round) => isPairingRoundComplete(round))
      .map((round) =>
        createCompletedRoundEvent(
          base,
          `${keyPrefix}-runde-${round.roundNumber}`,
          getLabel(round)
        )
      );
  }

  function collectCompletedKnockoutRounds(base, groupsAnalysis) {
    const knockoutRoundEvents = (groupsAnalysis.knockoutRounds || [])
      .filter((round) => {
        const scheduledPairings = (round.pairings || []).filter((pairing) => !pairing.isBye);
        return scheduledPairings.length > 0 && scheduledPairings.every((pairing) => pairing.isComplete);
      })
      .map((round) =>
        createCompletedRoundEvent(
          base,
          `ko-runde-${round.roundNumber}`,
          round.roundName || `KO-Runde ${round.roundNumber}`
        )
      );

    const placementEvents = (groupsAnalysis.placementMatches || [])
      .filter((match) => match.isReady && match.isComplete)
      .map((match) =>
        createCompletedRoundEvent(
          base,
          "ko-platzierung",
          match.roundName || "Platzierungsspiel"
        )
      );

    return [...knockoutRoundEvents, ...placementEvents];
  }

  function isPairingRoundComplete(round) {
    const pairings = round?.pairings || [];
    return pairings.length > 0 && pairings.every((pairing) => isPairingComplete(pairing));
  }

  function isPairingComplete(pairing) {
    if (!pairing) {
      return false;
    }
    if (pairing.isBye || pairing.isComplete || pairing.winner) {
      return true;
    }
    return Boolean(
      pairing.score ||
        pairing.rawScore ||
        (pairing.matchStatus && pairing.matchStatus !== "normal")
    );
  }

  function createCompletedRoundEvent(base, roundKey, roundLabel) {
    return {
      ...base,
      roundKey,
      roundLabel,
      checkpointKey: `${base.tournamentId}:${base.mode}:${roundKey}`
    };
  }

  function collectNewCompletedRoundEvents(previousTournament, nextTournament, tournamentIndex) {
    const previousKeys = new Set(
      collectCompletedRoundEvents(previousTournament, tournamentIndex).map((event) => event.checkpointKey)
    );

    // Ausdrücklich ohne Abgleich gegen die Liste im Fenster: Die kann durch
    // einen Speicherfehler leer sein oder in einem zweiten Fenster veraltet.
    // Ob wirklich gesichert wurde, entscheidet unten der Inhaltsstempel.
    return collectCompletedRoundEvents(nextTournament, tournamentIndex).filter(
      (event) => !previousKeys.has(event.checkpointKey)
    );
  }

  function createAutomaticRoundCheckpoints(previousTournament, nextTournament, tournamentIndex) {
    const events = collectNewCompletedRoundEvents(previousTournament, nextTournament, tournamentIndex);
    if (events.length === 0) {
      return [];
    }

    // Der Speicher wird bei jedem Rundenende frisch gelesen: Ein zweites
    // Fenster hat denselben Stand womöglich längst gesichert (B045 Weg B).
    const knownStamps = readRoundCheckpointStamps();
    const createdCheckpoints = [];

    events.forEach((event) => {
      const payload = buildWorkspaceBackupPayload(workspace);
      payload.checkpoint = {
        kind: "automatic-round-checkpoint",
        tournamentId: event.tournamentId,
        tournamentLabel: event.tournamentLabel,
        roundKey: event.roundKey,
        roundLabel: event.roundLabel
      };

      const stamp = computeContentStamp(payload.workspace);
      if (knownStamps.get(event.checkpointKey) === stamp) {
        // Exakt dieser Stand liegt schon als Datei beim Nutzer. Ein zweiter
        // Download derselben Runde ist Lärm, kein Schutz.
        return;
      }

      // Stempel vor dem Download: Wirft das Schreiben, hält ihn der Notnagel —
      // in beiden Fällen entsteht die Datei genau einmal.
      rememberRoundCheckpointStamp(event.checkpointKey, stamp);
      knownStamps.set(event.checkpointKey, stamp);

      const completedAt = payload.exportedAt;
      const checkpoint = {
        id: `checkpoint-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        checkpointKey: event.checkpointKey,
        tournamentId: event.tournamentId,
        tournamentLabel: event.tournamentLabel,
        tournamentName: event.tournamentName,
        mode: event.mode,
        roundKey: event.roundKey,
        roundLabel: event.roundLabel,
        completedAt,
        backupFilename: buildRoundCheckpointBackupFilename(event, completedAt),
        payload
      };

      downloadRoundCheckpoint(checkpoint);
      createdCheckpoints.push(checkpoint);
    });

    if (createdCheckpoints.length === 0) {
      return [];
    }

    roundCheckpoints = [
      ...createdCheckpoints,
      ...roundCheckpoints.filter(
        (checkpoint) =>
          !createdCheckpoints.some((created) => created.checkpointKey === checkpoint.checkpointKey)
      )
    ].slice(0, ROUND_CHECKPOINT_LIMIT);

    const saved = saveRoundCheckpoints();
    if (!saved) {
      showInfo("Rundenbackup wurde heruntergeladen, aber der interne Checkpoint konnte nicht im Browser gespeichert werden.");
    } else if (createdCheckpoints.length === 1) {
      showInfo(`${createdCheckpoints[0].roundLabel} automatisch gesichert. JSON-Backup wurde heruntergeladen.`);
    } else {
      showInfo(`${createdCheckpoints.length} Runden automatisch gesichert. JSON-Backups wurden heruntergeladen.`);
    }

    return createdCheckpoints;
  }

  /**
   * Sicherung vor einem Schritt, der Ergebnisse verwirft. Anders als Undo
   * überlebt sie das Neuladen — genau darauf kommt es an, wenn jemand am
   * Turniertag versehentlich an einem Zahlenfeld dreht und es erst später
   * merkt.
   */
  function storeRoundCheckpoint(label, options = {}) {
    const payload = buildWorkspaceBackupPayload(workspace);
    payload.checkpoint = {
      kind: "manual-safety-checkpoint",
      tournamentId: activeTournament?.id,
      tournamentLabel: activeTournament?.tabName || "",
      roundLabel: label
    };
    const completedAt = payload.exportedAt;
    const checkpoint = {
      id: `checkpoint-${completedAt}-${roundCheckpoints.length}`,
      checkpointKey: `safety-${activeTournament?.id}-${completedAt}`,
      tournamentId: activeTournament?.id,
      tournamentLabel: activeTournament?.tabName || "",
      tournamentName: activeTournament?.tournamentName || "",
      mode: activeTournament?.mode,
      roundKey: "safety",
      roundLabel: label,
      completedAt,
      backupFilename: buildRoundCheckpointBackupFilename(
        { tournamentLabel: activeTournament?.tabName || "turnier", roundLabel: label },
        completedAt
      ),
      payload
    };

    roundCheckpoints = [checkpoint, ...roundCheckpoints].slice(0, ROUND_CHECKPOINT_LIMIT);
    if (!saveRoundCheckpoints()) {
      renderRoundCheckpointPanel();
      if (!options.quiet) {
        showInfo("Achtung: Die Sicherung konnte nicht im Browser abgelegt werden.");
      }
      return false;
    }
    renderRoundCheckpointPanel();
    if (!options.quiet) {
      showInfo(`Sicherung „${label}“ abgelegt — wiederherstellbar über die Rundenstände.`);
    }
    return true;
  }

  function handleUndo() {
    if (!activeTournament) {
      renderHistoryButtons();
      return;
    }

    const history = getTournamentHistory(activeTournament.id);
    const entry = history.undo.pop();
    if (!entry) {
      renderHistoryButtons();
      return;
    }

    pushTournamentHistorySnapshot(activeTournament.id, "redo", activeTournament, entry.note);
    restoreTournamentSnapshot(
      activeTournament.id,
      entry.tournament,
      // B048: „wiederhergestellt" las sich nach einem Rückgängigmachen wie das
      // Gegenteil dessen, was gerade passiert ist.
      `Zurückgenommen: ${entry.note}`
    );
    // Die alte Erfolgsmeldung („8 Teilnehmer wurden übernommen.") darf nach
    // dem Zurücknehmen nicht stehen bleiben — sonst lügt der Screen.
    showInfo(`Zurückgenommen: ${entry.note}`);
  }

  function handleRedo() {
    if (!activeTournament) {
      renderHistoryButtons();
      return;
    }

    const history = getTournamentHistory(activeTournament.id);
    const entry = history.redo.pop();
    if (!entry) {
      renderHistoryButtons();
      return;
    }

    pushTournamentHistorySnapshot(activeTournament.id, "undo", activeTournament, entry.note);
    restoreTournamentSnapshot(
      activeTournament.id,
      entry.tournament,
      `Wiederholt: ${entry.note}`
    );
    showInfo(`Wiederholt: ${entry.note}`);
  }

  /**
   * Kurzform des Turnierzustands für Kopfleiste, Schalter und Startliste:
   * Format, laufende Runde und wie viele Spiele darin erfasst sind.
   */
  function describeTournamentState(tournament) {
    const format = getTournamentModeLabel(tournament);

    try {
      if (isTtRaceTournament(tournament)) {
        const rounds = Array.isArray(tournament.ttRace?.rounds) ? tournament.ttRace.rounds : [];
        const current = rounds[rounds.length - 1];
        if (!current) {
          return {
            format: "Schweizer System",
            round: "noch keine Runde ausgelost",
            progress: "Noch nicht gestartet",
            started: false,
            done: false
          };
        }

        // B105: Die Rundenzahl steht unter `settings`. Wer sie an der Wurzel
        // sucht, findet nichts und meldet „Runde 1 von 1 · Abgeschlossen" —
        // dieselbe Lüge, die B070 auf den Beamer geschrieben hat. Deshalb
        // fragen Kopfleiste und Bühne jetzt denselben Weg.
        const progress = getTtRaceProgress(tournament.ttRace);
        const matches = Array.isArray(current.matches) ? current.matches : [];
        const played = matches.filter((match) => hasTtRaceMatchResult(match)).length;
        return {
          format,
          round: `Runde ${progress.currentRoundNumber} von ${progress.maxRounds}`,
          progress: `${played} von ${matches.length} Spielen`,
          started: true,
          done: progress.complete
        };
      }

      const analysisForTournament = analyzeTournamentForState(tournament);
      const rounds = analysisForTournament?.rounds ?? [];
      if (rounds.length === 0) {
        return { format, round: "", progress: "Noch nicht gestartet", started: false, done: false };
      }

      const hasResult = (pairing) => Boolean(pairing.rawScore?.trim?.() || pairing.score);
      const allPairings = rounds.flatMap((round) => round.pairings ?? []);
      const played = allPairings.filter(hasResult).length;
      const openRound = rounds.find((round) => (round.pairings ?? []).some((pairing) => !hasResult(pairing)));
      const roundNumber = openRound?.roundNumber ?? rounds.length;

      return {
        format,
        round: `Runde ${roundNumber} von ${rounds.length}`,
        progress: `${played} von ${allPairings.length} Spielen`,
        started: played > 0,
        done: played === allPairings.length && allPairings.length > 0
      };
    } catch (error) {
      return { format, round: "", progress: "", started: false, done: false };
    }
  }

  function analyzeTournamentForState(tournament) {
    const shared = {
      matchMode: tournament.matchMode,
      scoring: tournament.scoring,
      tournamentName: tournament.tournamentName
    };

    if (tournament.mode === "team") {
      return analyzeTeamCompetition({ ...tournament.team, ...shared });
    }

    if (tournament.mode === "groupsKnockout") {
      const groups = analyzeGroupsKnockout({ ...tournament.groupsKnockout, ...shared });
      return { rounds: groups.groupRoundSchedule ?? [] };
    }

    return analyzeRoundRobin({ ...tournament.roundRobin, ...shared });
  }

  function formatTournamentStateLine(state) {
    return [state.format, state.round, state.progress].filter(Boolean).join(" · ");
  }

  /**
   * Der Turniername steht nur im Schalter. Die Überschrift trägt die Aufgabe
   * des Reiters, darunter die Rahmendaten als stille Zeile.
   */
  function renderAppTitle() {
    const index = workspace.tournaments.findIndex((entry) => entry.id === activeTournament.id);
    const name = getTournamentLabel(activeTournament, index < 0 ? 0 : index);
    const state = describeTournamentState(activeTournament);

    switcherName.textContent = name;

    // Die Startliste ist kein Turnier-Reiter; sie trägt ihren eigenen Titel.
    if (startViewOpen) {
      appTitle.textContent = "Meine Turniere";
      screenKicker.textContent = `${workspace.tournaments.length} Turnier${workspace.tournaments.length === 1 ? "" : "e"}`;
      screenFacts.textContent = "";
      screenMeta.innerHTML = "";
      document.title = "Meine Turniere — Turnierblatt";
      return;
    }

    // Ein abgeschlossenes Turnier heißt nicht mehr "Ergebniseingabe" — es wird
    // nichts mehr eingegeben, es wird gelesen.
    appTitle.textContent =
      activeWorkspaceView === "output" && isTournamentClosed()
        ? "Endstand"
        : VIEW_TITLES[activeWorkspaceView] || "Turnierblatt";
    screenKicker.textContent = [state.format, state.round].filter(Boolean).join(" · ");

    // Die Rahmendaten stehen unter dem Titel. Nur wenn es zusätzlichen
    // Kontext gibt — den click-TT-Stand — wandern sie nach rechts, damit
    // beide Zeilen zusammen stehen.
    const { facts, source } = buildScreenMeta(state);
    if (source) {
      screenFacts.textContent = "";
      screenMeta.innerHTML = [facts, source]
        .filter(Boolean)
        .map((line) => `<span>${escapeHtml(line)}</span>`)
        .join("");
    } else {
      screenFacts.textContent = facts;
      screenMeta.innerHTML = "";
    }

    document.title = `${name} — Turnierblatt`;
  }

  function buildScreenMeta(state) {
    const parts = [];
    const participantCount = countActiveParticipants();

    if (participantCount > 0) {
      parts.push(`${participantCount} Teilnehmer`);
    }

    if (state.progress) {
      parts.push(state.progress);
    }

    if (analysis?.matchModeLabel) {
      parts.push(analysis.matchModeLabel);
    }

    const source = isTtRaceTournament()
      ? activeTournament.clicktt?.rawXml
        ? "click-TT XML verbunden · Namen, IDs, Vereine, TTR übernommen"
        : "Keine click-TT XML verbunden"
      : "";

    // Auf dem Teilnehmer-Reiter zählt die Startliste, nicht der Spielstand.
    if (isTtRaceTournament() && activeWorkspaceView === "input") {
      const players = activeTournament.ttRace?.players ?? [];
      const active = players.filter((player) => (player.status || "active") === "active").length;
      const rosterFacts = [
        `${players.length} gelistet`,
        `${active} aktiv`,
        `${activeTournament.schedule.fieldCount} Tische`
      ];
      return { facts: rosterFacts.join(" · "), source };
    }

    return { facts: parts.join(" · "), source };
  }

  function countActiveParticipants() {
    if (isTtRaceTournament()) {
      // getRaceDayParticipants liefert nur Namen; der Status hängt am Spielerobjekt.
      return (activeTournament.ttRace?.players ?? []).filter((player) => (player.status || "active") !== "withdrawn").length;
    }

    if (activeTournament.mode === "team") {
      const team = activeTournament.team ?? {};
      return (team.teamAPlayers?.length ?? 0) + (team.teamBPlayers?.length ?? 0);
    }

    const source =
      activeTournament.mode === "groupsKnockout" ? activeTournament.groupsKnockout : activeTournament.roundRobin;
    const names = source?.playerNames ?? [];
    const statuses = source?.playerStatuses ?? [];
    return names.filter((name, index) => statuses[index] !== "withdrawn").length;
  }

  function renderWorkspacePanels() {
    const isOutput = activeWorkspaceView === "output";
    const isLive = activeWorkspaceView === "live";
    inputView.hidden = isOutput || isLive;
    outputView.hidden = !isOutput;
    liveView.hidden = !isLive;
    inputView.classList.toggle("is-hidden", isOutput || isLive);
    outputView.classList.toggle("is-hidden", !isOutput);
    liveView.classList.toggle("is-hidden", !isLive);
    inputView.classList.toggle("is-race-workspace", !isOutput && !isLive && isTtRaceTournament());

    // Die Bühne wird erst messbar, wenn sie sichtbar ist — sonst bliebe der
    // Skalierungsfaktor auf dem Wert von vor dem Reiterwechsel stehen.
    if (isLive) {
      updateLiveStageScale();
    }

    workspaceViewTabs.querySelectorAll("[data-workspace-view]").forEach((button) => {
      const isActive = button.dataset.workspaceView === activeWorkspaceView;
      button.classList.toggle("is-active", isActive);
      button.setAttribute("aria-pressed", isActive ? "true" : "false");
    });
  }

  /**
   * 12a — Turnierwechsel aus der Kopfleiste. Der Wechsel behält den Reiter:
   * wer in der Ergebniseingabe war, landet dort auch im anderen Turnier.
   */
  function renderTabs() {
    tabsElement.innerHTML = workspace.tournaments
      .map((tournament, index) => {
        const isActive = tournament.id === workspace.activeTournamentId;
        const label = getTournamentLabel(tournament, index);
        const state = describeTournamentState(tournament);
        return `
          <button class="switcher-row ${isActive ? "is-current" : ""}" type="button" data-tab-id="${tournament.id}">
            <span class="switcher-mark"></span>
            <span class="switcher-row-text">
              <span class="switcher-row-name">${escapeHtml(label)}</span>
              <span class="switcher-row-meta">${escapeHtml(formatTournamentStateLine(state))}</span>
            </span>
            <span class="switcher-row-action">${isActive ? "geöffnet" : "wechseln"}</span>
          </button>
        `;
      })
      .join("");

    tabsElement.querySelectorAll("[data-tab-id]").forEach((button) => {
      button.addEventListener("click", () => {
        closeTournamentSwitcher();
        if (button.dataset.tabId === workspace.activeTournamentId) {
          return;
        }

        updateWorkspace((draft) => {
          draft.activeTournamentId = button.dataset.tabId;
        }, "Turnier gewechselt");
      });
    });

    renderStartTournamentList();
  }

  /**
   * 5a — Meine Turniere. Zeile je Turnier mit Zustandsmarke und einer Aktion;
   * Umbenennen, Löschen und Sortieren liegen hier statt in der Kopfleiste.
   */
  function renderStartTournamentList() {
    startTournamentList.innerHTML = workspace.tournaments
      .map((tournament, index) => {
        const isActive = tournament.id === workspace.activeTournamentId;
        const label = getTournamentLabel(tournament, index);
        const state = describeTournamentState(tournament);

        const badge = state.done
          ? '<span class="tag tag-neutral">Abgeschlossen</span>'
          : state.started
            ? `<span class="tag tag-accent">${escapeHtml(state.round || "Läuft")}</span>`
            : '<span class="tag tag-outline">Noch nicht gestartet</span>';

        const action = state.done ? "Ansehen" : state.started ? "Fortsetzen" : "Öffnen";

        return `
          <div class="start-row ${isActive ? "is-current" : ""}" data-tab-shell="${tournament.id}">
            <button class="start-row-drag" type="button" data-tab-drag="${tournament.id}" aria-label="Turnier verschieben" title="Gedrückt halten und verschieben">
              ${renderTabToolIcon("drag")}
            </button>
            <span class="start-row-text">
              <span class="start-row-name">${escapeHtml(label)}</span>
              <span class="start-row-meta">${escapeHtml(formatTournamentStateLine(state))}</span>
            </span>
            ${badge}
            <span class="start-row-tools">
              <button class="link-button" type="button" data-tab-open="${tournament.id}">${action}</button>
              <button class="tab-tool-button icon-only" type="button" data-tab-rename="${tournament.id}" aria-label="Turnier umbenennen" title="Umbenennen">
                ${renderTabToolIcon("rename")}
              </button>
              <button class="tab-tool-button icon-only danger" type="button" data-tab-delete="${tournament.id}" ${workspace.tournaments.length <= 1 ? "disabled" : ""} aria-label="Turnier löschen" title="Löschen">
                ${renderTabToolIcon("delete")}
              </button>
            </span>
          </div>
        `;
      })
      .join("");

    startTournamentList.querySelectorAll("[data-tab-open]").forEach((button) => {
      button.addEventListener("click", () => {
        const id = button.dataset.tabOpen;
        hideStartView();
        if (id === workspace.activeTournamentId) {
          return;
        }

        updateWorkspace((draft) => {
          draft.activeTournamentId = id;
        }, "Turnier gewechselt");
      });
    });

    startTournamentList.querySelectorAll("[data-tab-drag]").forEach((handle) => {
      handle.addEventListener("pointerdown", handleTournamentTabPointerDown);
    });

    startTournamentList.querySelectorAll("[data-tab-rename]").forEach((button) => {
      button.addEventListener("click", () => {
        handleRenameTournamentTab(button.dataset.tabRename);
      });
    });

    startTournamentList.querySelectorAll("[data-tab-delete]").forEach((button) => {
      button.addEventListener("click", () => {
        handleDeleteTournamentTab(button.dataset.tabDelete);
      });
    });
  }

  function openTournamentSwitcher() {
    switcherPanel.hidden = false;
    switcherButton.setAttribute("aria-expanded", "true");
  }

  function closeTournamentSwitcher() {
    switcherPanel.hidden = true;
    switcherButton.setAttribute("aria-expanded", "false");
  }

  function toggleTournamentSwitcher() {
    if (switcherPanel.hidden) {
      openTournamentSwitcher();
    } else {
      closeTournamentSwitcher();
    }
  }

  function openWorkspaceView(view) {
    activeWorkspaceView = ["input", "output", "live"].includes(view) ? view : "input";
    saveWorkspaceView();
    hideStartView();
    renderWorkspacePanels();
    renderAppTitle();
  }

  function showStartView() {
    closeTournamentSwitcher();
    startViewOpen = true;
    startView.hidden = false;
    mainLayout.hidden = true;
    renderStartTournamentList();
    renderAppTitle();
  }

  function hideStartView() {
    const wasOpen = startViewOpen;
    startViewOpen = false;
    startView.hidden = true;
    mainLayout.hidden = false;
    if (wasOpen) {
      renderAppTitle();
    }
  }

  function renderTemplateControls() {
    const selectedTemplateId = templateSelect.value;
    const hasTemplates = tournamentTemplates.length > 0;

    templateSelect.innerHTML = hasTemplates
      ? tournamentTemplates
          .map(
            (template) =>
              `<option value="${escapeHtml(template.id)}">${escapeHtml(formatTemplateOptionLabel(template))}</option>`
          )
          .join("")
      : `<option value="">Keine Vorlage gespeichert</option>`;

    if (hasTemplates && tournamentTemplates.some((template) => template.id === selectedTemplateId)) {
      templateSelect.value = selectedTemplateId;
    }

    templateSelect.disabled = !hasTemplates;
    document.querySelector("#loadTemplateBtn").disabled = !hasTemplates;
    document.querySelector("#deleteTemplateBtn").disabled = !hasTemplates;
  }

  function renderRoundCheckpointPanel() {
    const activeCheckpoints = getRoundCheckpointsForTournament(activeTournament?.id);
    const hasCheckpoints = activeCheckpoints.length > 0;
    // Der Speicherfehler beim Checkpoint war früher ein Toast, der nach fünf
    // Sekunden verschwand (B054). Hier steht er, bis er behoben ist.
    const storageWarning = roundCheckpointStorageFailed
      ? `<p class="rail-note is-warning" role="alert"><strong>Rundenstände werden nicht mehr im Browser gespeichert.</strong>
          Die heruntergeladenen JSON-Dateien sind jetzt die einzige Sicherung.</p>`
      : roundCheckpointsUnreadable
        ? `<p class="rail-note is-warning" role="alert"><strong>Gespeicherte Rundenstände ließen sich nicht lesen.</strong>
            „Keine Checkpoints“ heißt hier nicht, dass es keine gab: die nach jeder Runde
            heruntergeladenen JSON-Dateien liegen weiterhin im Download-Ordner und lassen sich
            über „Sicherung laden“ zurückholen.</p>`
        : "";

    roundCheckpointPanels.forEach((panel) => {
      panel.classList.toggle("is-empty", !hasCheckpoints);

      if (!hasCheckpoints) {
        panel.innerHTML = `
          ${storageWarning}
          <p class="rail-note">Nach jeder erstmals vollständig erfassten Runde wird automatisch ein interner Checkpoint gespeichert und ein JSON-Backup heruntergeladen.</p>
        `;
        return;
      }

      // Feld und Knöpfe tragen die Randspalten-Form: gleiche Gestalt wie
      // „Vorlagen" und „Sicherung" direkt darüber (G1) — und sie passen in die
      // schmale Spur, statt rechts hinauszulaufen.
      panel.innerHTML = `
        ${storageWarning}
        <label class="rail-field round-checkpoint-select-field">
          <span>Gesicherter Stand</span>
          <select data-round-checkpoint-select>
            ${activeCheckpoints
              .map(
                (checkpoint) => `
                  <option value="${escapeHtml(checkpoint.id)}">${escapeHtml(formatRoundCheckpointOptionLabel(checkpoint))}</option>
                `
              )
              .join("")}
          </select>
        </label>
        <div class="rail-links">
          <button class="link-button" type="button" data-round-checkpoint-download>JSON erneut laden</button>
          <button class="link-button" type="button" data-round-checkpoint-restore>Checkpoint laden</button>
        </div>
      `;

      panel
        .querySelector("[data-round-checkpoint-download]")
        ?.addEventListener("click", handleDownloadSelectedRoundCheckpoint);
      panel
        .querySelector("[data-round-checkpoint-restore]")
        ?.addEventListener("click", handleRestoreSelectedRoundCheckpoint);
    });
  }

  /**
   * Was zuletzt gesichert wurde — eine Zeile, in beiden Randspalten dieselbe.
   * Solange nichts gesichert ist, steht hier nichts: Der Hinweis, wie ein
   * Checkpoint entsteht, steht im Panel darunter und muss nicht doppelt da sein.
   */
  function renderRoundBackupStatus() {
    const latestCheckpoint = getRoundCheckpointsForTournament(activeTournament?.id)[0];
    const markup = latestCheckpoint
      ? `<strong>${escapeHtml(latestCheckpoint.roundLabel)} gesichert</strong>
         <span>${escapeHtml(formatDateTime(latestCheckpoint.completedAt))} · ${escapeHtml(latestCheckpoint.backupFilename)}</span>`
      : "";

    roundBackupStatusTargets.forEach((target) => {
      target.innerHTML = markup;
      target.hidden = !latestCheckpoint;
    });
  }

  function getRoundCheckpointsForTournament(tournamentId) {
    return roundCheckpoints
      .filter((checkpoint) => checkpoint.tournamentId === tournamentId)
      .sort((left, right) => String(right.completedAt).localeCompare(String(left.completedAt)));
  }

  /**
   * Die Auswahl gehört zu dem Panel, in dem geklickt wurde — sonst lädt der
   * Knopf in der Ergebnisansicht den Stand, der in der Startansicht ausgewählt
   * ist.
   */
  function getSelectedRoundCheckpoint(origin) {
    const panel =
      origin?.closest?.("[data-round-checkpoint-panel]") ||
      roundCheckpointPanels.find((entry) => entry.querySelector("[data-round-checkpoint-select]"));
    const checkpointId = panel?.querySelector("[data-round-checkpoint-select]")?.value;
    return roundCheckpoints.find((checkpoint) => checkpoint.id === checkpointId) || null;
  }

  function formatRoundCheckpointOptionLabel(checkpoint) {
    return `${checkpoint.roundLabel} · ${formatDateTime(checkpoint.completedAt)}`;
  }

  function formatDateTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return "Zeitpunkt unbekannt";
    }
    return date.toLocaleString("de-DE", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  function formatTemplateOptionLabel(template) {
    const resultHint = template.includeResults ? "mit Ergebnissen" : "ohne Ergebnisse";
    return `${template.name} (${getTournamentModeLabel(template.state)}, ${resultHint})`;
  }

  function getTournamentModeLabel(tournament) {
    if (isTtRaceTournament(tournament)) {
      return "TT-Race Schweizer System";
    }

    return MODES[tournament.mode]?.label || "Turnier";
  }

  function renderRaceDayShell() {
    const isRace = isTtRaceTournament();

    if (!isRace) {
      raceDayShell.hidden = true;
      raceDayShell.innerHTML = "";
      return;
    }

    raceDayShell.hidden = false;

    const roundContext = getRaceDayRoundContext();
    const participants = getRaceDayParticipants();
    const progress = getRaceDayProgress(roundContext);
    const clickttMeta = getActiveClickTtMeta();
    const canEditRoster = isRace && (activeTournament.ttRace?.rounds?.length ?? 0) === 0;
    const title =
      activeTournament.tournamentName?.trim() ||
      getTournamentLabel(activeTournament, getActiveTournamentIndex());
    const completed = progress.completed;
    const total = progress.total;

    // 2cv2 — Startliste prüfen: Arbeitsfläche links, Vereinsquote rechts.
    const players = Array.isArray(activeTournament.ttRace?.players) ? activeTournament.ttRace.players : [];
    const activeCount = players.filter((player) => (player.status || "active") === "active").length;
    const generationState = getTtRaceGenerationStateFromTournament(activeTournament.ttRace);

    raceDayShell.innerHTML = `
      <h2 id="race-day-heading" class="sr-only">${escapeHtml(title)}</h2>
      <div class="work-split">
        <div class="work-main">
          <hr class="work-rule" />
          <div class="work-head">
            <h3>Startliste prüfen</h3>
            <button class="secondary-button" type="button" data-race-action="add-tt-race-player" ${
              canEditRoster
                ? 'title="Trägt einen weiteren Teilnehmer in die Startliste ein."'
                : 'disabled title="Die Startliste ist ab der ersten ausgelosten Runde festgeschrieben."'
            }>Teilnehmer hinzufügen</button>
          </div>
          <p class="entry-lead">${
            canEditRoster
              ? `${players.length} Name${players.length === 1 ? "" : "n"}, zwei Spalten, eine Zeile pro Teilnehmer. Zum Ändern die Zeile anklicken.`
              : "Die Teilnehmerliste ist nach Rundenerzeugung gesperrt."
          }</p>

          ${renderTtRaceParticipantManager(canEditRoster)}

          <div class="work-action">
            <button class="primary-button" type="button" data-race-action="generate-swiss-round" ${generationState.canGenerate ? "" : "disabled"}>
              ${escapeHtml(generationState.label)}
            </button>
            <span class="action-reason">${
              generationState.canGenerate
                ? `${activeCount} aktive Teilnehmer · BTTV Race läuft von 9 bis 16.`
                : escapeHtml(generationState.reason)
            }</span>
          </div>
        </div>

        ${renderTtRaceRosterRail(players, clickttMeta)}
      </div>
    `;
  }

  /** Randspalte von 2cv2: Vereinsquote, Verteilung, Herkunft. */
  function renderTtRaceRosterRail(players, clickttMeta) {
    const clubCounts = new Map();
    players
      .filter((player) => (player.status || "active") === "active")
      .forEach((player) => {
        const club = player.clubName || player.club || "Ohne Verein";
        clubCounts.set(club, (clubCounts.get(club) ?? 0) + 1);
      });

    const distribution = [...clubCounts.entries()].sort((a, b) => b[1] - a[1]);
    const source = clickttMeta?.sourceFileName || clickttMeta?.fileName;

    return `
      <aside class="work-rail" aria-label="Prüfungen">
        ${renderTtRaceClubQuotaNotice(players)}

        ${
          distribution.length > 0
            ? `<section class="rail-block">
                <h6 class="rail-heading">Verteilung</h6>
                <table class="data-table rail-table">
                  <tbody>
                    ${distribution
                      .map(
                        ([club, count]) => `
                          <tr>
                            <td>${escapeHtml(club)}</td>
                            <td class="is-numeric">${count}</td>
                          </tr>
                        `
                      )
                      .join("")}
                  </tbody>
                </table>
              </section>`
            : ""
        }

        <hr class="hairline" />

        <div class="rail-links">
          <span class="rail-note">${escapeHtml(getAutosaveShortText())}</span>
          <button class="link-button" type="button" data-race-action="choose-clicktt-file">${clickttMeta ? "Andere XML wählen" : "click-TT XML wählen"}</button>
          <button class="link-button" type="button" data-race-action="load-race-demo">Demodaten laden</button>
          <button class="link-button" type="button" data-print-mode="startlist">Startliste drucken</button>
          ${source ? `<span class="rail-note">Quelle: ${escapeHtml(source)}</span>` : ""}
        </div>
      </aside>
    `;
  }

  function getActiveClickTtMeta() {
    return activeTournament.clicktt || clickTtImportDraft;
  }

  function isTtRaceTournament(tournament = activeTournament) {
    return Boolean(tournament?.ttRace);
  }

  function renderTtRaceParticipantManager(canEditRoster) {
    const players = Array.isArray(activeTournament.ttRace?.players) ? activeTournament.ttRace.players : [];

    if (players.length === 0) {
      return `
        <div class="empty-round-state">
          <p>Noch keine Teilnehmer geladen.</p>
          <div class="clicktt-import-actions">
            <button class="secondary-button" type="button" data-race-action="choose-clicktt-file">click-TT XML wählen</button>
            <button class="ghost-button" type="button" data-race-action="add-tt-race-player">Manuell hinzufügen</button>
          </div>
        </div>
      `;
    }

    // 2cv2 — Startliste zweispaltig im Lesemodus; bearbeitet wird die
    // angeklickte Zeile, nicht ein Formularraster über alle Teilnehmer.
    const half = Math.ceil(players.length / 2);
    const columns = [players.slice(0, half), players.slice(half)];
    const editing = players.find((player, index) => (player.id || `player-${index + 1}`) === ttRaceEditingPlayerId);

    return `
      <div class="roster-columns">
        ${columns
          .map(
            (column, columnIndex) => `
              <div class="roster-column">
                ${column
                  .map((player, rowIndex) =>
                    renderTtRaceParticipantRow(player, columnIndex * half + rowIndex, canEditRoster)
                  )
                  .join("")}
              </div>
            `
          )
          .join("")}
      </div>

      ${editing ? renderTtRaceParticipantEditor(editing, players.indexOf(editing), canEditRoster) : ""}
    `;
  }

  /** Feldsatz für die eine angeklickte Zeile. */
  function renderTtRaceParticipantEditor(player, index, canEditRoster) {
    const id = escapeHtml(player.id || `player-${index + 1}`);
    const status = PLAYER_STATUSES[player.status] ? player.status : "active";
    const disabled = canEditRoster ? "" : "disabled";
    const ratingValue = hasTtrValue(player.rating) ? formatTtrValue(player.rating) : "";
    const names = splitParticipantName(player);

    return `
      <div class="roster-editor">
        <h4 class="roster-editor-heading">Nr. ${index + 1} bearbeiten</h4>
        <div class="roster-editor-grid">
          <label class="field">
            <span>Vorname</span>
            <input data-tt-race-player-first="${id}" type="text" value="${escapeHtml(names.firstName)}" ${disabled} />
          </label>
          <label class="field">
            <span>Nachname</span>
            <input data-tt-race-player-last="${id}" type="text" value="${escapeHtml(names.lastName)}" ${disabled} />
          </label>
          <label class="field">
            <span>TTR</span>
            <input data-tt-race-player-rating="${id}" type="number" min="0" max="4000" step="1" value="${escapeHtml(ratingValue)}" placeholder="—" ${disabled} />
          </label>
          <label class="field">
            <span>Status</span>
            <select data-tt-race-player-status="${id}" ${disabled}>
              ${Object.values(PLAYER_STATUSES)
                .map((entry) => `<option value="${escapeHtml(entry.id)}" ${entry.id === status ? "selected" : ""}>${escapeHtml(entry.label)}</option>`)
                .join("")}
            </select>
          </label>
        </div>
        <div class="action-row">
          <button class="secondary-button" type="button" data-race-action="apply-tt-race-player" data-player-id="${id}" ${disabled}>Übernehmen</button>
          <button class="ghost-button" type="button" data-race-action="remove-tt-race-player" data-player-id="${id}" ${disabled}>Teilnehmer entfernen</button>
        </div>
      </div>
    `;
  }

  /**
   * Vor- und Nachname kommen aus der click-TT XML. Fehlen sie (manuell
   * angelegte Teilnehmer), wird am letzten Leerzeichen getrennt.
   */
  function splitParticipantName(player) {
    if (player.firstName || player.lastName) {
      return { firstName: player.firstName || "", lastName: player.lastName || "" };
    }

    const parts = String(player.name || "").trim().split(/\s+/);
    if (parts.length < 2) {
      return { firstName: parts[0] || "", lastName: "" };
    }

    return { firstName: parts.slice(0, -1).join(" "), lastName: parts[parts.length - 1] };
  }

  function renderTtRaceClubQuotaNotice(players) {
    const activePlayers = players.filter((player) => (player.status || "active") === "active");
    const activeCount = activePlayers.length;

    if (activeCount === 0) {
      return "";
    }

    const maxAllowed = Math.ceil(activeCount / 2) - 1;
    const clubMap = new Map();
    const missingClubInfo = [];

    activePlayers.forEach((player) => {
      const clubNr = String(player.clubNr || player.clubNumber || player.clubId || "").trim();
      const clubName = String(player.clubName || player.club || "").trim();

      if (!clubNr && !clubName) {
        missingClubInfo.push(player);
        return;
      }

      const key = clubNr ? `club-nr:${clubNr}` : `club-name:${clubName.toLocaleLowerCase("de")}`;
      const entry = clubMap.get(key) ?? { clubName, clubNr, count: 0 };
      entry.count += 1;
      clubMap.set(key, entry);
    });

    const violations = [...clubMap.values()].filter((club) => club.count * 2 >= activeCount);
    const hasClickttImport = Boolean(activeTournament.clicktt?.rawXml);

    if (violations.length === 0 && (!hasClickttImport || missingClubInfo.length === 0)) {
      return "";
    }

    const messages = [];
    violations.forEach((club) => {
      const label = club.clubName || club.clubNr || "Ein Verein";
      messages.push(
        `${label}: ${club.count} von ${activeCount} aktiven Teilnehmern. Für BTTV Race sind maximal ${maxAllowed} erlaubt.`
      );
    });

    if (hasClickttImport && missingClubInfo.length > 0) {
      messages.push(
        `${missingClubInfo.length} aktive Teilnehmer haben keine Vereinsdaten. Bitte click-TT Import prüfen.`
      );
    }

    // Getönter Hinweis in der Randspalte, nicht als Warnkasten in der Liste.
    return `
      <section class="quota-notice" role="status">
        <h6 class="quota-notice-heading">Vereinsquote prüfen</h6>
        ${messages.map((message) => `<p class="quota-notice-text">${escapeHtml(message)}</p>`).join("")}
      </section>
    `;
  }

  /** Eine Zeile im Lesemodus: Nr, Name mit Verein, TTR, Marke nur wenn abweichend. */
  function renderTtRaceParticipantRow(player, index, canEditRoster) {
    const status = PLAYER_STATUSES[player.status] ? player.status : "active";
    const id = escapeHtml(player.id || `player-${index + 1}`);
    const isEditing = id === ttRaceEditingPlayerId;
    const club = player.clubName || player.club || "";

    return `
      <button
        class="roster-row ${status !== "active" ? "is-muted" : ""} ${isEditing ? "is-editing" : ""}"
        type="button"
        data-race-action="edit-tt-race-player"
        data-player-id="${id}"
        ${canEditRoster ? "" : "disabled"}
      >
        <span class="roster-number">${index + 1}</span>
        <span class="roster-name-cell">
          <span class="roster-name">${escapeHtml(player.name || "")}</span>
          ${club ? `<span class="roster-club">${escapeHtml(club)}</span>` : ""}
        </span>
        <span class="roster-ttr">${hasTtrValue(player.rating) ? escapeHtml(formatTtrValue(player.rating)) : "—"}</span>
        <span class="roster-status">${
          status === "active" ? "" : `<span class="tag tag-neutral">${escapeHtml(PLAYER_STATUSES[status].label)}</span>`
        }</span>
      </button>
    `;
  }

  function getTtRaceRegardTtrValues() {
    return activeTournament.ttRace?.settings?.regardTtrValues !== false;
  }

  function getRaceDayParticipants() {
    if (isTtRaceTournament()) {
      return (activeTournament.ttRace.players ?? []).map((player) => player.name || player.id || "Spieler");
    }

    if (activeTournament.mode === "team") {
      return [
        ...ensureLength(
          activeTournament.team.teamAPlayers,
          activeTournament.team.teamACount,
          "Spieler A"
        ),
        ...ensureLength(
          activeTournament.team.teamBPlayers,
          activeTournament.team.teamBCount,
          "Spieler B"
        )
      ];
    }

    if (activeTournament.mode === "groupsKnockout") {
      return ensureLength(
        activeTournament.groupsKnockout.playerNames,
        activeTournament.groupsKnockout.playerCount,
        "Spieler"
      );
    }

    return ensureLength(
      activeTournament.roundRobin.playerNames,
      activeTournament.roundRobin.playerCount,
      "Spieler"
    );
  }

  function getRaceDayRoundContext() {
    if (isTtRaceTournament()) {
      const rounds = Array.isArray(activeTournament.ttRace.rounds) ? activeTournament.ttRace.rounds : [];
      const currentRound = rounds[rounds.length - 1] || null;
      const currentRoundNumber = currentRound?.roundNumber ?? rounds.length;

      return {
        kind: "ttRace",
        label: currentRound ? `Schweizer Runde ${currentRoundNumber}` : "Noch keine Schweizer Runde",
        targetRound: "ttRace",
        sheetAction: "",
        totalRounds: Math.max(1, rounds.length),
        currentRoundNumber,
        currentRound
      };
    }

    if (activeTournament.mode === "team") {
      const totalRounds = Math.max(1, analysis.rounds?.length || 1);
      const currentRoundNumber = getCurrentTeamRoundNumber(totalRounds);
      return {
        label: `Einzelrunde ${currentRoundNumber}`,
        targetRound: "team",
        sheetAction: "teamCurrentRound",
        totalRounds,
        currentRoundNumber,
        currentRound: analysis.rounds?.[currentRoundNumber - 1]
      };
    }

    if (activeTournament.mode === "groupsKnockout") {
      const totalRounds = Math.max(1, analysis.groupRoundSchedule?.length || 1);
      const currentRoundNumber = getCurrentGroupsRoundNumber(totalRounds);
      return {
        label: `Gruppenrunde ${currentRoundNumber}`,
        targetRound: "groupStage",
        sheetAction: "groupsCurrentRound",
        totalRounds,
        currentRoundNumber,
        currentRound: analysis.groupRoundSchedule?.[currentRoundNumber - 1]
      };
    }

    const totalRounds = Math.max(1, analysis.rounds?.length || 1);
    const currentRoundNumber = getCurrentRoundNumber(totalRounds);
    return {
      label: `Runde ${currentRoundNumber}`,
      targetRound: "roundRobin",
      sheetAction: "roundRobinCurrentRound",
      totalRounds,
      currentRoundNumber,
      currentRound: analysis.rounds?.[currentRoundNumber - 1]
    };
  }

  function getRaceDayProgress(roundContext) {
    if (roundContext.kind === "ttRace") {
      const matches = (activeTournament.ttRace?.rounds ?? []).flatMap((round) => round.matches ?? []);
      const completed = matches.filter((match) =>
        match.status && !["scheduled", "void"].includes(match.status)
      ).length;
      const total = matches.length;

      return {
        completed,
        total,
        completionRate: total > 0 ? Math.round((completed / total) * 100) : 0
      };
    }

    const completed = analysis.completedMatches || 0;
    const total = analysis.totalMatches || 0;

    return {
      completed,
      total,
      completionRate: Math.max(0, Math.min(100, analysis.completionRate || 0))
    };
  }

  function isTtRaceMatchComplete(match) {
    return (
      Boolean(match?.playerAId) &&
      Boolean(match?.playerBId) &&
      Boolean(match?.status) &&
      !["scheduled", "void"].includes(match.status) &&
      Boolean(match.winnerId || match.sets?.length > 0 || match.setScore)
    );
  }

  function hasTtRaceMatchResult(match) {
    return Boolean(
      match?.winnerId ||
        match?.sets?.length > 0 ||
        match?.setScore ||
        ["completed", "walkover", "retired", "void"].includes(match?.status)
    );
  }

  function isTtRaceRoundComplete(round) {
    const matches = Array.isArray(round?.matches) ? round.matches : [];
    return matches.every((match) => isTtRaceMatchComplete(match));
  }

  function getTtRaceInitialRedrawState(ttRaceTournament = activeTournament.ttRace) {
    const rounds = Array.isArray(ttRaceTournament?.rounds) ? ttRaceTournament.rounds : [];
    const firstRound = rounds[0];

    if (rounds.length !== 1 || firstRound?.roundNumber !== 1) {
      return {
        visible: false,
        canRedraw: false,
        reason: ""
      };
    }

    const hasResults = (firstRound.matches ?? []).some(hasTtRaceMatchResult);
    return {
      visible: true,
      canRedraw: !hasResults,
      reason: hasResults
        ? "Runde 1 enthält bereits Ergebnisse."
        : "Runde 1 enthält noch keine Ergebnisse."
    };
  }

  function renderTtRaceRedrawButton(redrawState, className = "secondary-button") {
    if (!redrawState.visible) {
      return "";
    }

    return `
      <button class="${escapeHtml(className)}" type="button" data-race-action="redraw-initial-round" ${redrawState.canRedraw ? "" : "disabled"} title="${escapeHtml(redrawState.reason)}">
        Erste Runde neu losen
      </button>
    `;
  }

  function getTtRaceGenerationStateFromTournament(ttRaceTournament = activeTournament.ttRace) {
    const rounds = Array.isArray(ttRaceTournament?.rounds) ? ttRaceTournament.rounds : [];
    const lastRound = rounds[rounds.length - 1] || null;
    const settings = ttRaceTournament?.settings ?? {};
    const maxRounds = Number.isInteger(Number(settings.maxRounds)) ? Number(settings.maxRounds) : 6;
    const activePlayerCount = (ttRaceTournament?.players ?? []).filter((player) => player.status === "active").length;
    const label = lastRound ? "Nächste Schweizer Runde erzeugen" : "Erste Schweizer Runde erzeugen";

    if (rounds.length === 0 && settings.bttvRaceRules && (activePlayerCount < 9 || activePlayerCount > 16)) {
      return {
        canGenerate: false,
        label,
        reason: activePlayerCount === 7 || activePlayerCount === 8
          ? "Bei 7 oder 8 Teilnehmern ist das BTTV TT-Race kein Schweizer System."
          : "BTTV TT-Race im Schweizer System braucht 9 bis 16 aktive Teilnehmer."
      };
    }

    if (activePlayerCount < 2) {
      return {
        canGenerate: false,
        label,
        reason: "Bitte zuerst Teilnehmer laden oder anlegen."
      };
    }

    if (rounds.length >= maxRounds) {
      return {
        canGenerate: false,
        label: "Maximale Rundenzahl erreicht",
        reason: `Es sind bereits ${maxRounds} Schweizer Runden erzeugt.`
      };
    }

    if (lastRound && !isTtRaceRoundComplete(lastRound)) {
      return {
        canGenerate: false,
        label,
        reason: "Erst alle Spiele der aktuellen Runde mit einem gültigen Ergebnis abschließen."
      };
    }

    return {
      canGenerate: true,
      label,
      reason: lastRound
        ? "Alle Spiele der aktuellen Runde sind erfasst."
        : "Die erste Runde wird aus der Teilnehmerliste ausgelost."
    };
  }

  function getTtRaceFinalExportState(ttRaceTournament = activeTournament.ttRace) {
    const rounds = Array.isArray(ttRaceTournament?.rounds) ? ttRaceTournament.rounds : [];
    const settings = ttRaceTournament?.settings ?? {};
    const maxRounds = Number.isInteger(Number(settings.maxRounds)) ? Number(settings.maxRounds) : 6;
    const allMatches = rounds.flatMap((round) => round.matches ?? []);
    const completedMatches = allMatches.filter((match) => isTtRaceMatchComplete(match)).length;
    const totalMatches = allMatches.length;

    if (!settings.bttvRaceRules) {
      return {
        canExport: completedMatches > 0,
        reason: completedMatches > 0
          ? "Export bereit."
          : "Noch keine exportierbaren Ergebnisse.",
        completedMatches,
        totalMatches
      };
    }

    if (rounds.length < maxRounds) {
      return {
        canExport: false,
        reason: `Finaler click-TT Export erst nach ${maxRounds} vollständig erfassten Schweizer Runden.`,
        completedMatches,
        totalMatches
      };
    }

    const incompleteRound = rounds.find((round) => !isTtRaceRoundComplete(round));
    if (incompleteRound) {
      return {
        canExport: false,
        reason: `Runde ${incompleteRound.roundNumber} ist noch nicht vollständig erfasst.`,
        completedMatches,
        totalMatches
      };
    }

    return {
      canExport: totalMatches > 0 && completedMatches === totalMatches,
      reason: "Finaler click-TT Export bereit.",
      completedMatches,
      totalMatches
    };
  }

  function buildClickTtXmlPreview(roundContext = getRaceDayRoundContext()) {
    if (clickTtBridgeModule && activeTournament.clicktt?.rawXml) {
      try {
        const exportState = getTtRaceFinalExportState(activeTournament.ttRace);
        if (!exportState.canExport) {
          return [
            '<?xml version="1.0" encoding="UTF-8"?>',
            "<!-- click-TT Export noch nicht bereit -->",
            `<!-- ${escapeXmlText(exportState.reason)} -->`
          ].join("\n");
        }
        const result = clickTtBridgeModule.exportClickttTournamentResults(activeTournament, {
          allowEmpty: true
        });
        if (result.matches.length === 0) {
          return [
            '<?xml version="1.0" encoding="UTF-8"?>',
            "<!-- Noch keine exportierbaren Ergebnisse. -->",
            "<!-- Es wird bewusst keine leere <matches>-Liste als Vorschau ausgegeben. -->"
          ].join("\n");
        }
        const warningText = result.warnings.length
          ? `\n<!-- Hinweise: ${escapeXmlText(result.warnings.join(" | "))} -->`
          : "";
        return result.xml.trimEnd() + warningText;
      } catch (error) {
        return [
          '<?xml version="1.0" encoding="UTF-8"?>',
          "<!-- click-TT Export noch nicht bereit -->",
          `<!-- ${escapeXmlText(error.message || "Unbekannter Fehler")} -->`
        ].join("\n");
      }
    }

    const title =
      activeTournament.tournamentName?.trim() ||
      getTournamentLabel(activeTournament, getActiveTournamentIndex());
    const ttRacePlayerById = new Map((activeTournament.ttRace?.players ?? []).map((player) => [player.id, player]));
    const ttRaceMatches = (roundContext.currentRound?.matches ?? []).map((match) => ({
      table: match.table,
      status: match.status,
      playerA: ttRacePlayerById.get(match.playerAId)?.name || match.playerAId,
      playerB: ttRacePlayerById.get(match.playerBId)?.name || match.playerBId,
      score: formatSetScoreDisplay(match.sets)
    }));
    const matches = (ttRaceMatches.length > 0 ? ttRaceMatches : (roundContext.currentRound?.pairings ?? [])).slice(0, 8);
    const matchLines = matches.length
      ? matches
          .map(
            (pairing, index) =>
              `    <match table="${escapeXmlAttribute(pairing.table ?? index + 1)}" status="${escapeXmlAttribute(pairing.score || pairing.status === "completed" ? "complete" : "open")}">` +
              `<home>${escapeXmlText(pairing.playerA)}</home>` +
              `<away>${escapeXmlText(pairing.playerB)}</away>` +
              `<sets>${escapeXmlText(pairing.score || "")}</sets>` +
              `</match>`
          )
          .join("\n")
      : "    <!-- Keine Paarungen in dieser Runde -->";

    return [
      '<?xml version="1.0" encoding="UTF-8"?>',
      '<clickttResults source="TT-Race-MVP" adapter="demo">',
      `  <competition>${escapeXmlText(title)}</competition>`,
      `  <round number="${roundContext.currentRoundNumber}" label="${escapeXmlAttribute(roundContext.label)}">`,
      matchLines,
      "  </round>",
      "</clickttResults>"
    ].join("\n");
  }

  /** Gesamtergebnis eines TT-Race-Spiels ohne Satzdetails, z. B. „3:1". */
  function formatTtRaceTotalScore(setScore) {
    if (!setScore || typeof setScore !== "object") {
      return "";
    }

    const links = Number(setScore.a);
    const rechts = Number(setScore.b);
    if (!Number.isFinite(links) || !Number.isFinite(rechts)) {
      return "";
    }

    return `${links}:${rechts}`;
  }

  /**
   * Satzstand eines TT-Race-Spiels für die Anzeige: aus den Sätzen gezählt,
   * und wenn es keine gibt (Kurzform „3:1", B129), aus dem abgelegten
   * Gesamtergebnis. Ohne diesen Rückfall stand auf Beamer und Ergebniszettel
   * „erfasst" bzw. „offen" über einem längst gespielten Match.
   */
  function formatTtRaceMatchSummary(match) {
    return formatSetSummaryDisplay(match?.sets) || formatTtRaceTotalScore(match?.setScore);
  }

  function formatSetScoreDisplay(sets) {
    return (Array.isArray(sets) ? sets : [])
      .map((set) => {
        if (Array.isArray(set) && set.length >= 2) {
          return `${set[0]}:${set[1]}`;
        }

        if (set && typeof set === "object") {
          return `${set.a}:${set.b}`;
        }

        return "";
      })
      .filter(Boolean)
      .join(", ");
  }

  function formatSetSummaryDisplay(sets) {
    const summary = (Array.isArray(sets) ? sets : []).reduce(
      (result, set) => {
        const left = Array.isArray(set) ? Number(set[0]) : Number(set?.a);
        const right = Array.isArray(set) ? Number(set[1]) : Number(set?.b);

        if (!Number.isFinite(left) || !Number.isFinite(right) || left === right) {
          return result;
        }

        if (left > right) {
          result.left += 1;
        } else {
          result.right += 1;
        }

        return result;
      },
      { left: 0, right: 0 }
    );

    return summary.left + summary.right > 0 ? `${summary.left}:${summary.right}` : "";
  }

  function renderSetScoreSummaryPill(sets, { emptyText = "offen", showDetail = true, totalScore = null } = {}) {
    const summary = formatSetSummaryDisplay(sets) || formatTtRaceTotalScore(totalScore);
    const detail = formatSetScoreDisplay(sets);

    if (!summary) {
      return `<span class="set-score-summary-pill is-empty">${escapeHtml(emptyText)}</span>`;
    }

    return `
      <span class="set-score-summary-pill ${showDetail && detail ? "has-detail" : ""}">
        <strong>${escapeHtml(summary)}</strong>
        ${showDetail && detail ? `<small>${escapeHtml(detail)}</small>` : ""}
      </span>
    `;
  }

  function escapeXmlText(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function escapeXmlAttribute(value) {
    return escapeXmlText(value).replace(/"/g, "&quot;");
  }

  function getSelectedTemplate() {
    return tournamentTemplates.find((template) => template.id === templateSelect.value) || null;
  }

  function renderConfig() {
    // Beim TT-Race trägt die Turniertag-Hülle die Startliste (2cv2); der
    // private Eintragsbereich (2bv2) würde sie nur doppeln.
    const configContent = isTtRaceTournament()
      ? { top: "", details: "" }
      : activeTournament.mode === "team"
        ? renderTeamConfig()
        : activeTournament.mode === "groupsKnockout"
          ? renderGroupsKnockoutConfig()
          : renderRoundRobinConfig();

    configForm.innerHTML = configContent.top;
    configDetails.innerHTML = configContent.details;

    [configForm, configDetails].forEach((container) => {
      container.querySelectorAll("[data-action]").forEach((element) => {
        element.addEventListener("change", handleConfigInput);
      });

      container.querySelectorAll("[data-import-text]").forEach((element) => {
        element.addEventListener("input", handleParticipantImportTextInput);
      });

      container.querySelectorAll("[data-import-file]").forEach((element) => {
        element.addEventListener("change", handleParticipantImportFileSelection);
      });

      container.querySelectorAll("[data-import-team-name]").forEach((element) => {
        element.addEventListener("input", handleParticipantImportTeamNameInput);
      });

      container.querySelectorAll("[data-import-number-duplicates]").forEach((element) => {
        element.addEventListener("change", handleParticipantImportDuplicateOption);
      });

      container.querySelectorAll("[data-import-apply]").forEach((button) => {
        button.addEventListener("click", handleApplyParticipantImport);
      });

      container.querySelectorAll("[data-import-clear]").forEach((button) => {
        button.addEventListener("click", handleClearParticipantImport);
      });

      container.querySelectorAll("[data-draw-action]").forEach((button) => {
        button.addEventListener("click", handleDrawAction);
      });

      container.querySelectorAll("[data-open-view]").forEach((button) => {
        button.addEventListener("click", () => openWorkspaceView(button.dataset.openView));
      });

      container.querySelectorAll("[data-entry-remove]").forEach((button) => {
        button.addEventListener("click", () => handleRemoveEntry(button.dataset.entryRemove, Number(button.dataset.index)));
      });

      container.querySelectorAll("[data-draft-remove]").forEach((button) => {
        button.addEventListener("click", () => handleRemoveDraftLine(button.dataset.draftRemove, Number(button.dataset.index)));
      });

      container.querySelectorAll("[data-team-add]").forEach((button) => {
        button.addEventListener("click", () => handleAddTeamPlayer(button.dataset.teamAdd));
      });

      // "Liste einfügen" blendet den Import dieser Spalte ein.
      container.querySelectorAll("[data-team-paste]").forEach((button) => {
        button.addEventListener("click", () => {
          const panel = container.querySelector(`[data-team-paste-panel="${button.dataset.teamPaste}"]`);
          if (panel) {
            panel.hidden = !panel.hidden;
          }
        });
      });

      container.querySelectorAll("[data-open-example]").forEach((button) => {
        button.addEventListener("click", handleLoadExample);
      });

      container.querySelectorAll("[data-open-template]").forEach((button) => {
        button.addEventListener("click", handleLoadTemplate);
      });

      container.querySelectorAll("[data-race-action]").forEach((button) => {
        button.addEventListener("click", () => handleRaceAction(button));
      });

      container.querySelectorAll("[data-double-add]").forEach((button) => {
        button.addEventListener("click", handleAddDouble);
      });

      container.querySelectorAll("[data-double-remove]").forEach((button) => {
        button.addEventListener("click", handleRemoveDouble);
      });
    });
  }

  /**
   * 2bv2 — Teilnehmer für ein privates Turnier. Links eintragen, rechts
   * sofort die erkannte Liste. Spielmodus und Teilnehmerzahl gehören nicht
   * auf diesen Screen; sie liegen still in der Randspalte.
   */
  function renderRoundRobinConfig() {
    return {
      top: "",
      details: `
        <div class="work-split">
          <div class="work-main">
            <hr class="work-rule" />
            <h3 class="entry-title">Teilnehmer eintragen</h3>
            <p class="entry-lead">Privat genügt ein Name pro Zeile — Tobi bleibt Tobi. Ein Nachname ist nur nötig, wenn zwei gleich heißen.</p>
            ${renderParticipantEntry("roundRobin")}
          </div>
          ${renderParticipantEntryRail("roundRobin")}
        </div>
      `
    };
  }

  /** Textfeld links, erkannte oder eingetragene Namen rechts. */
  function renderParticipantEntry(targetKey) {
    const settings = getParticipantImportSettings(targetKey);
    const draft = getParticipantImportDraft(activeTournament.id)[targetKey];
    const preview = getParticipantImportPreview(targetKey);
    const importId = `${activeTournament.id}-${targetKey}`;
    const roster = getEntryRoster(targetKey);
    const showsDraft = preview.hasInput;
    const rows = showsDraft
      ? preview.displayNames.map((entry, index) => ({ name: preview.applyNames[index] || entry.name, index }))
      : roster.map((name, index) => ({ name, index }));

    return `
      <div data-import-panel="${escapeHtml(targetKey)}">
      <div class="entry-split">
        <div class="entry-input">
          <label for="participant-import-${escapeHtml(importId)}">Namen eintragen — ein Name pro Zeile</label>
          <textarea
            id="participant-import-${escapeHtml(importId)}"
            data-import-text="${escapeHtml(targetKey)}"
            rows="6"
            placeholder="${escapeHtml(settings.placeholder)}"
          >${escapeHtml(draft.text)}</textarea>
          <span class="entry-hint">Auch später jederzeit ergänzbar.</span>
        </div>

        <div class="entry-recognised">
          <h6 class="rail-heading" data-import-count>${escapeHtml(
            showsDraft ? formatImportCountHeading(preview.applyNames.length) : `Startliste · ${rows.length} Teilnehmer`
          )}</h6>
          <div data-import-preview="${escapeHtml(targetKey)}">
            ${renderEntryRows(rows, targetKey, showsDraft)}
          </div>
        </div>
      </div>

      <div class="work-action">
        <button class="primary-button" type="button" data-import-apply="${escapeHtml(targetKey)}" ${
          preview.applyNames.length === 0 ? "disabled" : ""
        }>Liste übernehmen</button>
        <span class="action-reason" data-import-hint>${
          showsDraft
            ? "Danach folgt die Auslosung der ersten Runde."
            : "Namen eintragen, dann übernehmen."
        }</span>
      </div>
      </div>
    `;
  }

  function renderEntryRows(rows, targetKey, isDraft) {
    if (rows.length === 0) {
      return '<p class="empty-note">Noch keine Namen eingetragen.</p>';
    }

    return rows
      .map(({ name, index }) => {
        const parts = String(name || "").trim().split(/\s+/);
        // "Spieler 1" ist ein Platzhalter, kein Vor- und Nachname.
        const hasNumericTail = parts.length > 1 && /^\d+$/.test(parts[parts.length - 1]);
        const first = hasNumericTail ? parts.join(" ") : parts[0] || "";
        const last = hasNumericTail ? "" : parts.slice(1).join(" ");

        return `
          <div class="entry-row">
            <span class="entry-nr">${index + 1}</span>
            <span class="entry-first">${escapeHtml(first)}</span>
            <span class="${last ? "entry-last" : "entry-last is-missing"}">${escapeHtml(last || "Nachname ergänzen")}</span>
            <button
              class="entry-remove"
              type="button"
              ${isDraft ? `data-draft-remove="${escapeHtml(targetKey)}"` : `data-entry-remove="${escapeHtml(targetKey)}"`}
              data-index="${index}"
              aria-label="${escapeHtml(name)} entfernen"
              title="Entfernen"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true" focusable="false">
                <path d="M6 6l12 12" /><path d="M18 6L6 18" />
              </svg>
            </button>
          </div>
        `;
      })
      .join("");
  }

  /**
   * Streicht eine Zeile aus dem noch nicht übernommenen Entwurf. Die
   * Startliste bleibt davon unberührt.
   */
  function handleRemoveDraftLine(targetKey, index) {
    const draft = getParticipantImportDraft(activeTournament.id)[targetKey];
    const lines = String(draft.text ?? "").split(/\r?\n/);
    const contentIndexes = lines
      .map((line, position) => ({ line, position }))
      .filter((entry) => entry.line.trim().length > 0)
      .map((entry) => entry.position);

    const target = contentIndexes[index];
    if (target === undefined) {
      return;
    }

    lines.splice(target, 1);
    draft.text = lines.join("\n");

    const textarea = configDetails.querySelector(`[data-import-text="${targetKey}"]`);
    if (textarea) {
      textarea.value = draft.text;
    }

    refreshParticipantImportPreview(targetKey);
  }

  function handleAddTeamPlayer(side) {
    updateActiveTournament((tournament) => {
      const key = side === "A" ? "teamAPlayers" : "teamBPlayers";
      const countKey = side === "A" ? "teamACount" : "teamBCount";
      const names = ensureLength(tournament.team[key], tournament.team[countKey], `Spieler ${side}`);
      names.push(`Spieler ${side}${names.length + 1}`);
      tournament.team[key] = names;
      tournament.team[countKey] = names.length;
    }, "Spieler hinzugefügt", { checkRoundBackups: true });
  }

  function handleRemoveEntry(targetKey, index) {
    if (!Number.isInteger(index)) {
      return;
    }

    updateActiveTournament((tournament) => {
      if (targetKey === "teamA" || targetKey === "teamB") {
        const key = targetKey === "teamA" ? "teamAPlayers" : "teamBPlayers";
        const countKey = targetKey === "teamA" ? "teamACount" : "teamBCount";
        const names = ensureLength(tournament.team[key], tournament.team[countKey], "Spieler");
        names.splice(index, 1);
        tournament.team[key] = names;
        tournament.team[countKey] = Math.max(1, names.length);
        return;
      }

      const names = ensureLength(
        tournament.roundRobin.playerNames,
        tournament.roundRobin.playerCount,
        "Spieler"
      );
      const statuses = tournament.roundRobin.playerStatuses ?? [];
      names.splice(index, 1);
      statuses.splice(index, 1);
      tournament.roundRobin.playerNames = names;
      tournament.roundRobin.playerStatuses = statuses;
      tournament.roundRobin.playerCount = Math.max(2, names.length);
    }, "Teilnehmer entfernt", { checkRoundBackups: true });
  }

  function getEntryRoster(targetKey) {
    if (targetKey === "teamA") {
      return ensureLength(activeTournament.team.teamAPlayers, activeTournament.team.teamACount, "Spieler A");
    }

    if (targetKey === "teamB") {
      return ensureLength(activeTournament.team.teamBPlayers, activeTournament.team.teamBCount, "Spieler B");
    }

    return ensureLength(
      activeTournament.roundRobin.playerNames,
      activeTournament.roundRobin.playerCount,
      "Spieler"
    );
  }

  /** Randspalte von 2bv2: offizieller Weg oben, Werkzeuge darunter. */
  function renderParticipantEntryRail(targetKey) {
    return `
      <aside class="work-rail" aria-label="Werkzeuge">
        <section class="rail-block">
          <h6 class="rail-heading">Offizielles Turnier</h6>
          <p class="rail-note">Die click-TT XML bringt Namen, IDs, Vereine und Q-TTR mit und ist Voraussetzung für den Ergebnis-Export.</p>
          <button class="secondary-button" type="button" data-race-action="choose-clicktt-file">click-TT XML wählen</button>
        </section>

        <hr class="hairline" />

        <section class="rail-block">
          <h6 class="rail-heading">Werkzeuge</h6>
          <div class="rail-links">
            <label class="link-button file-picker-button">
              CSV-Liste einlesen
              <input data-import-file="${escapeHtml(targetKey)}" type="file" accept=".csv,.txt,text/csv,text/plain" hidden />
            </label>
            <button class="link-button" type="button" data-open-example>Beispieldaten laden</button>
            <button class="link-button" type="button" data-open-template>Vorlage aus letztem Turnier</button>
          </div>
        </section>

        <hr class="hairline" />

        ${renderTournamentSettingsBlock()}
      </aside>
    `;
  }

  /**
   * Spielmodus, Teilnehmerzahl und Turniername stehen im Entwurf im
   * Assistenten. Für ein laufendes Turnier müssen sie erreichbar bleiben —
   * hier still am Ende der Randspalte statt oben auf der Arbeitsfläche.
   */
  function renderTournamentSettingsBlock() {
    return `
      <details class="rail-details">
        <summary>Turniereinstellungen</summary>
        <div class="rail-details-body">
          <label class="rail-field">
            <span>Turniername</span>
            <input data-action="tournamentName" type="text" value="${escapeHtml(activeTournament.tournamentName)}" placeholder="z. B. Vereinsabend" />
          </label>
          ${renderMatchModeField()}
          ${renderSettingsPlayerCountField()}
          ${renderScoringRulesToggle()}
        </div>
      </details>
    `;
  }

  /**
   * B108: Das Feld hing fest an `roundRobinCount` — auch dann, wenn der Block
   * aus der Gruppen+KO- oder Team-Konfiguration gerendert wurde. Dort zeigte
   * es den ruhenden Jeder-gegen-jeden-Wert an, und jede Eingabe mutierte still
   * das falsche Sub-Objekt: die sichtbare Teilnehmerzahl änderte sich nicht,
   * dafür das unsichtbare andere Turnier.
   */
  function renderSettingsPlayerCountField() {
    if (isTtRaceTournament()) {
      return `
        <p class="rail-note">Die Teilnehmerzahl ergibt sich im TT-Race aus der Startliste.</p>
      `;
    }

    if (activeTournament.mode === "groupsKnockout") {
      return `
        <label class="rail-field">
          <span>Anzahl der Teilnehmer</span>
          <input data-action="groupsKnockoutCount" type="number" min="4" max="100" value="${activeTournament.groupsKnockout.playerCount}" />
        </label>
      `;
    }

    if (activeTournament.mode === "team") {
      return `
        <label class="rail-field">
          <span>Spieler ${escapeHtml(activeTournament.team.teamAName || "Team A")}</span>
          <input data-action="teamACount" type="number" min="1" max="100" value="${activeTournament.team.teamACount}" />
        </label>
        <label class="rail-field">
          <span>Spieler ${escapeHtml(activeTournament.team.teamBName || "Team B")}</span>
          <input data-action="teamBCount" type="number" min="1" max="100" value="${activeTournament.team.teamBCount}" />
        </label>
      `;
    }

    return `
      <label class="rail-field">
        <span>Anzahl der Teilnehmer</span>
        <input data-action="roundRobinCount" type="number" min="2" max="100" value="${activeTournament.roundRobin.playerCount}" />
      </label>
    `;
  }

  function renderGroupsKnockoutConfig() {
    const names = ensureLength(
      activeTournament.groupsKnockout.playerNames,
      activeTournament.groupsKnockout.playerCount,
      "Spieler"
    );

    const placementOn = activeTournament.groupsKnockout.placementMatchesEnabled;
    const groupCount = activeTournament.groupsKnockout.groupCount;

    // 10a — die vier Einstellungen stehen als eine Zeile, abgeschlossen mit
    // einer Haarlinie; darunter die Gruppenaufteilung direkt sichtbar.
    return {
      top: "",
      details: `
        <div class="work-main">
          <hr class="work-rule" />

          <div class="settings-row">
            <label class="settings-item">
              <span>Teilnehmer</span>
              <input data-action="groupsKnockoutCount" type="number" min="4" max="100" value="${activeTournament.groupsKnockout.playerCount}" />
            </label>
            <label class="settings-item">
              <span>Gruppen</span>
              <input data-action="groupsKnockoutGroupCount" type="number" min="2" max="8" value="${groupCount}" />
            </label>
            <label class="settings-item">
              <span>Weiter je Gruppe</span>
              <input data-action="groupsKnockoutQualifiers" type="number" min="1" max="10" value="${activeTournament.groupsKnockout.qualifiersPerGroup}" />
            </label>
            <div class="settings-item settings-item-wide">
              <span>Spiel um Platz 3</span>
              <span class="seg">
                <label class="seg-opt">
                  <input data-action="groupsKnockoutPlacement" type="radio" name="groupsPlacement" value="yes" ${placementOn ? "checked" : ""} />
                  <span>Ja</span>
                </label>
                <label class="seg-opt">
                  <input data-action="groupsKnockoutPlacement" type="radio" name="groupsPlacement" value="no" ${placementOn ? "" : "checked"} />
                  <span>Nein</span>
                </label>
              </span>
            </div>
          </div>

          <h3 class="section-subheading">Gruppenaufteilung</h3>
          <p class="work-note">Die Teilnehmer werden reihum verteilt: Position 1 in Gruppe A, Position 2 in Gruppe B, Position 3 wieder in Gruppe A und so weiter. Vor den Spielen ist niemand qualifiziert.</p>

          <div class="group-split">
            ${Array.from({ length: groupCount }, (_, groupIndex) => {
              const groupNames = names.filter((_, index) => index % groupCount === groupIndex);
              return `
                <div class="group-split-column">
                  <h4 class="rail-heading">Gruppe ${String.fromCharCode(65 + groupIndex)}</h4>
                  ${groupNames
                    .map((name, position) => {
                      const nameIndex = position * groupCount + groupIndex;
                      return `
                        <label class="group-split-row">
                          <span class="roster-number">${position + 1}</span>
                          <input data-action="groupsKnockoutName" data-index="${nameIndex}" type="text" value="${escapeHtml(name)}" placeholder="Spieler ${nameIndex + 1}" />
                        </label>
                      `;
                    })
                    .join("")}
                </div>
              `;
            }).join("")}
          </div>

          <div class="work-action">
            <button class="primary-button" type="button" data-open-view="output">Gruppenphase öffnen</button>
            ${renderRandomDrawSection(
              "shuffle-groups-knockout",
              "Teilnehmer neu auslosen",
              "",
              "Mischt die Teilnehmer zufällig und verteilt sie danach neu auf die Gruppen.",
              hasGroupsKnockoutDrawStarted(activeTournament)
            )}
            <span class="action-reason">${
              hasGroupsKnockoutDrawStarted(activeTournament)
                ? "Die Auslosung ist nach dem ersten Ergebnis gesperrt."
                : "Die Aufteilung bleibt änderbar, solange kein Ergebnis erfasst ist."
            }</span>
          </div>

          ${renderTournamentSettingsBlock()}
        </div>
      `
    };
  }

  /** Die Auslosung steht als stiller Knopf neben der Hauptaktion, nicht als Kasten. */
  function renderRandomDrawSection(action, buttonLabel, title, description, locked) {
    const lockReason = "Nach dem ersten Ergebnis gesperrt.";
    return `
      <button
        class="secondary-button"
        type="button"
        data-draw-action="${escapeHtml(action)}"
        ${locked ? "disabled" : ""}
        title="${escapeHtml(locked ? lockReason : description)}"
      >${escapeHtml(buttonLabel)}</button>
    `;
  }

  /**
   * 8a — Aufstellung: beide Teams nebeneinander, getrennt durch eine
   * senkrechte Haarlinie. Doppel sind ein eigener, ausdrücklich optionaler
   * Abschnitt darunter.
   */
  function renderTeamConfig() {
    const doubles = Array.isArray(activeTournament.team.doubles) ? activeTournament.team.doubles : [];
    const teamADatalistId = `team-a-players-${activeTournament.id}`;
    const teamBDatalistId = `team-b-players-${activeTournament.id}`;
    const hasStarted = Object.keys(activeTournament.team.results ?? {}).length > 0;

    return {
      top: "",
      details: `
        <div class="work-main team-setup">
          <hr class="work-rule" />

          <div class="team-split">
            ${renderTeamRoster("A")}
            ${renderTeamRoster("B")}
          </div>

          <section class="team-doubles">
            <div class="work-head">
              <h3>Doppel</h3>
              <button class="secondary-button" type="button" data-double-add>Doppel hinzufügen</button>
            </div>
            <p class="entry-lead">Optional. Namen aus der Aufstellung wählen oder reine Doppelspieler frei eintippen.</p>
            ${
              doubles.length > 0
                ? `<div class="double-list">
                    ${doubles
                      .map((entry, index) => renderDoubleConfigCard(entry, index, teamADatalistId, teamBDatalistId))
                      .join("")}
                  </div>`
                : '<p class="empty-note">Noch keine Doppel angelegt.</p>'
            }
            <datalist id="${teamADatalistId}">${renderTeamPlayerOptions(
              ensureLength(activeTournament.team.teamAPlayers, activeTournament.team.teamACount, "Spieler A")
            )}</datalist>
            <datalist id="${teamBDatalistId}">${renderTeamPlayerOptions(
              ensureLength(activeTournament.team.teamBPlayers, activeTournament.team.teamBCount, "Spieler B")
            )}</datalist>
          </section>

          <div class="work-action">
            <button class="primary-button" type="button" data-open-view="output">Runde 1 öffnen</button>
            <span class="action-reason">${
              hasStarted
                ? "Es sind bereits Ergebnisse erfasst."
                : "Aufstellung und Doppel bleiben änderbar, solange keine Runde erfasst ist."
            }</span>
          </div>

          ${renderTournamentSettingsBlock()}
        </div>
      `
    };
  }

  /** Eine Teamspalte: Name und Größe oben, darunter die Aufstellung. */
  function renderTeamRoster(side) {
    const isA = side === "A";
    const names = ensureLength(
      isA ? activeTournament.team.teamAPlayers : activeTournament.team.teamBPlayers,
      isA ? activeTournament.team.teamACount : activeTournament.team.teamBCount,
      `Spieler ${side}`
    );
    const statuses = (isA ? activeTournament.team.teamAPlayerStatuses : activeTournament.team.teamBPlayerStatuses) ?? [];
    const teamName = isA ? activeTournament.team.teamAName : activeTournament.team.teamBName;

    return `
      <div class="team-column">
        <div class="team-column-head">
          <label class="team-name-field">
            <span>Teamname ${side} · ${isA ? "Zeilen" : "Spalten"}</span>
            <input data-action="team${side}Name" type="text" value="${escapeHtml(teamName)}" placeholder="Team ${side}" />
          </label>
          <label class="team-count-field">
            <span>Spieler</span>
            <input data-action="team${side}Count" type="number" min="1" max="100" value="${names.length}" />
          </label>
        </div>

        <div class="team-roster">
          ${names
            .map((name, index) => {
              const status = PLAYER_STATUSES[statuses[index]] ? statuses[index] : "active";
              return `
                <div class="team-roster-row ${status === "active" ? "" : "is-muted"}">
                  <span class="entry-nr">${index + 1}</span>
                  <input
                    class="team-roster-name"
                    data-action="team${side}Player"
                    data-index="${index}"
                    type="text"
                    value="${escapeHtml(name)}"
                    placeholder="Spieler ${index + 1}"
                    aria-label="Spieler ${index + 1} in Team ${side}"
                  />
                  <span class="team-roster-status">${escapeHtml(PLAYER_STATUSES[status].label)}</span>
                  <button
                    class="entry-remove"
                    type="button"
                    data-entry-remove="team${side}"
                    data-index="${index}"
                    aria-label="${escapeHtml(name)} entfernen"
                    title="Entfernen"
                  >
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true" focusable="false">
                      <path d="M6 6l12 12" /><path d="M18 6L6 18" />
                    </svg>
                  </button>
                </div>
              `;
            })
            .join("")}
        </div>

        <div class="action-row team-column-actions">
          <button class="secondary-button" type="button" data-team-add="${side}">Spieler hinzufügen</button>
          <button class="link-button" type="button" data-team-paste="${side}">Liste einfügen</button>
        </div>

        <div class="team-paste" data-team-paste-panel="${side}" hidden>
          ${renderParticipantImportSection(isA ? "teamA" : "teamB")}
        </div>
      </div>
    `;
  }


  function renderParticipantStatusSelect(action, index, selectedStatus) {
    const normalizedStatus = PLAYER_STATUSES[selectedStatus] ? selectedStatus : "active";
    return `
      <select class="participant-status-select" data-action="${action}" data-index="${index}">
        ${PLAYER_STATUS_ORDER.map(
          (statusId) => `
            <option value="${statusId}" ${normalizedStatus === statusId ? "selected" : ""}>
              ${escapeHtml(PLAYER_STATUSES[statusId].label)}
            </option>
          `
        ).join("")}
      </select>
    `;
  }


  function renderScheduleConfigSection() {
    const schedule = activeTournament.schedule;
    const fieldInputs = schedule.fieldNames
      .map((name, index) => [
        "                <label>",
        "                  <span>Name Tisch " + (index + 1) + "</span>",
        "                  <input data-sheet-action=\"scheduleFieldName\" data-index=\"" + index + "\" type=\"text\" value=\"" + escapeHtml(name) + "\" placeholder=\"Tisch " + (index + 1) + "\" />",
        "                </label>"
      ].join(""))
      .join("");

    return [
      "      <section class=\"table-card schedule-config-section\">",
      "        <div class=\"section-heading compact\">",
      "          <div>",
      "            <h3>Spielplan</h3>",
      "            <p>Optionaler Zeitplan mit Tischen, Uhrzeiten und Puffer.</p>",
      "          </div>",
      "        </div>",
      "        <label class=\"double-round-toggle schedule-enable-toggle\">",
      "          <input data-sheet-action=\"scheduleEnabled\" type=\"checkbox\" " + (schedule.enabled ? "checked" : "") + " />",
      "          <span>Spielplan verwenden</span>",
      "        </label>",
      schedule.enabled
        ? [
      "        <div class=\"schedule-config-grid\">",
      "          <label><span>Anzahl Tische</span><input data-sheet-action=\"scheduleFieldCount\" type=\"number\" min=\"1\" max=\"20\" value=\"" + schedule.fieldCount + "\" /></label>",
      "          <label><span>Startzeit</span><input data-sheet-action=\"scheduleStartTime\" type=\"time\" value=\"" + escapeHtml(schedule.startTime) + "\" /></label>",
      "          <label><span>Spieldauer je Spiel (Min.)</span><input data-sheet-action=\"scheduleMatchDuration\" type=\"number\" min=\"1\" max=\"240\" value=\"" + schedule.matchDurationMinutes + "\" /></label>",
      "          <label><span>Pause/Puffer (Min.)</span><input data-sheet-action=\"scheduleBreak\" type=\"number\" min=\"0\" max=\"120\" value=\"" + schedule.breakMinutes + "\" /></label>",
      "        </div>",
      "        <div class=\"field-name-grid\">",
      fieldInputs,
      "        </div>"
          ].join("")
        : "        <p class=\"muted-text\">Aktiviere den Spielplan nur, wenn du konkrete Uhrzeiten und Tische nutzen möchtest.</p>",
      "      </section>"
    ].join("");
  }
  function renderParticipantImportSection(targetKey) {
    const settings = getParticipantImportSettings(targetKey);
    const draft = getParticipantImportDraft(activeTournament.id)[targetKey];
    const preview = getParticipantImportPreview(targetKey);
    const importId = activeTournament.id + "-" + targetKey;
    const teamNameField = settings.hasTeamName
      ? [
          "          <label class=\"participant-import-team-name\">",
          "            <span>Teamname aus Import oder manuell</span>",
          "            <input data-import-team-name=\"" + targetKey + "\" type=\"text\" value=\"" + escapeHtml(draft.teamName) + "\" placeholder=\"" + escapeHtml(settings.teamNamePlaceholder) + "\" />",
          "          </label>"
        ].join("")
      : "";
    const fileNote = draft.fileName
      ? "<span class=\"participant-import-file-note\">" + escapeHtml(draft.fileName) + " geladen</span>"
      : "";

    return [
      "        <section class=\"participant-import-section\" data-import-panel=\"" + targetKey + "\">",
      "          <h3 class=\"section-subheading\">Teilnehmer einfügen</h3>",
      "          <p class=\"work-note\">" + escapeHtml(settings.description) + "</p>",
      "          <div class=\"import-split\">",
      "            <div class=\"import-entry\">",
      teamNameField,
      "          <label class=\"participant-import-textarea\" for=\"participant-import-" + importId + "\">",
      "            <span>" + escapeHtml(settings.textareaLabel) + "</span>",
      "            <textarea id=\"participant-import-" + importId + "\" data-import-text=\"" + targetKey + "\" rows=\"6\" placeholder=\"" + escapeHtml(settings.placeholder) + "\">" + escapeHtml(draft.text) + "</textarea>",
      "          </label>",
      "          <div class=\"participant-import-toolbar\">",
      "            <label class=\"file-picker-button ghost-button\">",
      "              CSV-Datei laden",
      "              <input data-import-file=\"" + targetKey + "\" type=\"file\" accept=\".csv,.txt,text/csv,text/plain\" hidden />",
      "            </label>",
      "            <label class=\"participant-import-checkbox\">",
      "              <input data-import-number-duplicates=\"" + targetKey + "\" type=\"checkbox\" " + (draft.numberDuplicates ? "checked" : "") + " />",
      "              <span>Doppelte Namen automatisch nummerieren</span>",
      "            </label>",
      fileNote,
      "          </div>",
      "          <div class=\"participant-import-actions\">",
      "            <button class=\"primary-button\" type=\"button\" data-import-apply=\"" + targetKey + "\" " + (preview.applyNames.length === 0 ? "disabled" : "") + ">Übernehmen</button>",
      "            <button class=\"ghost-button\" type=\"button\" data-import-clear=\"" + targetKey + "\">Eingabe leeren</button>",
      "          </div>",
      "            </div>",
      "            <div class=\"import-preview-column\">",
      "              <h4 class=\"rail-heading\" data-import-count>" + escapeHtml(formatImportCountHeading(preview.applyNames.length)) + "</h4>",
      "              <div class=\"participant-import-preview\" data-import-preview=\"" + targetKey + "\">",
      renderParticipantImportPreview(targetKey),
      "              </div>",
      "            </div>",
      "          </div>",
      "        </section>"
    ].join("");
  }

  function formatImportCountHeading(count) {
    return `Erkannt · ${count} Teilnehmer`;
  }

  function renderParticipantImportPreview(targetKey) {
    const preview = getParticipantImportPreview(targetKey);

    if (!preview.hasInput) {
      return "<p class=\"participant-import-empty\">Noch keine Namen eingefügt.</p>";
    }

    if (preview.names.length === 0) {
      return "<p class=\"participant-import-warning\">Keine verwertbaren Namen gefunden.</p>";
    }

    const previewItems = preview.displayNames.slice(0, 12).map((entry, index) => {
      const appliedName = preview.applyNames[index] || entry.name;
      const duplicateBadge = entry.isDuplicate
        ? " <span class=\"duplicate-badge\">doppelt</span>"
        : "";
      const numberedBadge = appliedName !== entry.name
        ? " <span class=\"numbered-badge\">wird zu " + escapeHtml(appliedName) + "</span>"
        : "";
      // Der Nachname ist beim privaten Turnier freiwillig; fehlt er, steht es
      // still daneben statt als Fehler.
      const lastNameHint = entry.name.trim().split(/\s+/).length < 2
        ? " <span class=\"missing-lastname-hint\">Nachname ergänzen</span>"
        : "";
      return "<li class=\"" + (entry.isDuplicate ? "is-duplicate" : "") + "\"><span>" + escapeHtml(entry.name) + "</span>" + lastNameHint + duplicateBadge + numberedBadge + "</li>";
    }).join("");
    const remainingCount = Math.max(0, preview.displayNames.length - 12);
    const remainingItem = remainingCount > 0
      ? "<li class=\"participant-import-more\">+" + remainingCount + " weitere</li>"
      : "";
    const duplicateNote = preview.duplicateCount > 0
      ? "<p class=\"participant-import-warning\">" + preview.duplicateCount + " doppelte Namensstelle" + (preview.duplicateCount === 1 ? "" : "n") + " markiert.</p>"
      : "";
    const limitNote = preview.ignoredCount > 0
      ? "<p class=\"participant-import-warning\">Maximal 100 Teilnehmer sind erlaubt. Nicht übernommen: " + preview.ignoredCount + " Name" + (preview.ignoredCount === 1 ? "" : "n") + ".</p>"
      : "";
    const teamNote = preview.teamName
      ? "<p class=\"participant-import-team-note\">Teamname: " + escapeHtml(preview.teamName) + "</p>"
      : "";

    return [
      "<div class=\"participant-import-summary\">",
      "<strong>Diese " + preview.applyNames.length + " Teilnehmer werden übernommen.</strong>",
      teamNote,
      duplicateNote,
      limitNote,
      "</div>",
      "<ul class=\"participant-import-list\">",
      previewItems,
      remainingItem,
      "</ul>"
    ].join("");
  }

  function renderTeamPlayerOptions(names) {
    return [...new Set(names.filter(Boolean))]
      .map((name) => `<option value="${escapeHtml(name)}"></option>`)
      .join("");
  }

  function renderDoubleConfigCard(entry, index, teamADatalistId, teamBDatalistId) {
    return `
      <article class="double-config-card">
        <div class="double-config-header">
          <strong class="double-config-title">Doppel-Aufstellung ${index + 1}</strong>
          <button
            class="ghost-button danger"
            type="button"
            data-double-remove
            data-double-id="${escapeHtml(entry.id)}"
          >
            Entfernen
          </button>
        </div>
        <div class="dual-names double-config-dual">
          <div class="name-section">
            <div class="section-heading">
              <h3>${escapeHtml(activeTournament.team.teamAName || "Team A")}</h3>
              <p>Spieler für die Doppel-Aufstellung von ${escapeHtml(activeTournament.team.teamAName || "Team A")}.</p>
            </div>
            <div class="name-grid stacked-name-grid">
              <label>
                <span>Spieler 1</span>
                <input
                  data-action="doubleTeamAPlayer1"
                  data-double-id="${escapeHtml(entry.id)}"
                  type="text"
                  list="${teamADatalistId}"
                  value="${escapeHtml(entry.teamAPlayer1 || "")}"
                  placeholder="Spieler auswählen oder frei eingeben"
                />
              </label>
              <label>
                <span>Spieler 2</span>
                <input
                  data-action="doubleTeamAPlayer2"
                  data-double-id="${escapeHtml(entry.id)}"
                  type="text"
                  list="${teamADatalistId}"
                  value="${escapeHtml(entry.teamAPlayer2 || "")}"
                  placeholder="Spieler auswählen oder frei eingeben"
                />
              </label>
            </div>
          </div>
          <div class="name-section">
            <div class="section-heading">
              <h3>${escapeHtml(activeTournament.team.teamBName || "Team B")}</h3>
              <p>Spieler für die Doppel-Aufstellung von ${escapeHtml(activeTournament.team.teamBName || "Team B")}.</p>
            </div>
            <div class="name-grid stacked-name-grid">
              <label>
                <span>Spieler 1</span>
                <input
                  data-action="doubleTeamBPlayer1"
                  data-double-id="${escapeHtml(entry.id)}"
                  type="text"
                  list="${teamBDatalistId}"
                  value="${escapeHtml(entry.teamBPlayer1 || "")}"
                  placeholder="Spieler auswählen oder frei eingeben"
                />
              </label>
              <label>
                <span>Spieler 2</span>
                <input
                  data-action="doubleTeamBPlayer2"
                  data-double-id="${escapeHtml(entry.id)}"
                  type="text"
                  list="${teamBDatalistId}"
                  value="${escapeHtml(entry.teamBPlayer2 || "")}"
                  placeholder="Spieler auswählen oder frei eingeben"
                />
              </label>
            </div>
          </div>
        </div>
      </article>
    `;
  }

  /**
   * Aufgeklappte Blöcke überleben das Neuzeichnen. Ohne das schließt jeder
   * Klick auf „Satzdetails einblenden" die Matrix, in der man gerade steht —
   * die Schaltfläche sitzt ja selbst in dem Block.
   *
   * B027: Die Sonderstatus-Klappen tragen alle denselben Summary-Text („!").
   * Wer nach dem Text schlüsselt, öffnet nach dem Neuzeichnen alle acht, sobald
   * irgendwo eine offen war. Deshalb zählt jetzt `data-details-id`; nur wo es
   * fehlt, bleibt der Text die Notlösung.
   */
  function getDetailsStateKey(entry) {
    return (entry.dataset.detailsId || entry.querySelector("summary")?.textContent || "").trim();
  }

  /**
   * Die Sonderstatus-Klappe wird bewusst NICHT gerettet: sie ist ein
   * Überlagerungspanel über der nächsten Zeile und hat ihre Arbeit getan,
   * sobald der Status steht. Ein fremder Commit darf sie nicht aufreißen.
   */
  function isRestorableDetails(entry) {
    return !entry.classList.contains("match-anomaly-control");
  }

  function readOpenDetailsState(container) {
    const open = new Set();
    container.querySelectorAll("details").forEach((entry) => {
      if (!entry.open || !isRestorableDetails(entry)) {
        return;
      }
      const key = getDetailsStateKey(entry);
      if (key) {
        open.add(key);
      }
    });
    return open;
  }

  function restoreOpenDetailsState(container, open) {
    if (!open || open.size === 0) {
      return;
    }
    container.querySelectorAll("details").forEach((entry) => {
      if (!isRestorableDetails(entry)) {
        return;
      }
      const key = getDetailsStateKey(entry);
      if (key && open.has(key)) {
        entry.open = true;
      }
    });
  }

  // ── Fokus überlebt das Neuzeichnen (B020/B078) ────────────────────────────
  // Die Merkmale dazu (FOCUS_MEMO_FIELDS, pendingChainFocus …) stehen ganz oben
  // bei den übrigen Konstanten: hier unten wären sie beim ersten Zeichnen noch
  // nicht initialisiert (G0 — genau daran starb schon einmal die halbe
  // Randspalte).

  function escapeAttributeValue(value) {
    return String(value ?? "").replaceAll("\\", "\\\\").replaceAll('"', '\\"');
  }

  function describeFocusField(element, container) {
    if (!element || !container || !container.contains(element)) {
      return null;
    }

    const field = FOCUS_MEMO_FIELDS.find((entry) => element.dataset?.[entry.prop] != null);
    if (!field) {
      return null;
    }

    const value = element.dataset[field.prop];
    const selector = `[${field.attribute}="${escapeAttributeValue(value)}"]`;
    const twins = [...container.querySelectorAll(selector)];

    return {
      selector,
      scopeProp: field.scopeProp,
      scopeValue: field.scopeProp ? element.dataset[field.scopeProp] || "" : null,
      index: Math.max(0, twins.indexOf(element))
    };
  }

  function findFocusField(container, memo) {
    if (!memo) {
      return null;
    }

    const candidates = [...container.querySelectorAll(memo.selector)].filter(
      (element) => !memo.scopeProp || (element.dataset[memo.scopeProp] || "") === memo.scopeValue
    );
    return candidates[memo.index] || candidates[0] || null;
  }

  function readFocusMemo(container) {
    const memo = describeFocusField(document.activeElement, container);
    if (!memo) {
      return null;
    }

    const active = document.activeElement;
    return {
      ...memo,
      selectionStart: typeof active.selectionStart === "number" ? active.selectionStart : null,
      selectionEnd: typeof active.selectionEnd === "number" ? active.selectionEnd : null
    };
  }

  function restoreFocusMemo(container, memo) {
    const target = findFocusField(container, memo);
    if (!target || target.disabled) {
      return false;
    }

    target.focus({ preventScroll: true });
    if (memo.selectionStart != null && typeof target.setSelectionRange === "function") {
      try {
        target.setSelectionRange(memo.selectionStart, memo.selectionEnd ?? memo.selectionStart);
      } catch {
        // Feldtypen ohne Auswahlbereich (z. B. select) haben keine Marke.
      }
    }
    return true;
  }

  function isOpenChainField(element) {
    return !element.disabled && element.offsetParent !== null;
  }

  /**
   * B078: Enter geht zum nächsten OFFENEN Spiel in Anzeigereihenfolge — nicht
   * zum nächsten DOM-Element. Ist in der Liste nichts mehr offen, bleibt der
   * Fokus stehen, statt auf BODY zu fallen.
   */
  function applyPendingChainFocus(container) {
    const source = findFocusField(container, pendingChainFocus);
    if (!source) {
      return false;
    }

    const scopeRoot = source.closest(CHAIN_CONTAINER_SELECTOR) || container;
    const fields = [...scopeRoot.querySelectorAll(CHAIN_FIELD_SELECTOR)].filter(isOpenChainField);
    const startIndex = fields.indexOf(source);

    if (startIndex >= 0) {
      for (let step = 1; step <= fields.length; step += 1) {
        const candidate = fields[(startIndex + step) % fields.length];
        if (!candidate.value.trim()) {
          candidate.focus({ preventScroll: true });
          candidate.select?.();
          return true;
        }
      }
    }

    if (source.disabled || source.offsetParent === null) {
      return false;
    }
    source.focus({ preventScroll: true });
    return true;
  }

  /**
   * Die oberste Überschrift der Randspalte trägt die goldene Linie, die mit
   * der Linie der Arbeitsfläche fluchtet. Welcher Block oben steht, hängt vom
   * Format ab — deshalb wird die Marke nach dem Zeichnen gesetzt und nicht in
   * jedem Renderpfad einzeln.
   */
  function markRailStart() {
    if (!sheetMeta) {
      return;
    }
    sheetMeta.querySelectorAll(".rail-heading.is-rail-start").forEach((heading) => {
      heading.classList.remove("is-rail-start");
    });
    sheetMeta.querySelector(".rail-heading")?.classList.add("is-rail-start");
  }

  /**
   * Abschluss eines Turniers. Solange ein Turnier offen ist, kann jedes
   * Ergebnis noch geändert werden — am Turniertag richtig, danach nicht mehr.
   * Der Abschluss friert den Stand ein und macht das Blatt zur Urkunde; er ist
   * umkehrbar, weil auch nach dem letzten Spiel noch ein Fehler auffallen kann.
   */
  /**
   * B116: `closedAt` überlebte bisher den Formatwechsel. Ein abgeschlossenes
   * Jeder-gegen-jeden, das über click-TT-Import oder Demodaten zum TT-Race
   * wurde, blieb „abgeschlossen" — mit einer Sperre, die für das neue Format
   * gar nicht mehr gilt. Der Abschluss gehört zu dem Format, in dem er
   * ausgesprochen wurde.
   */
  function getTournamentFormatKey(tournament = activeTournament) {
    return isTtRaceTournament(tournament) ? "ttRace" : tournament?.mode || "roundRobin";
  }

  function isTournamentClosed() {
    if (!activeTournament?.closedAt) {
      return false;
    }
    const closedMode = activeTournament.closedMode;
    return !closedMode || closedMode === getTournamentFormatKey();
  }

  function getMatchProgress() {
    // TT-Race hat keinen Vollplan: `analysis` traegt hier die
    // Jeder-gegen-jeden-Rechnung (bei 16 Teilnehmern 120 Spiele), waehrend
    // das Schweizer System nur die ausgelosten Runden spielt (6 x 8 = 48).
    // Ohne diese Weiche konnte ein fertig gespieltes TT-Race nie als fertig
    // gelten: Urkunde und Siegerliste druckten fuer immer "Noch 120 von 120
    // Spielen offen" — zwei erfundene Zahlen auf Papier (Welle-4-Pruefer).
    if (isTtRaceTournament()) {
      const lauf = getTtRaceProgress();
      const gesamt = Number(lauf?.totalMatches ?? 0);
      const erfasst = Number(lauf?.completedMatches ?? 0);
      const offen = lauf?.complete ? 0 : Math.max(0, gesamt - erfasst);
      // Solange nicht alle vorgesehenen Runden ausgelost sind, ist das Turnier
      // nicht fertig — auch wenn die bisherigen Spiele alle erfasst sind.
      const offeneRunden = Math.max(0, Number(lauf?.maxRounds ?? 0) - Number(lauf?.playedRounds ?? 0));
      // `offen` ist die Zahl, an der der Abschluss haengt — sie kann aus
      // Spielen ODER aus noch nicht ausgelosten Runden kommen. Welche Einheit
      // sie gerade hat, steht in `einheit`; ohne diese Angabe druckte die App
      // "Noch 3 von 18 Spielen offen (18 erfasst)": drei fehlende RUNDEN,
      // ausgegeben als Spiele (B122-Nachpruefung, Welle 5).
      return {
        gesamt,
        erfasst,
        offen: offen > 0 ? offen : offeneRunden,
        offeneSpiele: offen,
        offeneRunden,
        einheit: offen > 0 ? "spiele" : offeneRunden > 0 ? "runden" : "fertig",
        maxRunden: Number(lauf?.maxRounds ?? 0),
        gespielteRunden: Number(lauf?.playedRounds ?? 0)
      };
    }

    const gesamt = Number(analysis?.totalMatches ?? 0);
    const erfasst = Number(analysis?.completedMatches ?? 0);
    const offen = Math.max(0, gesamt - erfasst);
    return {
      gesamt,
      erfasst,
      offen,
      offeneSpiele: offen,
      offeneRunden: 0,
      einheit: offen > 0 ? "spiele" : "fertig"
    };
  }

  function renderTournamentClosingBanner() {
    if (!isTournamentClosed()) {
      return "";
    }
    return `
      <div class="tournament-closed-banner">
        <div>
          <strong>Turnier abgeschlossen</strong>
          <p>Seit ${escapeHtml(formatDateTime(activeTournament.closedAt))}. Die Ergebnisse sind gesperrt — der Stand unten ist der Endstand.</p>
        </div>
        <button class="secondary-button" type="button" data-tournament-close="reopen">Wieder öffnen</button>
      </div>
      ${renderFinalStandingsBlock()}
    `;
  }

  /**
   * Der Endstand steht bei einem abgeschlossenen Turnier oben, nicht
   * aufklappbar weiter unten: er ist jetzt der Inhalt der Seite.
   */
  function renderFinalStandingsBlock() {
    if (activeTournament.mode === "team") {
      return `
        <section class="final-standings">
          <h3>Endstand</h3>
          <div class="table-wrapper">${renderTeamRankingTable(analysis.playerRanking ?? [])}</div>
        </section>
      `;
    }
    if (activeTournament.mode === "groupsKnockout") {
      const stand = analysis.finalStandings ?? [];
      if (stand.length === 0) {
        return "";
      }
      return `
        <section class="final-standings">
          <h3>Endstand</h3>
          <div class="table-wrapper">${renderFinalStandingsTable(stand)}</div>
        </section>
      `;
    }
    return `
      <section class="final-standings">
        <h3>Endstand</h3>
        <div class="table-wrapper">${renderRoundRobinRankingTable(analysis.ranking ?? [])}</div>
      </section>
    `;
  }

  /**
   * Genau eine Hauptaktion je Screen. Sind alle Spiele erfasst, ist die
   * Hauptaktion der Abschluss — und zwar an der Stelle, an der eben noch
   * "Weiter zu Runde N" stand. Ein ausgegrauter Rundenknopf oben und ein
   * zweiter Knopf weit darunter sind zwei Hauptaktionen, von denen eine tot
   * ist.
   */
  function placeClosingAction() {
    if (isTournamentClosed()) {
      return;
    }
    const { gesamt, offen } = getMatchProgress();
    if (gesamt === 0 || offen > 0) {
      return;
    }

    // Im TT-Race heisst die Hauptaktion nicht "Weiter zu Runde N", sondern
    // "Nächste Schweizer Runde erzeugen" — ohne diesen zweiten Selektor
    // erschien der Abschluss dort nie, und ein fertig gespieltes TT-Race liess
    // sich nicht abschliessen (Welle-4-Pruefer).
    const rundenKnopf = tournamentSheet.querySelector(
      '.work-action .primary-button[data-round-shift], .work-action .primary-button[data-race-action="generate-swiss-round"]'
    );
    if (!rundenKnopf) {
      return;
    }

    const abschluss = document.createElement("button");
    abschluss.className = "primary-button";
    abschluss.type = "button";
    abschluss.dataset.tournamentClose = "close";
    abschluss.textContent = "Turnier abschließen";
    rundenKnopf.replaceWith(abschluss);

    const grund = abschluss.parentElement?.querySelector(".action-reason");
    if (grund) {
      grund.textContent = "Alle Spiele sind erfasst. Nach dem Abschluss sind die Ergebnisse gesperrt.";
    }
  }

  /**
   * Ein abgeschlossenes Turnier lässt sich nicht mehr bearbeiten. Gesperrt wird
   * nach dem Zeichnen und über alle Formate hinweg — so kann kein Renderpfad
   * die Sperre vergessen.
   */
  function lockClosedTournament() {
    if (!isTournamentClosed()) {
      return;
    }
    // B116: `[data-race-action]` fehlte in dieser Liste — im abgeschlossenen
    // TT-Race liessen sich Runden weiter auslosen und Teilnehmer aendern.
    tournamentSheet
      .querySelectorAll(
        "input, select, textarea, button[data-round-shift], [data-draw-action], [data-race-action], [data-tie-decide]"
      )
      .forEach((element) => {
        if (element.dataset.tournamentClose) {
          return;
        }
        element.disabled = true;
      });
  }

  function handleTournamentClose(event) {
    const modus = event.currentTarget.dataset.tournamentClose;
    if (modus === "close") {
      const { offen } = getMatchProgress();
      if (offen > 0) {
        return;
      }
      storeRoundCheckpoint("Vor dem Abschluss");
      updateActiveTournament((tournament) => {
        tournament.closedAt = new Date().toISOString();
        tournament.closedMode = getTournamentFormatKey(tournament);
      }, "Turnier abgeschlossen");
      showInfo("Turnier abgeschlossen. Die Ergebnisse sind jetzt gesperrt.");
      return;
    }

    updateActiveTournament((tournament) => {
      tournament.closedAt = null;
      tournament.closedMode = "";
    }, "Turnier wieder geöffnet");
    showInfo("Turnier wieder geöffnet — Ergebnisse lassen sich wieder ändern.");
  }

  function renderTournamentSheet() {
    const openDetails = readOpenDetailsState(tournamentSheet);
    const focusMemo = readFocusMemo(tournamentSheet);
    sheetRenderCount += 1;

    // Der Zustand des Turniers steht im Titelblock und in der Randspalte;
    // ein eigener Zusammenfassungsblock würde ihn nur wiederholen.
    if (isTtRaceTournament()) {
      sheetMeta.innerHTML = renderTtRaceSheetMeta();
      tournamentSheet.innerHTML = renderTtRaceSheet();
    } else {
      sheetMeta.innerHTML = renderSheetMeta();

      tournamentSheet.innerHTML =
        activeTournament.mode === "team"
          ? renderTeamSheet()
          : activeTournament.mode === "groupsKnockout"
            ? renderGroupsKnockoutSheet()
            : renderRoundRobinSheet();
    }

    tournamentSheet.insertAdjacentHTML("afterbegin", renderTournamentClosingBanner());
    placeClosingAction();
    // Der Druckblock ist ein statisches Geschwister von #sheetMeta; er braucht
    // nur seinen Inhalt neu, weil die Dokumentliste vom Format abhängt.
    renderPrintRail();

    restoreOpenDetailsState(tournamentSheet, openDetails);
    markRailStart();
    lockClosedTournament();

    tournamentSheet.querySelectorAll("[data-tournament-close]").forEach((button) => {
      button.addEventListener("click", handleTournamentClose);
    });

    tournamentSheet.querySelectorAll("[data-result-key]").forEach((select) => {
      select.addEventListener("change", handleResultChange);
    });
    tournamentSheet.querySelectorAll("[data-normal-set-key]").forEach((input) => {
      input.addEventListener("input", handleNormalSetScoreInput);
      input.addEventListener("change", handleNormalSetScoreChange);
    });
    tournamentSheet.querySelectorAll("[data-quick-key]").forEach((input) => {
      input.addEventListener("input", handleQuickResultInput);
      input.addEventListener("keydown", handleQuickResultKeydown);
      input.addEventListener("change", handleQuickResultChange);
    });
    tournamentSheet.querySelectorAll("[data-set-details-toggle]").forEach((button) => {
      button.addEventListener("click", handleSetDetailsToggle);
    });

    // Die Randspalte ist ein eigener Container und braucht ihre eigenen Bindungen.
    sheetMeta.querySelectorAll("[data-draw-action]").forEach((button) => {
      button.addEventListener("click", handleDrawAction);
    });
    sheetMeta.querySelectorAll("[data-print-mode]").forEach((button) => {
      button.addEventListener("click", () => handlePrintDocument(button.dataset.printMode));
    });
    // Der Link in der Randspalte klappt den passenden Block darunter auf.
    sheetMeta.querySelectorAll("[data-open-details]").forEach((button) => {
      button.addEventListener("click", () => {
        const needle = button.dataset.openDetails.toLowerCase();
        const target = [...tournamentSheet.querySelectorAll("details.work-details")].find((entry) =>
          (entry.querySelector("summary")?.textContent || "").toLowerCase().includes(needle)
        );
        if (target) {
          target.open = true;
          target.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      });
    });
    sheetMeta.querySelectorAll("[data-rail-standings]").forEach((button) => {
      button.addEventListener("click", () => {
        railStandingsExpanded = button.dataset.railStandings === "expand";
        renderTournamentSheet();
      });
    });
    sheetMeta.querySelectorAll("[data-export-csv]").forEach((button) => {
      button.addEventListener("click", handleExportCsv);
    });
    sheetMeta.querySelectorAll("[data-history-action]").forEach((button) => {
      button.addEventListener("click", () => {
        if (button.dataset.historyAction === "undo") {
          handleUndo();
        } else {
          handleRedo();
        }
      });
    });
    tournamentSheet.querySelectorAll("[data-match-status-key]").forEach((select) => {
      select.addEventListener("change", handleMatchStatusChange);
    });

    tournamentSheet.querySelectorAll("[data-sheet-action]").forEach((element) => {
      element.addEventListener("change", handleSheetInput);
    });

    tournamentSheet.querySelectorAll("[data-draw-action]").forEach((button) => {
      button.addEventListener("click", handleDrawAction);
    });

    tournamentSheet.querySelectorAll("[data-round-shift]").forEach((button) => {
      button.addEventListener("click", handleRoundShift);
    });
    // F005: Der Gleichstands-Kasten steht im Blatt, nicht in der
    // Startlisten-Fläche — er wird deshalb hier gebunden wie alle anderen
    // Blatt-Knöpfe. (Der erste Versuch hing an `raceDayShell`; die beiden
    // Behälter sind Geschwister, kein Klick kam an.)
    tournamentSheet.querySelectorAll("[data-tie-decide]").forEach((button) => {
      button.addEventListener("click", () => handleTieDecideClick(button.dataset.tieDecide));
    });
    // Dieselben drei Bindungen wie bei den Ergebnisfeldern der anderen Formate
    // (B131): `input` zeigt nur, `keydown`/`change` übernehmen.
    tournamentSheet.querySelectorAll("[data-tt-race-sets]").forEach((input) => {
      input.addEventListener("input", handleTtRaceSetScoreInput);
      input.addEventListener("keydown", handleTtRaceSetScoreKeydown);
      input.addEventListener("change", handleTtRaceSetScoreChange);
    });
    tournamentSheet.querySelectorAll("[data-race-setting]").forEach((input) => {
      input.addEventListener("change", handleRaceSettingChange);
    });
    tournamentSheet.querySelectorAll("[data-race-action]").forEach((button) => {
      button.addEventListener("click", () => handleRaceAction(button));
    });

    tournamentSheet.querySelectorAll("[data-history-action]").forEach((button) => {
      button.addEventListener("click", () => {
        if (button.dataset.historyAction === "undo") {
          handleUndo();
        } else {
          handleRedo();
        }
      });
    });

    tournamentSheet.querySelectorAll("[data-font-size-step]").forEach((button) => {
      button.addEventListener("click", handlePlayerStatsFontSizeAdjust);
    });

    renderHistoryButtons();
    applyPlayerStatsFontSizeUI();

    // Zuletzt: der Fokus. Eine wartende Enter-Kette gewinnt gegen die Rettung
    // des alten Feldes, sonst stünde der Cursor wieder im schon gefüllten Feld.
    const chained = pendingChainFocus ? applyPendingChainFocus(tournamentSheet) : false;
    if (!chained && focusMemo) {
      restoreFocusMemo(tournamentSheet, focusMemo);
    }
  }


  // ── Live-Ansicht (F003) — feste Bühne 1920 × 1080 ─────────────────────────
  //
  // Der Beamer bekommt keine Seite, die sich nach dem Fenster richtet, sondern
  // eine Fläche in genau den Maßen des Entwurfs (4av1/4b/6a). Sie wird per
  // transform auf den vorhandenen Platz skaliert — deshalb steht hier jede
  // Größe fest in px, kein clamp(), keine Medienabfrage. Zwei Regeln tragen
  // den Umbau:
  //
  //   1. Was nicht in 1080 px passt, ist ein Fehler, kein Scrollbalken. In der
  //      Halle scrollt niemand (B071); die Bühne hat overflow: hidden, und der
  //      Prüflauf misst `#liveStage.scrollHeight <= 1080`.
  //   2. Bedienelemente stehen über der Bühne, nie darauf (B072). Was
  //      projiziert wird, ist Turnier — kein App-Knopf, keine Meldung.
  //
  // Reihenaufbau überall gleich: Kopfzeile mit Haarlinie, darunter das
  // Hauptraster. Namen stehen links, Ergebnisse rechts in einer festen Spur
  // (behebt B023 und B069 strukturell statt per Kürzungsregel).

  function renderLiveView() {
    const title =
      activeTournament.tournamentName?.trim() ||
      analysis.tournamentName ||
      getTournamentLabel(activeTournament, getActiveTournamentIndex());
    const stage = buildLiveStage(title);

    liveView.innerHTML = `
      <div class="live-toolbar">
        <p class="live-toolbar-note">Bühne 1920 × 1080 — diese Leiste wird nicht projiziert.</p>
        <div class="live-toolbar-actions">
          ${stage.showRankingLimit ? renderLiveRankingLimitControl(stage.rankingLength) : ""}
          <button class="live-fullscreen-button" type="button" data-live-fullscreen>Vollbild öffnen</button>
        </div>
      </div>
      <div class="live-viewport" data-live-viewport>
        <section id="liveStage" class="live-stage ${stage.modifier}" aria-labelledby="liveTitle">
          <header class="live-head">
            <h1 class="live-head-title" id="liveTitle">${escapeHtml(stage.headLeft)}</h1>
            <p class="live-head-state">${escapeHtml(stage.headRight)}</p>
          </header>
          ${stage.body}
        </section>
      </div>
    `;

    attachLiveStageScaling();
  }

  function buildLiveStage(title) {
    if (isTtRaceTournament()) {
      return buildTtRaceLiveStage(title);
    }

    if (activeTournament.mode === "groupsKnockout") {
      return buildGroupsKnockoutLiveStage(title);
    }

    if (["roundRobin", "team"].includes(activeTournament.mode)) {
      return buildRoundRobinLiveStage(title);
    }

    return {
      modifier: "is-live-empty",
      headLeft: title,
      headRight: getTournamentModeLabel(activeTournament),
      showRankingLimit: false,
      rankingLength: 0,
      body: `<div class="live-body"><p class="live-empty-state">Für dieses Format gibt es noch keine Live-Ansicht.</p></div>`
    };
  }

  /**
   * Die Skalierung ist eine Zeile Mathematik, kein Framework: die Bühne ist
   * immer 1920 × 1080, der Faktor ist der kleinere der beiden Quotienten. Am
   * 1080p-Beamer im Vollbild ergibt das exakt 1, am 720p-Beamer 0,667, am
   * 4K-Schirm 2. Vollbild fordert die Fläche (`.live-viewport`) an, nicht die
   * Bühne — sonst wäre der Faktor im Vollbild wieder 1 und der Rest schwarz.
   */
  function attachLiveStageScaling() {
    const viewport = liveView.querySelector("[data-live-viewport]");
    if (!viewport) {
      return;
    }

    updateLiveStageScale();

    if (typeof ResizeObserver === "function") {
      if (liveViewportObserver) {
        liveViewportObserver.disconnect();
      }
      liveViewportObserver = new ResizeObserver(() => updateLiveStageScale());
      liveViewportObserver.observe(viewport);
    }
  }

  function updateLiveStageScale() {
    const viewport = liveView?.querySelector("[data-live-viewport]");
    if (!viewport) {
      return;
    }

    const box = viewport.getBoundingClientRect();
    if (box.width <= 0 || box.height <= 0) {
      return;
    }

    const scale = Math.min(box.width / LIVE_STAGE_WIDTH, box.height / LIVE_STAGE_HEIGHT);
    viewport.style.setProperty("--live-scale", String(Math.max(0.05, scale)));
  }

  /**
   * Ein einziger Weg zur Wahrheit über den Fortschritt eines TT-Race. Vorher
   * rechneten Bühne und Kopfleiste getrennt und beide falsch (B070, B105).
   * Solange die Engine noch lädt, gilt dieselbe Formel als Spiegel — die
   * geprüfte Fassung steht in js/ttRace.js (`describeSwissProgress`).
   */
  function getTtRaceProgress(ttRaceState = activeTournament?.ttRace) {
    if (ttRaceEngineModule?.describeSwissProgress) {
      return ttRaceEngineModule.describeSwissProgress(ttRaceState ?? {});
    }

    const rounds = Array.isArray(ttRaceState?.rounds) ? ttRaceState.rounds : [];
    const configured = Number(ttRaceState?.settings?.maxRounds);
    const maxRounds = Number.isFinite(configured) && configured > 0 ? Math.floor(configured) : 6;
    const allMatches = rounds.flatMap((round) => (Array.isArray(round?.matches) ? round.matches : []));
    const completedMatches = allMatches.filter((match) => isTtRaceMatchComplete(match)).length;
    const currentRound = rounds[rounds.length - 1] ?? null;
    const currentRoundMatches = Array.isArray(currentRound?.matches) ? currentRound.matches : [];

    return {
      playedRounds: rounds.length,
      maxRounds: Math.max(rounds.length, maxRounds),
      currentRoundNumber: currentRound?.roundNumber ?? rounds.length,
      currentRoundCompletedMatches: currentRoundMatches.filter((match) => isTtRaceMatchComplete(match)).length,
      currentRoundTotalMatches: currentRoundMatches.length,
      completedMatches,
      totalMatches: allMatches.length,
      started: rounds.length > 0,
      complete: rounds.length >= maxRounds && allMatches.length > 0 && completedMatches === allMatches.length
    };
  }

  /**
   * Die Wertung eines TT-Race liegt in `ttRace.standings`, nicht in
   * `analysis.ranking` — die Jeder-gegen-jeden-Analyse ist im Schweizer System
   * leer. Solange die Druckdokumente `analysis.ranking` lasen, druckten sie
   * nach sechs gespielten Runden zwölf Urkunden „1. geteilt" mit Bilanz 0/0,
   * während die Randspalte danebenstand und den echten Sieger zeigte
   * (B122-Nachprüfung, Welle 5). Diese Funktion ist die eine Quelle für alle
   * Druckwege.
   */
  function getTtRacePrintRanking() {
    return getTtRaceStandings().map((standing, index) => ({
      ...standing,
      place: Number(standing.displayRank ?? standing.rank) || index + 1,
      sharedPlace: Boolean(standing.unresolvedTieMarker),
      points: standing.matchPoints,
      wins: standing.wins,
      losses: standing.losses,
      setsWon: standing.setsWon,
      setsLost: standing.setsLost,
      setDiff: standing.setDiff
    }));
  }

  // ── TT-Race: 4av1 (laufend) und 4b (Endstand) ─────────────────────────────

  function buildTtRaceLiveStage(title) {
    const tournament = ttRaceEngineModule
      ? ttRaceEngineModule.normalizeTtRaceTournament(activeTournament.ttRace)
      : activeTournament.ttRace || {};
    const progress = getTtRaceProgress(activeTournament.ttRace);
    const players = Array.isArray(tournament.players) ? tournament.players : [];
    const standings = Array.isArray(tournament.standings) ? tournament.standings : [];
    const ranking = standings.map((standing, index) => ({
      ...standing,
      place: standing.displayRank ?? standing.rank ?? index + 1,
      sharedPlace: Boolean(standing.unresolvedTieMarker)
    }));
    const headLeft = `${title} · ${players.length} Teilnehmer`;

    if (progress.complete) {
      return {
        modifier: "is-tt-race-live is-live-final",
        headLeft,
        headRight: `Turnier abgeschlossen · ${livePlural(progress.playedRounds, "Runde", "Runden")} · ${progress.completedMatches} von ${progress.totalMatches} ${livePluralWord(progress.totalMatches, "Spiel", "Spielen")}`,
        showRankingLimit: false,
        rankingLength: ranking.length,
        body: renderLiveFinalBody({
          winners: ranking.filter((entry) => entry.place === 1),
          describeWinner: (entry) =>
            [
              livePlural(entry.wins, "Sieg", "Siege"),
              `Sätze ${formatSignedValue(entry.setDiff)}`,
              `Gegnerpunkte ${formatLiveNumber(entry.buchholz)}`
            ].join(" · "),
          columns: ["Pl", "Spieler", "Bilanz", "Sätze", "Gegner"],
          rows: ranking.map((entry) => ({
            place: entry.place,
            name: entry.name,
            values: [
              `${entry.wins}:${entry.losses}`,
              `${entry.setsWon}:${entry.setsLost}`,
              formatLiveNumber(entry.buchholz)
            ]
          })),
          footnote: `Endstand aller ${players.length} Teilnehmer · Bilanz = Siege–Niederlagen aus ${livePlural(progress.playedRounds, "Runde", "Runden")} · Gegner = Summe der Punkte aller Gegner, entscheidet bei gleicher Bilanz`
        })
      };
    }

    const currentRound = Array.isArray(tournament.rounds) ? tournament.rounds[tournament.rounds.length - 1] : null;
    const playerById = new Map(players.map((player) => [player.id, player]));
    const matches = currentRound?.matches ?? [];
    const byes = currentRound?.byes ?? [];
    const blocks = [
      ...matches.map((match) => {
        const done = isTtRaceMatchComplete(match);
        return {
          kicker: `Tisch ${match.table ?? "—"}`,
          names: [
            playerById.get(match.playerAId)?.name || match.playerAId || "Offen",
            playerById.get(match.playerBId)?.name || match.playerBId || "Offen"
          ],
          result: done ? formatTtRaceMatchSummary(match) || "erfasst" : "läuft",
          done
        };
      }),
      ...byes.map((bye) => ({
        kicker: "Freilos",
        names: [playerById.get(bye.playerId)?.name || bye.playerId || "Offen"],
        result: formatTtRaceByePoints(getTtRaceByePointValue(bye)),
        done: true
      }))
    ];

    return {
      modifier: "is-tt-race-live",
      headLeft,
      headRight: [
        progress.started ? `Runde ${progress.currentRoundNumber} von ${progress.maxRounds}` : "Noch keine Runde ausgelost",
        progress.started
          ? `${progress.currentRoundCompletedMatches} von ${progress.currentRoundTotalMatches} ${livePluralWord(progress.currentRoundTotalMatches, "Spiel", "Spielen")}`
          : "",
        "Schweizer System"
      ]
        .filter(Boolean)
        .join(" · "),
      showRankingLimit: true,
      rankingLength: ranking.length,
      body: renderLiveSplitBody({
        leftTitle: progress.started ? `Runde ${progress.currentRoundNumber}` : "Auslosung offen",
        left: renderLiveMatchGrid(blocks, "Noch keine Schweizer Runde ausgelost."),
        rightTitle: "Stand",
        right: renderLiveStanding(
          ranking.map((entry) => ({
            place: entry.place,
            name: entry.name,
            values: [formatLiveNumber(entry.matchPoints)]
          })),
          "is-two-value"
        )
      })
    };
  }

  // ── Jeder-gegen-jeden und Teamwettbewerb ──────────────────────────────────

  function buildRoundRobinLiveStage(title) {
    const isTeam = activeTournament.mode === "team";
    const ranking = isTeam ? analysis.playerRanking ?? [] : analysis.ranking ?? [];
    const participants = isTeam
      ? (analysis.teamAPlayers?.length ?? 0) + (analysis.teamBPlayers?.length ?? 0)
      : analysis.players?.length ?? 0;
    const headLeft = `${title} · ${participants} Teilnehmer`;
    const complete = analysis.totalMatches > 0 && analysis.completedMatches >= analysis.totalMatches;

    if (complete) {
      const winners = isTeam ? [] : ranking.filter((entry) => entry.place === 1);
      const teamWinner = analysis.teamSummary?.winner;
      const teamIsDraw = teamWinner === "Unentschieden";

      return {
        modifier: `is-live-final ${isTeam ? "is-team-live" : "is-round-robin-live"}`,
        headLeft,
        headRight: `Turnier abgeschlossen · ${analysis.completedMatches} von ${analysis.totalMatches} ${livePluralWord(analysis.totalMatches, "Spiel", "Spielen")} · ${analysis.matchModeLabel}`,
        showRankingLimit: false,
        rankingLength: ranking.length,
        body: renderLiveFinalBody({
          winners: isTeam
            ? [{ place: 1, name: teamIsDraw ? "Unentschieden" : teamWinner }]
            : winners,
          winnerKicker: isTeam && teamIsDraw ? "Endstand" : undefined,
          describeWinner: (entry) =>
            isTeam
              ? `Spiele ${analysis.teamSummary.byMatches.teamAValue}:${analysis.teamSummary.byMatches.teamBValue} · Sätze ${analysis.teamSummary.bySets.teamAValue}:${analysis.teamSummary.bySets.teamBValue}`
              : [livePlural(entry.wins, "Sieg", "Siege"), `Sätze ${formatSignedValue(entry.setDiff)}`].join(" · "),
          columns: ["Pl", "Spieler", "Bilanz", "Sätze", isTeam ? "Team" : "Diff."],
          rows: ranking.map((entry) => ({
            place: entry.place,
            name: entry.name,
            values: [
              isTeam ? `${entry.matchesWon}:${entry.matchesLost}` : `${entry.wins}:${entry.losses}`,
              `${entry.setsWon}:${entry.setsLost}`,
              isTeam ? entry.team : formatSignedValue(entry.setDiff)
            ]
          })),
          footnote: `Endstand aller ${participants} Teilnehmer · Bilanz = Siege–Niederlagen · Sätze = gewonnene zu verlorenen Sätzen`
        })
      };
    }

    const round = getLiveActiveRound();

    return {
      modifier: isTeam ? "is-team-live" : "is-round-robin-live",
      headLeft,
      headRight: [round.stateLabel, `${analysis.completedMatches} von ${analysis.totalMatches} ${livePluralWord(analysis.totalMatches, "Spiel", "Spielen")}`, analysis.matchModeLabel]
        .filter(Boolean)
        .join(" · "),
      showRankingLimit: true,
      rankingLength: ranking.length,
      body: renderLiveSplitBody({
        leftTitle: round.title,
        left: renderLiveMatchGrid(round.blocks, "In dieser Runde steht noch keine Paarung."),
        rightTitle: "Stand",
        rightHead: isTeam ? renderLiveTeamScoreboard() : "",
        right: renderLiveStanding(
          ranking.map((entry) => ({
            place: entry.place,
            name: entry.name,
            values: isTeam
              ? [`${entry.matchesWon}:${entry.matchesLost}`, formatSignedValue(entry.setDiff)]
              : [`${entry.wins}:${entry.losses}`, formatSignedValue(entry.setDiff)]
          }))
        )
      })
    };
  }

  /**
   * Der Beamer zeigt die Runde, die wirklich läuft — die erste mit einem noch
   * offenen Spiel. Welche Runde die Eingabe gerade anzeigt, geht die Halle
   * nichts an.
   */
  function getLiveActiveRound() {
    const hasResult = (pairing) => Boolean(pairing.score);
    const pickRunning = (rounds) => {
      const open = (rounds ?? []).find((round) => (round.pairings ?? []).some((pairing) => !hasResult(pairing)));
      return open ?? (rounds ?? [])[rounds.length - 1] ?? null;
    };

    if (activeTournament.mode === "team") {
      const singles = pickRunning(analysis.rounds);
      const doubles = pickRunning(analysis.doubleRounds);
      const blocks = [
        ...(singles?.pairings ?? []).map((pairing, index) => toLiveMatchBlock(pairing, `Einzel ${index + 1}`)),
        ...(doubles?.pairings ?? []).map((pairing, index) => toLiveMatchBlock(pairing, `Doppel ${index + 1}`))
      ];
      const title = doubles
        ? `Einzel ${singles?.roundNumber ?? 1} · Doppel ${doubles.roundNumber}`
        : `Einzelrunde ${singles?.roundNumber ?? 1}`;

      return {
        title,
        stateLabel: `Runde ${singles?.roundNumber ?? 1} von ${analysis.rounds.length}`,
        blocks
      };
    }

    const round = pickRunning(analysis.rounds);
    const blocks = (round?.pairings ?? []).map((pairing, index) => toLiveMatchBlock(pairing, `Spiel ${index + 1}`));

    if (round?.byePlayer) {
      blocks.push({
        kicker: "Spielfrei",
        names: [round.byePlayer],
        result: "—",
        done: true
      });
    }

    return {
      title: `Runde ${round?.roundNumber ?? 1}`,
      stateLabel: `Runde ${round?.roundNumber ?? 1} von ${analysis.rounds.length}`,
      blocks
    };
  }

  function toLiveMatchBlock(pairing, kicker) {
    return {
      kicker,
      names: [pairing.playerA || "Offen", pairing.playerB || "Offen"],
      result: pairing.score || "läuft",
      done: Boolean(pairing.score)
    };
  }

  function renderLiveTeamScoreboard() {
    const { teamSummary } = analysis;
    if (!teamSummary) {
      return "";
    }

    return `
      <div class="live-team-score">
        <div class="live-team-score-entry ${teamSummary.winner === analysis.teamAName ? "is-leading" : ""}">
          <span class="live-team-score-name">${escapeHtml(analysis.teamAName)}</span>
          <span class="live-team-score-value">${teamSummary.byMatches.teamAValue}</span>
        </div>
        <span class="live-team-score-separator" aria-hidden="true">:</span>
        <div class="live-team-score-entry ${teamSummary.winner === analysis.teamBName ? "is-leading" : ""}">
          <span class="live-team-score-value">${teamSummary.byMatches.teamBValue}</span>
          <span class="live-team-score-name">${escapeHtml(analysis.teamBName)}</span>
        </div>
      </div>
    `;
  }

  // ── Gruppen + KO: 6a ──────────────────────────────────────────────────────

  function buildGroupsKnockoutLiveStage(title) {
    const groups = analysis.groups ?? [];
    const stages = buildLiveKnockoutStages();
    const champion = analysis.champion?.name || "";
    const groupRows = groups.reduce((sum, group) => sum + (group.ranking?.length ?? 0), 0);

    return {
      modifier: `is-groups-live ${groupRows > 16 || groups.length > 2 ? "is-dense" : ""}`,
      headLeft: `${title} · ${analysis.playerCount} Teilnehmer`,
      headRight: describeGroupsKnockoutLiveState(champion),
      showRankingLimit: false,
      rankingLength: 0,
      body: `
        <div class="live-body live-body--groups">
          <section class="live-groups">
            ${groups
              .map(
                (group) => `
                  <div class="live-group">
                    <h2 class="live-column-title">${escapeHtml(group.name)}</h2>
                    <div class="live-standing">
                      ${(group.ranking ?? [])
                        .map(
                          (entry) => `
                            <div class="live-standing-row ${
                              analysis.groupStageComplete ? (entry.isQualified ? "is-qualified" : "is-out") : ""
                            }">
                              <span class="live-standing-place">${entry.qualificationRank}</span>
                              <span class="live-standing-name">${escapeHtml(entry.name)}</span>
                              <span class="live-standing-value">${entry.wins}:${entry.losses}</span>
                              <span class="live-standing-value is-muted">${escapeHtml(formatSignedValue(entry.setDiff))}</span>
                            </div>
                          `
                        )
                        .join("")}
                    </div>
                  </div>
                `
              )
              .join("")}
          </section>
          <div class="live-hairline" aria-hidden="true"></div>
          <section class="live-column">
            <h2 class="live-column-title">KO-Raster</h2>
            <div class="live-bracket" style="grid-template-columns: repeat(${Math.max(1, stages.length)}, minmax(0, 1fr)) 300px;">
              ${stages
                .map(
                  (stage) => `
                    <div class="live-bracket-stage">
                      ${stage.matches
                        .map(
                          (match) => `
                            <div class="live-bracket-match">
                              <span class="live-bracket-label">${escapeHtml(match.label)}</span>
                              <div class="live-bracket-pair">
                                <span class="live-bracket-name ${match.knownA ? "" : "is-origin"}">${escapeHtml(match.playerA)}</span>
                                <span class="live-bracket-score">${escapeHtml(match.scoreA)}</span>
                                <span class="live-bracket-name is-second ${match.knownB ? "" : "is-origin"}">${escapeHtml(match.playerB)}</span>
                                <span class="live-bracket-score is-second">${escapeHtml(match.scoreB)}</span>
                              </div>
                              ${match.note ? `<span class="live-bracket-note">${escapeHtml(match.note)}</span>` : ""}
                            </div>
                          `
                        )
                        .join("")}
                    </div>
                  `
                )
                .join("")}
              <div class="live-bracket-winner">
                <span class="live-bracket-label">Sieger</span>
                <span class="live-bracket-champion ${champion ? "" : "is-open"}">${champion ? escapeHtml(champion) : "?"}</span>
                <span class="live-bracket-note">${escapeHtml(describeLiveKnockoutPodium(champion))}</span>
              </div>
            </div>
          </section>
        </div>
      `
    };
  }

  function describeLiveKnockoutPodium(champion) {
    if (!champion) {
      return "Nach dem Finale erscheint hier der Turniersieger.";
    }

    const podium = (analysis.finalStandings ?? [])
      .filter((entry) => entry.place === 2 || entry.place === 3)
      .map((entry) => `${entry.place}. ${entry.name}`);

    return podium.length > 0 ? podium.join(" · ") : "Turnier entschieden.";
  }

  function describeGroupsKnockoutLiveState(champion) {
    const parts = [];

    if (champion) {
      parts.push(`Turnier abgeschlossen · Sieger ${champion}`);
    } else if (!analysis.groupStageComplete) {
      const rounds = analysis.groupRoundSchedule ?? [];
      const running = rounds.find((round) => (round.pairings ?? []).some((pairing) => !pairing.score));
      parts.push(`Gruppenrunde ${running?.roundNumber ?? rounds.length} von ${rounds.length}`);
      parts.push(`${analysis.completedGroupMatches} von ${analysis.totalGroupMatches} ${livePluralWord(analysis.totalGroupMatches, "Spiel", "Spielen")}`);
    } else {
      const openRound = (analysis.knockoutRounds ?? []).find((round) =>
        (round.pairings ?? []).some((match) => match.isPlayable && !match.winner)
      );
      parts.push("Gruppen abgeschlossen");
      parts.push(openRound ? `${openRound.roundName} läuft` : "KO-Runde läuft");
    }

    parts.push(analysis.matchModeLabel);
    return parts.join(" · ");
  }

  /**
   * Das Raster ist nie leer (Vorgabe 6a). Solange die Gruppen laufen, stehen
   * dort die Herkünfte der Plätze („Sieger Gruppe A"); danach die echten
   * Paarungen, unbekannte Seiten weiter als Herkunft („Sieger Halbfinale 2").
   * Das Spiel um Platz 3 steht in derselben Stufe wie das Finale.
   */
  function buildLiveKnockoutStages() {
    const rounds = analysis.knockoutRounds ?? [];

    if (rounds.length === 0) {
      return buildLiveKnockoutPreviewStages();
    }

    const placement = analysis.placementMatches ?? [];

    return rounds.map((round, roundIndex) => {
      const matches = round.pairings.map((match) => toLiveBracketMatch(match, round, rounds));

      if (roundIndex === rounds.length - 1) {
        placement.forEach((match) => {
          matches.push({
            ...toLiveBracketMatch(match, round, rounds),
            label: "Spiel um Platz 3"
          });
        });
      }

      return { matches };
    });
  }

  function toLiveBracketMatch(match, round, rounds) {
    const [scoreA, scoreB] = String(match.score || "").split(":");
    const label =
      match.id === "ko-third-place"
        ? "Spiel um Platz 3"
        : round.pairings.length > 1
          ? `${round.roundName} ${match.matchNumber}`
          : round.roundName;

    return {
      label,
      playerA: humanizeKnockoutOrigin(match.playerA, rounds),
      playerB: humanizeKnockoutOrigin(match.playerB, rounds),
      knownA: Boolean(match.participantA),
      knownB: Boolean(match.participantB),
      scoreA: scoreA?.trim() || "",
      scoreB: scoreB?.trim() || "",
      note: match.isBye ? "kampflos weiter" : match.isPlayable && !match.score ? "läuft" : ""
    };
  }

  function buildLiveKnockoutPreviewStages() {
    const groups = analysis.groups ?? [];
    const perGroup = Math.max(1, analysis.qualifiersPerGroup ?? 2);
    const seeds = [];

    for (let rank = 1; rank <= perGroup; rank += 1) {
      groups.forEach((group) => seeds.push(describeGroupSlot(rank, group.name)));
    }

    let bracketSize = 2;
    while (bracketSize < Math.max(2, seeds.length)) {
      bracketSize *= 2;
    }

    const padded = [...seeds, ...Array.from({ length: bracketSize - seeds.length }, () => "Freilos")];
    let quellen = [];
    for (let index = 0; index < bracketSize / 2; index += 1) {
      quellen.push(padded[index], padded[bracketSize - 1 - index]);
    }

    const stufen = [];
    while (quellen.length > 1) {
      const matchCount = quellen.length / 2;
      const roundName = getPreviewRoundName(matchCount);
      const matches = Array.from({ length: matchCount }, (_, index) => ({
        label: matchCount === 1 ? roundName : `${roundName} ${index + 1}`,
        playerA: quellen[index * 2],
        playerB: quellen[index * 2 + 1],
        knownA: false,
        knownB: false,
        scoreA: "",
        scoreB: "",
        note: ""
      }));
      stufen.push({ matches, roundName, matchCount });
      quellen = matches.map((match) => `Sieger ${match.label}`);
    }

    const halbfinale = stufen[stufen.length - 2];
    if (analysis.placementMatchesEnabled && halbfinale?.matchCount === 2) {
      stufen[stufen.length - 1].matches.push({
        label: "Spiel um Platz 3",
        playerA: `Verlierer ${halbfinale.roundName} 1`,
        playerB: `Verlierer ${halbfinale.roundName} 2`,
        knownA: false,
        knownB: false,
        scoreA: "",
        scoreB: "",
        note: ""
      });
    }

    return stufen;
  }

  /** „Sieger R1/S2" ist eine Kennung, keine Auskunft — hier wird sie lesbar. */
  function humanizeKnockoutOrigin(text, rounds) {
    return String(text ?? "").replace(/R(\d+)\/S(\d+)/g, (whole, roundText, matchText) => {
      const round = (rounds ?? []).find((entry) => entry.roundNumber === Number(roundText));
      if (!round) {
        return whole;
      }
      return round.pairings.length > 1 ? `${round.roundName} ${matchText}` : round.roundName;
    });
  }

  // ── gemeinsame Bausteine der Bühne ────────────────────────────────────────

  function renderLiveSplitBody({ leftTitle, left, rightTitle, rightHead = "", right }) {
    return `
      <div class="live-body live-body--split">
        <section class="live-column">
          <h2 class="live-column-title">${escapeHtml(leftTitle)}</h2>
          ${left}
        </section>
        <div class="live-hairline" aria-hidden="true"></div>
        <section class="live-column live-column--standing ${rightHead ? "live-column--with-head" : ""}">
          <h2 class="live-column-title">${escapeHtml(rightTitle)}</h2>
          ${rightHead}
          ${right}
        </section>
      </div>
    `;
  }

  function renderLiveMatchGrid(blocks, emptyText) {
    if (!blocks || blocks.length === 0) {
      return `<p class="live-empty-state">${escapeHtml(emptyText)}</p>`;
    }

    return `
      <div class="live-match-grid ${blocks.length === 1 ? "is-single-column" : ""}">
        ${blocks
          .map(
            (block) => `
              <article class="live-match">
                <div class="live-match-main">
                  <span class="live-match-kicker">${escapeHtml(block.kicker)}</span>
                  ${block.names
                    .map(
                      (name, index) =>
                        `<span class="live-match-name ${index > 0 ? "is-second" : ""}">${escapeHtml(name)}</span>`
                    )
                    .join("")}
                </div>
                <span class="live-match-result ${block.done ? "is-done" : "is-open"}">${escapeHtml(block.result)}</span>
              </article>
            `
          )
          .join("")}
      </div>
    `;
  }

  /**
   * G6: Die Bühne zeigt den ganzen Stand. Nur wenn mehr Zeilen anfallen, als
   * auf 1080 px lesbar bleiben, wird gekürzt — und dann sagt die letzte Zeile,
   * wie viele fehlen.
   */
  function renderLiveStanding(rows, modifier = "") {
    if (!rows || rows.length === 0) {
      return `<p class="live-empty-state">Noch keine Rangliste verfügbar.</p>`;
    }

    const limited = liveRankingLimit === "all" ? rows : rows.filter((row) => row.place <= liveRankingLimit);
    const visible = limited.slice(0, LIVE_STANDING_MAX_ROWS);
    const hidden = limited.length - visible.length + (rows.length - limited.length);

    return `
      <div class="live-standing ${modifier}">
        ${visible
          .map(
            (row) => `
              <div class="live-standing-row ${placeClass(row.place)}">
                <span class="live-standing-place">${row.place}</span>
                <span class="live-standing-name">${escapeHtml(row.name)}</span>
                ${row.values
                  .map(
                    (value, index) =>
                      `<span class="live-standing-value ${index > 0 ? "is-muted" : ""}">${escapeHtml(String(value))}</span>`
                  )
                  .join("")}
              </div>
            `
          )
          .join("")}
        ${
          hidden > 0
            ? `<p class="live-standing-more">${hidden} weitere ${livePluralWord(hidden, "Platz", "Plätze")} nicht angezeigt</p>`
            : ""
        }
      </div>
    `;
  }

  function renderLiveFinalBody({ winners, describeWinner, winnerKicker, columns, rows, footnote }) {
    const winner = winners?.[0] ?? null;
    const kicker = winnerKicker || (winners && winners.length > 1 ? "Geteilte Sieger" : "Sieger");
    const name = winners && winners.length > 1 ? winners.map((entry) => entry.name).join(", ") : winner?.name || "Noch offen";
    const visible = rows.slice(0, LIVE_FINAL_MAX_ROWS);
    const hidden = rows.length - visible.length;
    const split = Math.ceil(visible.length / 2);
    const left = visible.slice(0, split);
    const right = visible.slice(split);

    const table = (entries) => `
      <div class="live-final-table">
        <div class="live-final-row is-head">
          ${columns.map((column, index) => `<span class="${index > 1 ? "is-numeric" : ""}">${escapeHtml(column)}</span>`).join("")}
        </div>
        ${entries
          .map(
            (entry) => `
              <div class="live-final-row">
                <span class="live-final-place">${entry.place}</span>
                <span class="live-final-name">${escapeHtml(entry.name)}</span>
                ${entry.values
                  .map((value, index) => `<span class="is-numeric ${index > 0 ? "is-muted" : ""}">${escapeHtml(String(value))}</span>`)
                  .join("")}
              </div>
            `
          )
          .join("")}
      </div>
    `;

    return `
      <div class="live-body live-body--final">
        <div class="live-winner-row">
          <div>
            <p class="live-winner-kicker">${escapeHtml(kicker)}</p>
            <h2 class="live-winner-name">${escapeHtml(name)}</h2>
          </div>
          <p class="live-winner-stats">${winner && describeWinner ? escapeHtml(describeWinner(winner)) : ""}</p>
        </div>
        <div class="live-final-tables">
          ${table(left)}
          <div class="live-hairline" aria-hidden="true"></div>
          ${table(right)}
        </div>
        <p class="live-footnote">${escapeHtml(footnote)}${
          hidden > 0 ? ` · ${hidden} weitere ${livePluralWord(hidden, "Platz", "Plätze")} nur in der Ergebnisansicht` : ""
        }</p>
      </div>
    `;
  }

  function renderLiveRankingLimitControl(totalEntries) {
    return `
      <label class="live-ranking-limit-field">
        <span>Plätze auf der Bühne</span>
        <select data-live-ranking-limit aria-label="Anzahl der angezeigten Plätze wählen">
          ${LIVE_RANKING_LIMIT_OPTIONS.map((option) => {
            const value = String(option);
            const isSelected = option === liveRankingLimit;
            const label = option === "all" ? `Alle Plätze (${totalEntries})` : `Platz 1-${option}`;
            return `<option value="${value}" ${isSelected ? "selected" : ""}>${escapeHtml(label)}</option>`;
          }).join("")}
        </select>
      </label>
    `;
  }

  /** B073: „1 Punkte" ist ein Fehler, kein Schönheitsfehler. */
  function livePlural(count, singular, plural) {
    return `${count} ${livePluralWord(count, singular, plural)}`;
  }

  function livePluralWord(count, singular, plural) {
    return Math.abs(Number(count)) === 1 ? singular : plural;
  }

  function formatLiveNumber(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) {
      return String(value ?? "");
    }
    return Number.isInteger(numeric) ? String(numeric) : numeric.toFixed(1).replace(".", ",");
  }

  function handleLiveViewClick(event) {
    const button = event.target.closest?.("[data-live-fullscreen]");
    if (!button) {
      return;
    }

    const viewport = liveView.querySelector("[data-live-viewport]");
    if (!viewport?.requestFullscreen) {
      showInfo("Vollbild ist in diesem Browser nicht verfügbar.");
      return;
    }

    viewport.requestFullscreen().catch((error) => {
      console.warn("Live-Ansicht konnte nicht im Vollbild geöffnet werden.", error);
      showInfo("Vollbild konnte nicht geöffnet werden. Bitte Browserberechtigungen prüfen.");
    });
  }

  function handleLiveViewChange(event) {
    const select = event.target.closest?.("[data-live-ranking-limit]");
    if (!select) {
      return;
    }

    liveRankingLimit = select.value === "all" ? "all" : Number.parseInt(select.value, 10);
    if (!LIVE_RANKING_LIMIT_OPTIONS.includes(liveRankingLimit)) {
      liveRankingLimit = "all";
    }

    saveLiveRankingLimit();
    renderLiveView();
  }

  function formatSignedValue(value) {
    return value > 0 ? `+${value}` : `${value}`;
  }

  function renderMatchModeField(extraClass = "") {
    const mismatchCount = analysis.modeMismatchCount || 0;
    return `
      <label${extraClass ? ` class="${extraClass}"` : ""}>
        <span>Spielmodus</span>
        <select data-action="matchMode">
          ${MATCH_MODE_ORDER.map(
            (modeId) => `
              <option value="${modeId}" ${activeTournament.matchMode === modeId ? "selected" : ""}>
                ${escapeHtml(MATCH_MODES[modeId].label)}
              </option>
            `
          ).join("")}
        </select>
      </label>
      ${
        mismatchCount > 0
          ? `<p class="field-note">Aus einem anderen Spielmodus gespeichert: ${mismatchCount} Ergebnis${mismatchCount === 1 ? "" : "se"}. Die Wertung bleibt bestehen.</p>`
          : ""
      }
    `;
  }

  function renderScoringRulesToggle() {
    const scoring = normalizeScoringRules(activeTournament.scoring);
    const isDefault = isDefaultScoringRules(scoring);
    const drawField = matchModeAllowsDraw(activeTournament.matchMode)
      ? `
        <label>
          <span>Punkte pro Unentschieden</span>
          <input data-action="scoringDrawPoints" type="number" min="-99" max="99" step="1" value="${scoring.drawPoints}" />
        </label>
      `
      : "";

    return `
      <details class="scoring-rules-toggle">
        <summary>
          Erweiterte Wertung
          <span>${isDefault ? "Standard" : "angepasst"}</span>
        </summary>
        <div class="scoring-rules-body">
          <div class="scoring-points-grid">
            <label>
              <span>Punkte pro Sieg</span>
              <input data-action="scoringWinPoints" type="number" min="-99" max="99" step="1" value="${scoring.winPoints}" />
            </label>
            ${drawField}
            <label>
              <span>Punkte pro Niederlage</span>
              <input data-action="scoringLossPoints" type="number" min="-99" max="99" step="1" value="${scoring.lossPoints}" />
            </label>
          </div>
          <div class="scoring-order-grid">
            ${scoring.tieBreakOrder
              .map(
                (criterion, index) => `
                  <label>
                    <span>${index + 1}. Tie-Break</span>
                    <select data-action="scoringTieBreak" data-index="${index}">
                      ${Object.values(TIE_BREAK_CRITERIA)
                        .map(
                          (option) => `
                            <option value="${option.id}" ${option.id === criterion ? "selected" : ""}>
                              ${escapeHtml(option.label)}
                            </option>
                          `
                        )
                        .join("")}
                    </select>
                  </label>
                `
              )
              .join("")}
          </div>
          <p class="field-note">Alphabetisch sortiert nur noch technisch, wenn alle sportlichen Kriterien gleich bleiben; geteilte Plätze bleiben sichtbar.</p>
        </div>
      </details>
    `;
  }

  /** Randspalte der Ergebniseingabe: Stand oben, Spielmodus und Hinweise darunter. */
  function renderSheetMeta() {
    const mismatchCount = analysis.modeMismatchCount || 0;
    const scoringDescription = analysis.scoringDescription;

    return `
      ${renderRailStandings()}
      <p class="rail-note">Siege–Niederlagen und Satzdifferenz, bei Gleichstand entscheidet der direkte Vergleich.</p>
      ${
        mismatchCount > 0
          ? `<p class="rail-note">In einem anderen Spielmodus erfasst: ${mismatchCount} Ergebnis${mismatchCount === 1 ? "" : "se"}. Die Wertung bleibt bestehen.</p>`
          : ""
      }

      <hr class="hairline" />

      <div class="rail-links">
        <span class="rail-note" id="railAutosave">${escapeHtml(getAutosaveShortText())}</span>
        ${
          activeTournament.mode === "roundRobin"
            ? `<button class="link-button" type="button" data-draw-action="shuffle-round-robin" ${
                hasRoundRobinDrawStarted(activeTournament)
                  ? 'disabled title="Nach dem ersten eingetragenen Ergebnis lässt sich nicht mehr neu auslosen."'
                  : 'title="Mischt die Teilnehmer zufällig neu. Möglich, solange kein Ergebnis erfasst ist."'
              }>Teilnehmer neu auslosen</button>`
            : ""
        }
        <button class="link-button" type="button" data-export-csv>CSV / XLSX</button>
        <span class="rail-history">
          <button class="link-button" type="button" data-history-action="undo">Rückgängig</button>
          <button class="link-button" type="button" data-history-action="redo">Wiederholen</button>
        </span>
      </div>
      ${
        scoringDescription
          ? `<p class="rail-note">Spielmodus ${escapeHtml(analysis.matchModeLabel)} · Wertung ${escapeHtml(scoringDescription.points)}.</p>`
          : ""
      }
    `;
  }

  function getAutosaveShortText() {
    // Die Randspalte wird vor dem Schreiben gezeichnet; ohne diese Abfrage
    // stünde dort weiter "Automatische Speicherung aktiv", während oben die
    // Warnung steht, dass nichts mehr gespeichert wird.
    if (externalWorkspaceChange) {
      return "NICHT gespeichert — in einem anderen Fenster geändert, neu laden";
    }
    if (storageFailed) {
      return "NICHT gespeichert — Sicherung herunterladen";
    }
    const detail = autosaveDetail?.textContent?.trim();
    return detail && detail !== "Noch nichts gespeichert." ? detail : "Automatische Speicherung aktiv";
  }

  /**
   * Wie viele Zeilen die Randspalte zeigt. Ein Verweis auf "die ganze Liste"
   * lohnt nur, wenn er wirklich etwas verbirgt — für ein oder zwei Zeilen
   * kostet er einen Klick und einen Ortswechsel für nichts. Bis acht
   * Teilnehmern steht deshalb alles da.
   */
  function getRailStandingsLimit(total) {
    if (railStandingsExpanded || total <= RAIL_STANDINGS_ALWAYS_FULL) {
      return total;
    }
    return RAIL_STANDINGS_SHORT;
  }

  function renderRailStandingsToggle(total, shown) {
    if (shown >= total) {
      return railStandingsExpanded && total > RAIL_STANDINGS_ALWAYS_FULL
        ? `<button class="link-button" type="button" data-rail-standings="collapse">Weniger zeigen</button>`
        : "";
    }
    return `<button class="link-button" type="button" data-rail-standings="expand">Alle ${total} zeigen</button>`;
  }

  /** Kurzer Stand für die Randspalte: die ersten Plätze, Rest über einen Link. */
  function renderRailStandings() {
    if (activeTournament.mode === "team") {
      const summary = analysis.teamSummary ?? {};
      // B113: Die Randspalte las `byMatches.winner` (nur gewonnene Spiele,
      // ohne Stichentscheid), die Live-Bühne dagegen `teamSummary.winner`
      // (Spiele, dann Satzdifferenz). Bei gleichen Begegnungen und
      // unterschiedlicher Satzdifferenz markierte die eine keinen Führer, die
      // andere schon. Es gibt nur einen Gesamtstand — hier ist er.
      const gesamtsieger = summary.winner;
      const leader = gesamtsieger && gesamtsieger !== "Unentschieden" ? gesamtsieger : "";
      const teams = [
        { name: analysis.teamAName, stats: summary.teamA },
        { name: analysis.teamBName, stats: summary.teamB }
      ];
      const best = (analysis.playerRanking ?? []).slice(0, 3);

      return `
        <section class="rail-block">
          <h3 class="rail-heading">Teamstand</h3>
          <div class="team-standing">
            ${teams
              .map(
                (team) => `
                  <div class="team-standing-row ${leader && leader === team.name ? "is-leading" : ""}"${
                    leader && leader === team.name ? ' title="führt"' : ""
                  }>
                    <span>${escapeHtml(team.name || "")}</span>
                    <span class="is-numeric">${team.stats?.singlesWon ?? 0}</span>
                    <span class="is-numeric">${formatSignedValue(team.stats?.setDiff ?? 0)}</span>
                  </div>
                `
              )
              .join("")}
          </div>
          <p class="rail-note">Gewonnene Einzel und Satzdifferenz. ${
            leader
              ? `● markiert ${escapeHtml(leader)} als führendes Team (Begegnungen, bei Gleichstand Satzdifferenz).`
              : "Noch führt kein Team."
          }</p>
        </section>
        ${
          best.length > 0
            ? `<section class="rail-block">
                <h3 class="rail-heading">Beste Bilanz</h3>
                <table class="data-table rail-table">
                  <thead>
                    <tr><th>Spieler</th><th class="is-numeric">Spiele</th><th class="is-numeric">Diff.</th></tr>
                  </thead>
                  <tbody>
                    ${best
                      .map(
                        (player) => `
                          <tr>
                            <td>${escapeHtml(player.name || "")}</td>
                            <td class="is-numeric">${player.matchesWon ?? 0}–${player.matchesLost ?? 0}</td>
                            <td class="is-numeric">${formatSignedValue(player.setDiff ?? 0)}</td>
                          </tr>
                        `
                      )
                      .join("")}
                  </tbody>
                </table>
              </section>`
            : ""
        }
      `;
    }

    if (activeTournament.mode === "groupsKnockout") {
      const groups = analysis.groups ?? [];
      if (groups.length === 0) {
        return "";
      }

      const perGroup = analysis.qualifiersPerGroup ?? 2;

      // Randspalte trägt keine Rahmen: Haarlinien je Zeile, Ausgeschiedene blass.
      return `
        ${groups.map((group) => renderGroupRailStanding(group)).join("")}
        <p class="rail-note">Die oberen ${perGroup} jeder Gruppe kommen weiter, der Rest scheidet aus. Stand nach ${
          analysis.completedGroupMatches ?? 0
        } von ${analysis.totalGroupMatches ?? 0} Spielen.</p>
      `;
    }

    const ranking = analysis.ranking ?? [];
    if (ranking.length === 0) {
      return "";
    }

    const top = ranking.slice(0, getRailStandingsLimit(ranking.length));

    // Randspalte = schneller Blick: Platz, Name, Spiele, Sätze, Differenz.
    // Die vollen Angaben stehen unten in der Rangliste; wer mehr Zeilen sehen
    // will, klappt hier auf, statt weggeschickt zu werden.
    return `
      <section class="rail-block">
        <h3 class="rail-heading">Stand</h3>
        <table class="data-table rail-table">
          <thead>
            <tr><th>Pl.</th><th>Spieler</th><th class="is-numeric">Spiele</th><th class="is-numeric">Sätze</th><th class="is-numeric">Diff.</th></tr>
          </thead>
          <tbody>
            ${top
              .map(
                (player) => `
                  <tr class="${player.sharedPlace ? "is-tied" : ""}"${player.sharedPlace ? ' title="Platz geteilt"' : ""}>
                    <td>${player.place}${player.sharedPlace ? "*" : ""}</td>
                    <td>${escapeHtml(player.name || "")}</td>
                    <td class="is-numeric">${player.wins ?? 0}–${player.losses ?? 0}</td>
                    <td class="is-numeric">${player.setsWon ?? 0}:${player.setsLost ?? 0}</td>
                    <td class="is-numeric">${formatSignedValue(player.setDiff ?? 0)}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
        ${
          top.some((player) => player.sharedPlace)
            ? '<p class="rail-note">* Platz geteilt — die Wertung trennt diese Teilnehmer nicht.</p>'
            : ""
        }
        ${renderRailStandingsToggle(ranking.length, top.length)}
      </section>
    `;
  }

  /**
   * Kurzer Stand für die Randspalte: Platz, Spieler, Punkte, Sätze für die
   * ersten sechs. Die vollständige Wertung steht unter der Spielliste.
   */
  function renderTtRaceRailStandings(roundNumber) {
    const standings = getTtRaceStandings();
    if (standings.length === 0) {
      return "";
    }

    const top = standings.slice(0, 6);

    return `
      <section class="rail-block">
        <h3 class="rail-heading">${roundNumber ? `Stand nach Runde ${roundNumber}` : "Stand"}</h3>
        <table class="data-table rail-table">
          <thead>
            <tr><th>Pl.</th><th>Spieler</th><th class="is-numeric">Pkt</th><th class="is-numeric">Sätze</th></tr>
          </thead>
          <tbody>
            ${top
              .map(
                (standing) => `
                  <tr>
                    <td>${standing.rank}</td>
                    <td>${escapeHtml(standing.name)}</td>
                    <td class="is-numeric">${formatStandingNumber(standing.matchPoints)}</td>
                    <td class="is-numeric">${formatSignedValue(standing.setDiff)}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
        ${
          standings.length > top.length
            ? `<button class="link-button" type="button" data-open-details="rangliste">Ganze Rangliste (${standings.length})</button>`
            : ""
        }
      </section>
    `;
  }

  /** Randspalte der Ergebniseingabe: Stand, Prüfungen, Quelle. */
  function renderTtRaceSheetMeta() {
    const regardTtrValues = getTtRaceRegardTtrValues();
    const roundContext = getRaceDayRoundContext();
    const roundNumber = roundContext.currentRoundNumber || 0;
    const source = activeTournament.clicktt?.sourceFileName;

    return `
      ${renderTtRaceRailStandings(roundNumber)}

      <hr class="hairline" />

      <div class="rail-links">
        <span class="rail-note">${escapeHtml(getAutosaveShortText())}</span>
        <span class="rail-note">${
          source
            ? `Quelle: ${escapeHtml(source)}`
            : activeTournament.clicktt?.rawXml
              ? "click-TT XML verbunden"
              : "Keine XML geladen — der Export bleibt Vorschau."
        }</span>
        <span class="rail-note">${regardTtrValues ? "Auslosung mit TTR-Setzung." : "Auslosung ohne TTR-Setzung."} Jede Runde entsteht aus dem aktuellen Zwischenstand, nicht aus einer Vollmatrix.</span>
      </div>
    `;
  }

  function getTtRaceRoundByePlayers(round) {
    if (!round?.byes?.length) {
      return [];
    }

    const playersById = new Map((activeTournament.ttRace?.players ?? []).map((player) => [player.id, player]));
    return round.byes.map((bye) => ({
      name: playersById.get(bye.playerId)?.name || bye.playerId || "Unbekannter Spieler",
      points: getTtRaceByePointValue(bye)
    }));
  }

  function getTtRaceByePointValue(bye) {
    const points = Number(bye?.points);
    return Number.isFinite(points) ? points : 1;
  }

  function formatTtRaceByePoints(points) {
    return points === 1 ? "+1 Punkt" : `${points > 0 ? "+" : ""}${points} Punkte`;
  }

  function renderTtRaceRoundByeNotice(round) {
    const byes = getTtRaceRoundByePlayers(round);
    if (byes.length === 0) {
      return "";
    }

    return `
      <div class="tt-race-bye-notice" role="note">
        <strong>${byes.length === 1 ? "Setzt diese Runde aus" : "Setzen diese Runde aus"}</strong>
        <div>
          ${byes
            .map(
              (bye) =>
                `<span>${escapeHtml(bye.name)} · Freilos ${escapeHtml(formatTtRaceByePoints(bye.points))}</span>`
            )
            .join("")}
        </div>
      </div>
    `;
  }

  function renderTtRaceSheet() {
    const roundContext = getRaceDayRoundContext();
    const progress = getRaceDayProgress(roundContext);
    const players = activeTournament.ttRace?.players ?? [];
    const rounds = activeTournament.ttRace?.rounds ?? [];
    const hasExportPreview = progress.completed > 0 || Boolean(roundContext.currentRound);
    const generationState = getTtRaceGenerationStateFromTournament(activeTournament.ttRace);
    const exportState = getTtRaceFinalExportState(activeTournament.ttRace);

    const roundNumber = roundContext.currentRoundNumber || 0;
    const openCount = Math.max(0, progress.total - progress.completed);

    return `
      <div class="sheet-stack">
        <div class="work-head">
          <h3>${roundContext.currentRound ? `Runde ${roundNumber} erfassen` : "Erste Auslosung"}</h3>
          <span class="work-count">${progress.completed} von ${progress.total} Spielen</span>
        </div>

        <div class="work-intro">
          <p>
            ${
              roundContext.currentRound
                ? "Satzpunkte eintragen, kurz oder ausgeschrieben: „8, 3, 5“ wird zu 3:0 und den Sätzen 11:8, 11:3, 11:5. Wer die Sätze nicht hat, trägt nur das Gesamtergebnis ein: „3:1“."
                : "Teilnehmer laden und dann die erste Schweizer Runde erzeugen."
            }
          </p>
          ${roundContext.currentRound ? renderSetDetailsToggle() : ""}
        </div>

        ${renderTtRaceRoundByeNotice(roundContext.currentRound)}

        ${renderCurrentRoundEntries(roundContext.currentRound)}

        ${renderUnresolvedTiesBlock()}

        <div class="work-action">
          <button class="primary-button" type="button" data-race-action="generate-swiss-round" ${generationState.canGenerate ? "" : "disabled"}>
            ${escapeHtml(generationState.label)}
          </button>
          ${
            generationState.canGenerate
              ? ""
              : `<span class="action-reason">${escapeHtml(
                  generationState.reason || (openCount > 0 ? `Noch ${openCount} Ergebnis${openCount === 1 ? "" : "se"} offen.` : "")
                )}</span>`
          }
        </div>

        <details class="work-details">
          <summary>Auslosung anpassen</summary>
          <div class="work-details-body">
            ${renderTtRaceRoundSettings()}
          </div>
        </details>

        ${
          rounds.length > 0
            ? `
              <details class="work-details">
                <summary>Vollständige Rangliste anzeigen</summary>
                <div class="work-details-body table-wrapper">
                  ${renderTtRaceStandings()}
                </div>
              </details>
              <details class="work-details">
                <summary>Rundenverlauf anzeigen</summary>
                ${renderTtRaceRoundHistory()}
              </details>
            `
            : players.length > 0
              ? `
                <details class="work-details">
                  <summary>Teilnehmer anzeigen (${players.length})</summary>
                  ${renderTtRaceParticipantPreview(players)}
                </details>
              `
              : ""
        }

        ${
          hasExportPreview
            ? `
              <details class="work-details race-export-panel">
                <summary>click-TT Ergebnis-XML</summary>
                <div class="work-details-body">
                  <div class="action-row">
                    <button class="secondary-button" type="button" data-race-action="download-clicktt-xml" ${activeTournament.clicktt?.rawXml && !exportState.canExport ? "disabled" : ""}>${activeTournament.clicktt?.rawXml ? "XML exportieren" : "XML Demo"}</button>
                    <span class="action-reason">${activeTournament.clicktt?.rawXml ? escapeHtml(exportState.reason) : "Demo-Vorschau, bis eine click-TT XML importiert wurde."}</span>
                  </div>
                  <pre class="clicktt-xml-preview"><code>${escapeHtml(buildClickTtXmlPreview(roundContext))}</code></pre>
                </div>
              </details>
            `
            : ""
        }
      </div>
    `;
  }

  /**
   * Auslosungseinstellungen stehen unter der Hauptaktion, damit die Zeile mit
   * dem Primär-Button ruhig bleibt.
   */
  function renderTtRaceRoundSettings() {
    const regardTtrValues = getTtRaceRegardTtrValues();
    const redrawState = getTtRaceInitialRedrawState(activeTournament.ttRace);
    const canChangeTtrSetting = (activeTournament.ttRace?.rounds?.length ?? 0) === 0;

    return `
      <div class="action-row work-settings">
        ${renderTtRaceRedrawButton(redrawState)}
        <label class="inline-check">
          <input data-race-setting="regardTtrValues" type="checkbox" ${regardTtrValues ? "checked" : ""} ${canChangeTtrSetting ? "" : "disabled"} />
          <span>TTR bei Auslosung berücksichtigen</span>
        </label>
      </div>
    `;
  }

  function renderTtRaceParticipantPreview(players) {
    if (players.length === 0) {
      return `
        <div class="empty-round-state">
          <p>Noch keine Teilnehmer geladen.</p>
          <button class="secondary-button" type="button" data-race-action="choose-clicktt-file">XML wählen</button>
        </div>
      `;
    }

    return `
      <div class="race-participant-strip" aria-label="Teilnehmer">
        ${players
          .map(
            (player) => `
              <span>
                ${escapeHtml(player.name || player.id || "Teilnehmer")}
                ${hasTtrValue(player.rating) ? `<small>${escapeHtml(formatTtrValue(player.rating))}</small>` : ""}
              </span>
            `
          )
          .join("")}
      </div>
    `;
  }

  function renderTtRaceRoundHistory() {
    const playersById = new Map((activeTournament.ttRace?.players ?? []).map((player) => [player.id, player]));
    const rounds = activeTournament.ttRace?.rounds ?? [];

    if (rounds.length === 0) {
      return "<p>Noch keine Runde erzeugt.</p>";
    }

    return `
      <div class="tt-race-round-history">
        ${rounds
          .map(
            (round) => `
              <article class="round-card">
                <div class="round-card-header">
                  <h4>Runde ${round.roundNumber}</h4>
                  <span>${round.matches.filter((match) => match.status && !["scheduled", "void"].includes(match.status)).length}/${round.matches.length} erfasst</span>
                </div>
                <ul class="compact-schedule-list">
                  ${round.matches
                    .map((match) => {
                      const playerA = playersById.get(match.playerAId);
                      const playerB = playersById.get(match.playerBId);
                      return `<li class="compact-schedule-row"><span>Tisch ${match.table}</span><strong>${escapeHtml(playerA?.name || match.playerAId)} - ${escapeHtml(playerB?.name || match.playerBId)}</strong>${renderSetScoreSummaryPill(match.sets, { totalScore: match.setScore })}</li>`;
                    })
                    .join("")}
                  ${(round.byes ?? [])
                    .map((bye) => {
                      const player = playersById.get(bye.playerId);
                      return `<li class="compact-schedule-row is-bye"><span>Freilos</span><strong>${escapeHtml(player?.name || bye.playerId)} setzt aus</strong><em>${escapeHtml(formatTtRaceByePoints(getTtRaceByePointValue(bye)))}</em></li>`;
                    })
                    .join("")}
                </ul>
              </article>
            `
          )
          .join("")}
      </div>
    `;
  }

  // ── F005/B024/B052: Gleichstand ───────────────────────────────────────────
  //
  // Die Logik weiß seit langem, wann eine Reihenfolge nicht mehr aus dem Spiel
  // folgt (`unresolvedTieMarker`) — gelesen hat den Marker nie jemand. Die App
  // sortierte alphabetisch weiter, und wer „Adam" hieß, zog in die KO-Runde
  // ein. Ab hier gilt: ein solcher Gleichstand hält an. Der Turnierleiter
  // entscheidet, per Los oder von Hand; die Entscheidung steht danach im
  // Blatt, in der Randspalte und im Export — mit der Angabe, wie sie fiel.

  /**
   * Der Ablageort der Entscheidungen hängt am Format: jede Betriebsart führt
   * ihre eigenen, damit ein Formatwechsel keine fremde Reihenfolge erbt.
   */
  function getTieDecisionScopeName() {
    if (isTtRaceTournament()) {
      return "ttRace";
    }
    return activeTournament?.mode === "groupsKnockout" ? "groupsKnockout" : "roundRobin";
  }

  function getStoredTieDecisions(tournament = activeTournament) {
    if (!tournament) {
      return {};
    }
    const scope = isTtRaceTournament(tournament)
      ? tournament.ttRace
      : tournament.mode === "groupsKnockout"
        ? tournament.groupsKnockout
        : tournament.roundRobin;
    const decisions = scope?.tieDecisions;
    return decisions && typeof decisions === "object" ? decisions : {};
  }

  /**
   * Alle offenen Gleichstände des laufenden Turniers in einer Form, die
   * Blatt, Randspalte und Dialog gleichermaßen lesen können.
   */
  function getUnresolvedTies() {
    if (isTtRaceTournament()) {
      // Im Schweizer System stehen nach Runde 1 zwangsläufig halbe Felder
      // gleich — das entscheidet niemand, das spielt sich aus. Gefragt wird
      // erst, wenn keine Runde mehr kommt.
      if (!getTtRaceProgress().complete && !isTournamentClosed()) {
        return [];
      }
      const standings = getTtRaceStandings();
      const gruppen = new Map();
      standings.forEach((standing) => {
        const marker = standing.unresolvedTieMarker;
        if (!marker) {
          return;
        }
        if (!gruppen.has(marker)) {
          gruppen.set(marker, {
            decisionKey: marker,
            scopeLabel: "TT-Race Rangliste",
            place: standing.displayRank ?? standing.rank,
            players: [],
            blocksQualification: false
          });
        }
        gruppen.get(marker).players.push({ name: standing.name });
      });
      return [...gruppen.values()].filter((tie) => tie.players.length > 1);
    }

    return (analysis?.unresolvedTies ?? []).map((tie) => ({
      decisionKey: tie.decisionKey,
      scopeLabel: tie.scopeLabel,
      place: tie.place,
      players: tie.players.map((player) => ({ name: player.name })),
      blocksQualification: Boolean(tie.blocksQualification)
    }));
  }

  function findUnresolvedTie(decisionKey) {
    return getUnresolvedTies().find((tie) => tie.decisionKey === decisionKey) ?? null;
  }

  function describeTiePlayers(tie) {
    return tie.players.map((player) => player.name).join(", ");
  }

  /**
   * Der Kasten, der den Gleichstand sichtbar macht. Er steht dort, wo sonst
   * weitergearbeitet wird — nicht in einer Fußnote: solange er steht, ist die
   * Reihenfolge nicht entschieden.
   */
  function renderUnresolvedTiesBlock() {
    const ties = getUnresolvedTies();
    if (ties.length === 0) {
      return "";
    }

    return `
      <section class="tie-callout" aria-labelledby="tie-callout-heading">
        <h3 id="tie-callout-heading">${ties.length === 1 ? "Gleichstand offen" : `${ties.length} Gleichstände offen`}</h3>
        <p>Alle Wertungskriterien sind erschöpft — aus dem Spiel folgt keine Reihenfolge mehr. Die Turnierleitung entscheidet.</p>
        <ul class="tie-callout-list">
          ${ties
            .map(
              (tie) => `
                <li>
                  <div>
                    <strong>${escapeHtml(tie.scopeLabel)} · Platz ${tie.place}</strong>
                    <span>${escapeHtml(describeTiePlayers(tie))}</span>
                    ${
                      tie.blocksQualification
                        ? '<span class="tie-callout-block">Der Einzug in die KO-Runde hängt daran.</span>'
                        : ""
                    }
                  </div>
                  <button class="primary-button" type="button" data-tie-decide="${escapeHtml(tie.decisionKey)}">Gleichstand entscheiden</button>
                </li>
              `
            )
            .join("")}
        </ul>
      </section>
    `;
  }

  /**
   * Der Dialog bietet beide Wege nebeneinander an, mit „Turnierleitung
   * entscheidet" als Voreinstellung (F005, Antonios Entscheidung). Das Los ist
   * kein Zufall im Verborgenen: es füllt die Liste sichtbar aus, und was
   * danach dasteht, wird gespeichert.
   */
  let tieDecisionDraft = null;

  function handleTieDecideClick(decisionKey) {
    const tie = findUnresolvedTie(decisionKey);
    if (!tie) {
      return;
    }
    tieDecisionDraft = {
      decisionKey,
      method: "leader",
      order: tie.players.map((player) => player.name),
      scopeLabel: tie.scopeLabel,
      place: tie.place,
      blocksQualification: tie.blocksQualification
    };
    renderTieDecisionDialog();
    tieDecisionDialog.showModal();
  }

  function renderTieDecisionDialog() {
    if (!tieDecisionDraft) {
      return;
    }
    const draft = tieDecisionDraft;

    tieDecisionContent.innerHTML = `
      <div class="wizard-header">
        <div>
          <p class="kicker">${escapeHtml(draft.scopeLabel)} · Platz ${draft.place}</p>
          <h2 id="tieDecisionTitle">Gleichstand entscheiden</h2>
        </div>
        <button class="tab-tool-button icon-only" type="button" data-tie-cancel aria-label="Dialog schließen" title="Schließen">
          <svg class="tab-tool-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true" focusable="false">
            <path d="M6 6l12 12" />
            <path d="M18 6L6 18" />
          </svg>
        </button>
      </div>
      <p class="tie-decision-copy">
        ${draft.order.length} Teilnehmer stehen nach allen Kriterien gleich.
        ${draft.blocksQualification ? "Vom Ergebnis hängt ab, wer in die KO-Runde einzieht." : ""}
      </p>
      <fieldset class="tie-decision-methods">
        <legend>Wie wird entschieden?</legend>
        <label class="tie-decision-method">
          <input type="radio" name="tieMethod" value="leader" ${draft.method === "leader" ? "checked" : ""} />
          <span>
            <strong>Turnierleitung entscheidet</strong>
            <small>Reihenfolge unten von Hand festlegen.</small>
          </span>
        </label>
        <label class="tie-decision-method">
          <input type="radio" name="tieMethod" value="draw" ${draft.method === "draw" ? "checked" : ""} />
          <span>
            <strong>Los ziehen</strong>
            <small>Die App zieht eine zufällige Reihenfolge, die dann feststeht.</small>
          </span>
        </label>
      </fieldset>
      ${draft.method === "draw" ? '<button class="secondary-button" type="button" data-tie-draw>Los ziehen</button>' : ""}
      <ol class="tie-decision-order">
        ${draft.order
          .map(
            (name, index) => `
              <li>
                <span class="tie-decision-rank">${index + 1}.</span>
                <span class="tie-decision-name">${escapeHtml(name)}</span>
                <span class="tie-decision-move">
                  <button class="ghost-button" type="button" data-tie-move="up" data-tie-index="${index}" ${index === 0 ? "disabled" : ""} aria-label="${escapeHtml(name)} nach oben">▲</button>
                  <button class="ghost-button" type="button" data-tie-move="down" data-tie-index="${index}" ${index === draft.order.length - 1 ? "disabled" : ""} aria-label="${escapeHtml(name)} nach unten">▼</button>
                </span>
              </li>
            `
          )
          .join("")}
      </ol>
      <div class="wizard-footer">
        <button class="ghost-button" type="button" data-tie-cancel>Abbrechen</button>
        <button class="primary-button" type="button" data-tie-confirm>Reihenfolge übernehmen</button>
      </div>
    `;
  }

  function handleTieDecisionDialogClick(event) {
    if (event.target === tieDecisionDialog || event.target.closest("[data-tie-cancel]")) {
      tieDecisionDialog.close();
      tieDecisionDraft = null;
      return;
    }

    const zug = event.target.closest("[data-tie-move]");
    if (zug && tieDecisionDraft) {
      const index = Number(zug.dataset.tieIndex);
      const ziel = zug.dataset.tieMove === "up" ? index - 1 : index + 1;
      if (ziel >= 0 && ziel < tieDecisionDraft.order.length) {
        const order = [...tieDecisionDraft.order];
        [order[index], order[ziel]] = [order[ziel], order[index]];
        tieDecisionDraft.order = order;
        renderTieDecisionDialog();
      }
      return;
    }

    if (event.target.closest("[data-tie-draw]") && tieDecisionDraft) {
      tieDecisionDraft.order = zieheLos(tieDecisionDraft.order);
      renderTieDecisionDialog();
      return;
    }

    if (event.target.closest("[data-tie-confirm]") && tieDecisionDraft) {
      speichereGleichstandsentscheidung(tieDecisionDraft);
      tieDecisionDialog.close();
      tieDecisionDraft = null;
    }
  }

  function handleTieDecisionDialogChange(event) {
    const feld = event.target.closest('input[name="tieMethod"]');
    if (!feld || !tieDecisionDraft) {
      return;
    }
    tieDecisionDraft.method = feld.value === "draw" ? "draw" : "leader";
    if (tieDecisionDraft.method === "draw") {
      tieDecisionDraft.order = zieheLos(tieDecisionDraft.order);
    }
    renderTieDecisionDialog();
  }

  function zieheLos(names) {
    const gezogen = [...names];
    for (let index = gezogen.length - 1; index > 0; index -= 1) {
      const tausch = Math.floor(Math.random() * (index + 1));
      [gezogen[index], gezogen[tausch]] = [gezogen[tausch], gezogen[index]];
    }
    return gezogen;
  }

  function speichereGleichstandsentscheidung(draft) {
    const scope = getTieDecisionScopeName();
    const eintrag = {
      names: [...draft.order],
      method: draft.method,
      decidedAt: new Date().toISOString()
    };
    const wortlaut = draft.method === "draw" ? "Los" : "Turnierleitung";

    updateActiveTournament((tournament) => {
      const ziel =
        scope === "ttRace"
          ? (tournament.ttRace ??= {})
          : scope === "groupsKnockout"
            ? tournament.groupsKnockout
            : tournament.roundRobin;
      ziel.tieDecisions = { ...(ziel.tieDecisions ?? {}), [draft.decisionKey]: eintrag };
    }, `Gleichstand entschieden (${wortlaut}): ${draft.order.join(" vor ")}`);

    showInfo(`Gleichstand entschieden — ${wortlaut}: ${draft.order.join(" vor ")}.`);
  }

  /**
   * Wie ein Platz zustande kam, gehört an den Platz. Ohne diesen Zusatz stünde
   * eine per Los entschiedene Reihenfolge da wie eine erspielte.
   */
  function formatTieDecisionNote(player) {
    if (!player?.tieDecision) {
      return "";
    }
    return `Gleichstand entschieden: ${player.tieDecision.methodLabel}`;
  }

  /**
   * Eine unerklaerte Marke ist genau der Fehler, den B047 beschreibt. Hier
   * steht deshalb kein Zeichen, sondern das Wort: „(Los)" oder
   * „(Turnierleitung)" — kurz genug fuer die Zelle, klar ohne Legende.
   */
  function renderTieDecisionBadge(player) {
    if (!player?.tieDecision) {
      return "";
    }
    return ` <span class="tie-decision-badge" title="${escapeHtml(formatTieDecisionNote(player))}">(${escapeHtml(player.tieDecision.methodLabel)})</span>`;
  }

  function renderRoundRobinSheet() {
    const { players, ranking, results, rounds } = analysis;
    const currentRoundNumber = getCurrentRoundNumber(rounds.length);
    const currentRound = rounds[currentRoundNumber - 1];
    const roundRobinLayoutClass = getRoundRobinLayoutClass(players.length);
    const matrixColumnCount = players.length + 3;
    const roundPairings = currentRound?.pairings ?? [];
    const openInRound = roundPairings.filter((pairing) => !pairing.score).length;
    const openTotal = Math.max(0, (analysis.totalMatches ?? 0) - (analysis.completedMatches ?? 0));

    // Umkehrung von früher: die laufende Runde ist die Arbeitsfläche, die
    // Vollmatrix liegt aufklappbar darunter.
    return `
      <div class="sheet-stack">
        <div class="work-head">
          <h3>Runde ${currentRoundNumber} erfassen</h3>
          <span class="work-count">${roundPairings.length - openInRound} von ${roundPairings.length} Spielen</span>
        </div>

        <div class="work-intro">
          <p>Satzpunkte eintragen, kurz oder ausgeschrieben: „8, 3, 5“ wird mit Enter zu 3:0 und den Sätzen 11:8, 11:3, 11:5.</p>
          ${renderSetDetailsToggle()}
        </div>

        ${renderCurrentRoundEntries(currentRound)}

        ${renderUnresolvedTiesBlock()}

        <div class="work-action">
          <button class="primary-button" type="button" data-round-shift="1" data-target-round="roundRobin" ${
            currentRoundNumber >= rounds.length ? "disabled" : ""
          }>Weiter zu Runde ${Math.min(currentRoundNumber + 1, rounds.length)}</button>
          <span class="action-reason">${
            openTotal > 0
              ? `${openTotal} Spiel${openTotal === 1 ? "" : "e"} im ganzen Turnier noch offen.`
              : "Alle Spiele sind erfasst."
          }</span>
          ${
            currentRoundNumber > 1
              ? `<button class="link-button" type="button" data-round-shift="-1" data-target-round="roundRobin">Zurück zu Runde ${currentRoundNumber - 1}</button>`
              : ""
          }
        </div>

        <details class="work-details">
          <summary>Vollmatrix anzeigen</summary>
          <div class="work-details-body">
            <div class="table-wrapper">
              <table class="data-table grid-matrix">
                <thead>
                  <tr>
                    <th>Spieler</th>
                    ${players
                      .map(
                        (player, index) =>
                          `<th class="is-centered" scope="col" data-voll="${escapeHtml(player)}">${index + 1}</th>`
                      )
                      .join("")}
                  </tr>
                </thead>
                <tbody>
                  ${players
                    .map(
                      (player, rowIndex) => `
                        <tr>
                          <th class="matrix-player-cell" scope="row" data-voll="${escapeHtml(player)}"><span class="matrix-player-number">${rowIndex + 1}</span>${escapeHtml(player)}</th>
                          ${players
                            .map((_, columnIndex) => renderRoundRobinCell(rowIndex, columnIndex, results))
                            .join("")}
                        </tr>
                      `
                    )
                    .join("")}
                </tbody>
              </table>
            </div>
            <p class="matrix-note">Nur das obere Dreieck wird bearbeitet, die grauen Werte sind die automatisch gespiegelte Gegenseite.</p>
          </div>
        </details>

        <details class="work-details">
          <summary>Alle Runden anzeigen</summary>
          <div class="work-details-body">
            ${renderRoundOverviewToggle(rounds, currentRoundNumber, "Vollständige Rundenübersicht anzeigen")}
          </div>
        </details>

        <details class="work-details">
          <summary>Spielplan mit Tischen und Zeiten</summary>
          <div class="work-details-body">
            ${renderScheduleConfigSection()}
            ${activeTournament.schedule.enabled ? renderScheduleSection() : ""}
          </div>
        </details>

        <details class="work-details">
          <summary>Vollständige Rangliste anzeigen</summary>
          <div class="work-details-body table-wrapper">
            ${renderRoundRobinRankingTable(ranking)}
          </div>
        </details>
      </div>
    `;
  }

  function getRoundRobinStandingForPlayer(rowIndex) {
    const sourceStat = analysis.stats?.[rowIndex];

    return (
      analysis.ranking?.find((player) => player.sourceIndex === rowIndex) ||
      analysis.ranking?.find(
        (player) =>
          sourceStat &&
          player.name === sourceStat.name &&
          player.setsWon === sourceStat.setsWon &&
          player.setsLost === sourceStat.setsLost &&
          player.wins === sourceStat.wins &&
          player.draws === sourceStat.draws &&
          player.losses === sourceStat.losses
      ) ||
      sourceStat
    );
  }

  function getRoundRobinLayoutClass(playerCount) {
    if (playerCount <= 4) {
      return "is-compact compact-small";
    }

    if (playerCount === 5) {
      return "is-compact compact-medium";
    }

    return "";
  }

  function renderCurrentRoundEntries(round) {
    if (!round) {
      if (isTtRaceTournament()) {
        if ((activeTournament.ttRace?.players ?? []).length === 0) {
          return `
            <div class="empty-round-state">
              <p>Noch keine Teilnehmer aus click-TT XML geladen.</p>
              <button class="secondary-button" type="button" data-race-action="choose-clicktt-file">XML wählen</button>
            </div>
          `;
        }

        return `
          <div class="empty-round-state">
            <p>Noch keine Schweizer Runde erzeugt.</p>
          </div>
        `;
      }

      return "<p>Keine Runde verfügbar.</p>";
    }

    if (round.matches) {
      return renderTtRaceRoundEntries(round);
    }

    const byePlayers = getRoundByePlayers(round);
    const usesContextColumn = round.pairings.some((pairing) => pairing.contextLabel);
    const listClass = usesContextColumn ? "match-list has-context" : "match-list";

    return `
      <ul class="${listClass}">
        ${round.pairings
          .map((pairing, index) => {
            const lead = usesContextColumn
              ? `<span class="match-context">${escapeHtml(pairing.contextLabel || "")}</span>`
              : `<span class="match-table">${index + 1}</span>`;

            return `
              <li class="match-row">
                ${lead}
                <span class="match-player">${renderPlayerMatchName(pairing.playerA, pairing.playerAStatus)}</span>
                <span class="match-versus">gegen</span>
                <span class="match-player">${renderPlayerMatchName(pairing.playerB, pairing.playerBStatus)}</span>
                ${renderCurrentRoundResultControls(pairing)}
              </li>
            `;
          })
          .join("")}
        ${byePlayers
          .map(
            (player) =>
              `<li class="match-row is-bye">
                <span class="match-table">—</span>
                <span class="match-player match-bye-text">${renderByePlayerName(player)} ist diese Runde spielfrei</span>
              </li>`
          )
          .join("")}
      </ul>
    `;
  }

  function renderTtRaceRoundEntries(round) {
    const playerById = new Map((activeTournament.ttRace?.players ?? []).map((player) => [player.id, player]));

    const showDetails = isSetDetailsVisible();

    return `
      <ul class="match-list">
        ${round.matches
          .map((match) => {
            const playerA = playerById.get(match.playerAId);
            const playerB = playerById.get(match.playerBId);
            const scoreText = formatSetScoreDisplay(match.sets);
            // B129: Ohne Satzdetails trägt das Feld das Gesamtergebnis („3:1").
            // Sonst stand die eingetippte Kurzform nach dem Neuzeichnen nicht
            // mehr da und das Spiel sah wieder offen aus.
            const feldwert = scoreText || formatTtRaceTotalScore(match.setScore);
            const detail = showDetails && scoreText ? `Sätze ${scoreText}` : "";

            return `
              <li class="match-row">
                <span class="match-table">${escapeHtml(String(match.table))}</span>
                <span class="match-player">${escapeHtml(playerA?.name || match.playerAId)}</span>
                <span class="match-versus">gegen</span>
                <span class="match-player">${escapeHtml(playerB?.name || match.playerBId)}</span>
                <span class="quick-result">
                  <input
                    class="quick-result-input"
                    data-tt-race-sets="${escapeHtml(match.id)}"
                    type="text"
                    autocomplete="off"
                    value="${escapeHtml(feldwert)}"
                    placeholder="9, 4, -6 oder 3:1"
                  />
                  <span class="quick-result-note" data-quick-note="${escapeHtml(match.id)}">${escapeHtml(detail)}</span>
                </span>
              </li>
            `;
          })
          .join("")}
        ${(round.byes ?? [])
          .map((bye) => {
            const player = playerById.get(bye.playerId);
            return `
              <li class="match-row is-bye">
                <span class="match-table">—</span>
                <span class="match-player match-bye-text">${escapeHtml(player?.name || bye.playerId)} ist diese Runde spielfrei · Freilos ${escapeHtml(formatTtRaceByePoints(getTtRaceByePointValue(bye)))}</span>
              </li>
            `;
          })
          .join("")}
      </ul>
    `;
  }

  function getTtRaceStandings() {
    if ((activeTournament.ttRace?.rounds?.length ?? 0) === 0) {
      return [];
    }

    const standings =
      activeTournament.ttRace?.standings?.length > 0
        ? activeTournament.ttRace.standings
        : ttRaceEngineModule
          ? ttRaceEngineModule.normalizeTtRaceTournament(activeTournament.ttRace).standings
          : [];

    // Eine getroffene Gleichstandsentscheidung wirkt auf die Anzeige und den
    // Druck, nicht auf die Paarungsrechnung — die Auslosung folgt der Wertung
    // (F005/B052).
    return ttRaceEngineModule?.applySwissTieDecisions
      ? ttRaceEngineModule.applySwissTieDecisions(standings, getStoredTieDecisions())
      : standings;
  }

  function renderTtRaceStandings() {
    const standings = getTtRaceStandings();

    if (standings.length === 0) {
      return "";
    }

    return `
      <section class="tt-race-standings" aria-labelledby="tt-race-standings-heading">
        <div class="section-heading compact">
          <h3 id="tt-race-standings-heading">TT-Race Rangliste</h3>
          <p>Schweizer-System-Wertung nach Siegen, Gegnerpunkten, direktem Vergleich und niedrigerem Q-TTR.</p>
        </div>
        <div class="table-wrapper compact-table-wrapper">
          <table class="ranking-table tt-race-standings-table">
            <thead>
              <tr>
                <th>Platz</th>
                <th>Spieler</th>
                <th class="is-numeric">TTR</th>
                <th class="is-numeric">Punkte</th>
                <th class="is-numeric">Siege</th>
                <th class="is-numeric">Gegner</th>
                <th class="is-numeric">Sätze</th>
                <th class="is-numeric">Bälle</th>
              </tr>
            </thead>
            <tbody>
              ${standings
                .map(
                  (standing) => `
                    <tr class="${standing.unresolvedTieMarker ? "is-tied" : ""}">
                      <td>${standing.displayRank ?? standing.rank}${standing.unresolvedTieMarker ? " geteilt" : ""}</td>
                      <td>${escapeHtml(standing.name)}${renderTieDecisionBadge(standing)}</td>
                      <td class="is-numeric">${escapeHtml(formatTtrValue(standing.rating))}</td>
                      <td class="is-numeric">${formatStandingNumber(standing.matchPoints)}</td>
                      <td class="is-numeric">${standing.wins}</td>
                      <td class="is-numeric">${formatStandingNumber(standing.buchholz)}</td>
                      <td class="is-numeric">${formatSignedValue(standing.setDiff)}</td>
                      <td class="is-numeric">${formatSignedValue(standing.ballDiff)}</td>
                    </tr>
                  `
                )
                .join("")}
            </tbody>
          </table>
        </div>
        <p class="rail-note">Gegner = Summe der Punkte aller Gegner, entscheidet bei gleicher Bilanz.</p>
      </section>
    `;
  }

  function formatStandingNumber(value) {
    return Number.isInteger(value) ? String(value) : Number(value).toFixed(1).replace(/\.0$/, "");
  }

  function hasTtrValue(value) {
    return value !== null && value !== undefined && String(value).trim() !== "" && Number.isFinite(Number(value));
  }

  function formatTtrValue(value) {
    const number = Number(value);
    return Number.isFinite(number) ? String(Math.round(number)) : "-";
  }

  function renderCurrentRoundResultControls(pairing) {
    if (activeTournament.mode === "groupsKnockout") {
      return renderNormalResultControlStack(
        pairing.matchKey,
        pairing.score || "",
        readMatchStatusValue(activeTournament, "group", pairing.matchKey),
        "compact-select",
        pairing.displayReversed,
        "group"
      );
    }

    const resultControls = renderMatchResultControls(
      pairing.matchKey,
      pairing.score || "",
      pairing.matchStatus,
      "compact-select",
      pairing.displayReversed
    );

    return renderNormalResultControlStack(
      pairing.matchKey,
      pairing.score || "",
      pairing.matchStatus,
      "compact-select",
      pairing.displayReversed,
      "",
      false,
      resultControls
    );
  }

  /**
   * Ein einziges Feld je Spiel trägt jetzt beides: das Gesamtergebnis und die
   * Satzpunkte. Die frühere Kombination aus Auswahlfeld und zusätzlichem
   * Satzfeld entfällt.
   */
  function renderNormalResultControlStack(
    key,
    selectedValue,
    selectedStatus = "normal",
    extraClass = "",
    reverseForDisplay = false,
    resultScope = "",
    isDisabled = false,
    resultControls = null
  ) {
    return (
      resultControls ||
      renderMatchResultControls(
        key,
        selectedValue,
        selectedStatus,
        extraClass,
        reverseForDisplay,
        resultScope,
        isDisabled
      )
    );
  }

  function getSetDetailsScreenKey() {
    return isTtRaceTournament() ? "ttRace" : activeTournament.mode || "roundRobin";
  }

  function isSetDetailsVisible() {
    return Boolean(setDetailsByScreen[getSetDetailsScreenKey()]);
  }

  function renderSetDetailsToggle() {
    return `
      <button class="ghost-button set-details-toggle" type="button" data-set-details-toggle>
        ${isSetDetailsVisible() ? "Satzdetails ausblenden" : "Satzdetails einblenden"}
      </button>
    `;
  }

  function handleSetDetailsToggle() {
    const screen = getSetDetailsScreenKey();
    setDetailsByScreen[screen] = !setDetailsByScreen[screen];
    renderTournamentSheet();
  }

  function renderQuickResultField(
    key,
    selectedValue,
    extraClass = "",
    reverseForDisplay = false,
    resultScope = "",
    isDisabled = false
  ) {
    const storedSetScore = getNormalSetScoreValue(activeTournament, resultScope, key);
    const displaySetScore = reverseForDisplay ? reverseNormalSetScoreText(storedSetScore) : storedSetScore;
    const note = isSetDetailsVisible() && displaySetScore ? `Sätze ${displaySetScore}` : "";

    return `
      <span class="quick-result">
        <input
          class="quick-result-input ${extraClass}"
          data-quick-key="${escapeHtml(key)}"
          data-quick-scope="${escapeHtml(resultScope)}"
          data-quick-reverse="${reverseForDisplay ? "true" : "false"}"
          type="text"
          autocomplete="off"
          value="${escapeHtml(selectedValue || "")}"
          placeholder="${escapeHtml(QUICK_RESULT_PLACEHOLDER)}"
          title="${escapeHtml(QUICK_RESULT_INPUT_HINT)}"
          ${isDisabled ? "disabled" : ""}
        />
        <span class="quick-result-note" data-quick-note="${escapeHtml(key)}">${escapeHtml(note)}</span>
      </span>
    `;
  }

  function setQuickResultNote(input, text, isError) {
    const note = input.parentElement?.querySelector("[data-quick-note]");
    if (!note) {
      return;
    }

    note.textContent = text;
    note.classList.toggle("is-error", Boolean(isError));
  }

  /** Während des Tippens sagt die Zeile unter dem Feld, was Enter übernimmt. */
  function handleQuickResultInput(event) {
    const input = event.target;
    const raw = input.value.trim();
    input.setCustomValidity("");

    if (!raw) {
      setQuickResultNote(input, "", false);
      return;
    }

    if (TOTAL_SCORE_PATTERN.test(raw)) {
      setQuickResultNote(input, `Enter übernimmt ${raw.replace(/\s+/g, "")}`, false);
      return;
    }

    const shortcut = parseMatchStatusShortcut(raw);
    if (shortcut) {
      const label = getMatchStatusLabel(shortcut.status);
      setQuickResultNote(
        input,
        shortcut.winnerSide
          ? `Enter übernimmt ${label} für ${shortcut.winnerSide === 1 ? "links" : "rechts"}`
          : `Enter übernimmt ${label}`,
        false
      );
      return;
    }

    const parsed = deriveMatchScoreFromSetScoreText(raw, activeTournament.matchMode, {
      disallowDraw: input.dataset.quickScope === "knockout"
    });

    if (!parsed.valid) {
      setQuickResultNote(input, QUICK_RESULT_ERROR, true);
      return;
    }

    setQuickResultNote(input, `Enter übernimmt ${parsed.matchScore} · ${parsed.normalizedText}`, false);
  }

  function handleQuickResultKeydown(event) {
    if (event.key !== "Enter") {
      return;
    }

    event.preventDefault();
    const input = event.target;
    pendingChainFocus = describeFocusField(input, tournamentSheet);
    const rendersBefore = sheetRenderCount;
    const committed = commitQuickResult(input);

    // Hat sich nichts geändert (gleicher Wert), zeichnet niemand neu — dann
    // springt Enter hier direkt weiter, sonst hat es das Neuzeichnen getan.
    if (committed && sheetRenderCount === rendersBefore) {
      applyPendingChainFocus(tournamentSheet);
    }
    pendingChainFocus = null;
  }

  /**
   * B020: Das `change` beim Verlassen des Feldes fiel bisher zwischen mousedown
   * und mouseup — der Klick auf das nächste Feld traf einen bereits ersetzten
   * Knoten und verpuffte. Ein Frame Abstand lässt den Klick erst ankommen.
   */
  function handleQuickResultChange(event) {
    const input = event.target;
    // Bewusst ohne isConnected-Wache: ein Feld, das zwischendurch ersetzt
    // wurde, trägt seinen Wert trotzdem noch — er wird über den Schlüssel
    // geschrieben. Ein stiller Verlust wäre schlimmer als ein doppelter
    // Schreibversuch, den `updateTournamentById` ohnehin verwirft.
    // Ein Frame Abstand reicht NICHT: der Frame fällt ~16 ms nach mousedown,
    // also mitten in den Tastendruck. Das Neuzeichnen tauscht den gedrückten
    // Knopf aus, mouseup trifft einen anderen Knoten und Chrome verwirft den
    // Klick (Welle-2-Prüfer: Undo, "Weiter zu Runde 2" und "Satzdetails"
    // lösten gar kein click-Ereignis mehr aus). Deshalb wartet das Schreiben,
    // solange eine Maustaste unten ist — der Klick darf erst zu Ende gehen.
    if (zeigerIstUnten) {
      ausstehendeCommits.add(input);
      return;
    }
    window.requestAnimationFrame(() => commitQuickResult(input));
  }

  /**
   * Solange eine Maustaste gedrückt ist, wird nicht neu gezeichnet. Sonst
   * verschwindet das Ziel des Klicks zwischen mousedown und mouseup.
   */
  let zeigerIstUnten = false;
  const ausstehendeCommits = new Set();

  document.addEventListener("pointerdown", () => {
    zeigerIstUnten = true;
  }, true);

  document.addEventListener("pointerup", () => {
    zeigerIstUnten = false;
    if (ausstehendeCommits.size === 0) {
      return;
    }
    const offen = [...ausstehendeCommits];
    ausstehendeCommits.clear();
    // Nach dem Klick, nicht davor: erst darf das Ziel seinen Klick bekommen,
    // dann wird geschrieben und neu gezeichnet.
    window.setTimeout(() => offen.forEach((feld) => commitQuickResult(feld)), 0);
  }, true);

  document.addEventListener("pointercancel", () => {
    zeigerIstUnten = false;
  }, true);

  /**
   * Enter schreibt das berechnete Gesamtergebnis ins Feld und speichert die
   * Sätze dazu. Ein von Hand gesetztes Gesamtergebnis verwirft sie wieder.
   * Rückgabe: ob der Wert übernommen wurde — daran hängt die Enter-Kette.
   */
  function commitQuickResult(input) {
    const key = input.dataset.quickKey;
    if (!key) {
      return false;
    }

    const resultScope = input.dataset.quickScope || "";
    const reverseForDisplay = input.dataset.quickReverse === "true";
    const raw = input.value.trim();
    input.setCustomValidity("");

    if (!raw) {
      updateActiveTournament((tournament) => {
        const results = getResultMapForScope(tournament, resultScope);
        const statuses = getStatusMapForScope(tournament, resultScope);
        deleteNormalSetScore(tournament, resultScope, key);
        delete results[key];
        if (statuses) {
          delete statuses[key];
        }
      }, "Ergebnis gelöscht", { checkRoundBackups: true });
      return true;
    }

    const shortcut = parseMatchStatusShortcut(raw);
    if (shortcut) {
      return commitMatchStatusShortcut(input, key, resultScope, reverseForDisplay, shortcut);
    }

    if (TOTAL_SCORE_PATTERN.test(raw)) {
      const normalized = raw.replace(/\s+/g, "");
      const value = reverseForDisplay ? reverseScore(normalized) : normalized;

      // B088: Der Kurzweg „3:1" ging bisher ohne jede Prüfung durch — auch
      // „2:2" in einem KO-Spiel. Die App meldete „Ergebnis gespeichert", der
      // Baum bekam aber keinen Sieger und wartete danach dauerhaft auf
      // „Sieger R…". Ein KO-Spiel ohne Sieger ist kein Ergebnis.
      const [links, rechts] = normalized.split(":").map(Number);
      if (resultScope === "knockout" && links === rechts) {
        const message = "Ein KO-Spiel braucht einen Sieger — Unentschieden ist hier nicht möglich.";
        input.setCustomValidity(message);
        input.reportValidity?.();
        setQuickResultNote(input, message, true);
        return false;
      }

      updateActiveTournament((tournament) => {
        const results = getResultMapForScope(tournament, resultScope);
        deleteNormalSetScore(tournament, resultScope, key);
        results[key] = value;
      }, "Ergebnis gespeichert", { checkRoundBackups: true });
      return true;
    }

    const parsed = deriveMatchScoreFromSetScoreText(raw, activeTournament.matchMode, {
      disallowDraw: resultScope === "knockout"
    });

    if (!parsed.valid) {
      const message = parsed.errors[0] || NORMAL_SET_SCORE_INPUT_HINT;
      input.setCustomValidity(message);
      input.reportValidity?.();
      setQuickResultNote(input, message, true);
      return false;
    }

    const storedSetScore = reverseForDisplay ? reverseNormalSetScoreText(parsed.normalizedText) : parsed.normalizedText;
    const storedMatchScore = reverseForDisplay ? reverseScore(parsed.matchScore) : parsed.matchScore;

    updateActiveTournament((tournament) => {
      const setScores = ensureNormalSetScoreMap(tournament, resultScope);
      const results = getResultMapForScope(tournament, resultScope);
      const statuses = getStatusMapForScope(tournament, resultScope);

      setScores[key] = storedSetScore;
      results[key] = storedMatchScore;
      if (statuses) {
        delete statuses[key];
      }
    }, "Ergebnis übernommen", { checkRoundBackups: true });
    return true;
  }

  /**
   * Kürzel im Ergebnisfeld (F-F): der Sonderstatus ist damit ohne die kleine,
   * unsichtbare „!"-Klappe erreichbar. Die Ziffer nennt den SIEGER, so wie sie
   * auf dem Bildschirm steht — „w.o. 2" heißt: der rechte Name gewinnt.
   */
  function parseMatchStatusShortcut(raw) {
    const text = String(raw ?? "")
      .toLowerCase()
      .replace(/[\s.]/g, "");
    const match = text.match(/^(wo|walkover|kampflos|auf|aufgabe|na|nichtgewertet)([12])?$/);
    if (!match) {
      return null;
    }

    const [, word, side] = match;
    const status = word === "wo" || word === "walkover" || word === "kampflos"
      ? "walkover"
      : word === "auf" || word === "aufgabe"
        ? "retired"
        : "void";

    return { status, winnerSide: status === "void" ? null : side ? Number(side) : null };
  }

  function commitMatchStatusShortcut(input, key, resultScope, reverseForDisplay, shortcut) {
    const statusLabel = getMatchStatusLabel(shortcut.status);

    if (!getStatusMapForScope(activeTournament, resultScope)) {
      const message = "Für dieses Spiel lässt sich kein Sonderstatus speichern.";
      input.setCustomValidity(message);
      input.reportValidity?.();
      setQuickResultNote(input, message, true);
      return false;
    }

    // Ohne Sieger wird nichts erfunden: der Status steht, das Ergebnis bleibt
    // offen, und die Zeile darunter sagt, was noch fehlt (B051).
    const displayScore = shortcut.winnerSide
      ? shortcut.winnerSide === 2
        ? reverseScore(getDefaultWinScore(activeTournament.matchMode))
        : getDefaultWinScore(activeTournament.matchMode)
      : "";
    const storedScore = displayScore && reverseForDisplay ? reverseScore(displayScore) : displayScore;

    updateActiveTournament((tournament) => {
      const statuses = getStatusMapForScope(tournament, resultScope);
      const results = getResultMapForScope(tournament, resultScope);
      deleteNormalSetScore(tournament, resultScope, key);
      statuses[key] = shortcut.status;
      if (storedScore) {
        results[key] = storedScore;
      } else {
        delete results[key];
      }
    }, `${statusLabel} gespeichert`, { checkRoundBackups: true });

    showInfo(
      shortcut.winnerSide || shortcut.status === "void"
        ? `${statusLabel} gespeichert${displayScore ? ` — Ergebnis ${displayScore}` : ""}.`
        : `${statusLabel} gespeichert — Sieger fehlt noch: „w.o. 1“ oder „w.o. 2“ schreiben.`
    );
    return true;
  }

  function renderPairingResultLabel(pairing) {
    if (pairing.score && pairing.matchStatus && pairing.matchStatus !== "normal") {
      return escapeHtml(pairing.score + " · " + getMatchStatusLabel(pairing.matchStatus));
    }
    if (pairing.score) {
      return escapeHtml(pairing.score);
    }
    if (pairing.matchStatus && pairing.matchStatus !== "normal") {
      return escapeHtml(getMatchStatusLabel(pairing.matchStatus));
    }
    return "offen";
  }

  function renderRoundCard(round, isActive) {
    const byePlayers = getRoundByePlayers(round);
    const status = getRoundStatus(round);

    return `
      <article class="round-card ${isActive ? "is-active-round" : ""}">
        <div class="round-card-header">
          <h4>${round.roundNumber}. Runde</h4>
          <span class="round-status-badge ${status.className}">${escapeHtml(status.label)}</span>
        </div>
        <ul class="round-pairings">
          ${round.pairings
            .map(
              (pairing) => `
                <li class="round-pairing ${pairing.score || (pairing.matchStatus && pairing.matchStatus !== "normal") ? "is-complete" : ""}">
                  <span>${renderPlayerMatchName(pairing.playerA, pairing.playerAStatus)} - ${renderPlayerMatchName(pairing.playerB, pairing.playerBStatus)}</span>
                  <strong>${renderPairingResultLabel(pairing)}</strong>
                </li>
              `
            )
            .join("")}
          ${
            byePlayers
              .map(
                (player) =>
                  `<li class="round-pairing bye-row"><span>${renderByePlayerName(player)} spielfrei</span><strong>Pause</strong></li>`
              )
              .join("")
          }
        </ul>
      </article>
    `;
  }

  function getRoundByePlayers(round) {
    if (Array.isArray(round?.byePlayers)) {
      return round.byePlayers;
    }
    return round?.byePlayer ? [round.byePlayer] : [];
  }

  function renderByePlayerName(player) {
    if (typeof player === "string") {
      return escapeHtml(player);
    }
    return renderPlayerMatchName(player?.name || "", player?.status);
  }

  /**
   * Die Kopfzeile der Matrix trägt nur so viel Name, wie in eine schmale
   * Spalte passt — bei Platzhaltern reicht die Nummer.
   */

  /**
   * Eine bearbeitbare Matrixzelle: das nackte Feld trägt das Gesamtergebnis
   * (4:0, 3:2), darunter stehen auf Wunsch die einzelnen Sätze. Kein
   * Steuerelement-Rahmen, damit der Inhalt in der Spaltenmitte sitzt.
   */
  function renderMatrixInputCell(key, value, resultScope = "") {
    const storedSets = getNormalSetScoreValue(activeTournament, resultScope, key);
    const showSets = isSetDetailsVisible() && storedSets;

    return `
      <td class="matrix-cell is-editable">
        <input
          class="matrix-input"
          data-quick-key="${escapeHtml(key)}"
          data-quick-scope="${escapeHtml(resultScope)}"
          data-quick-reverse="false"
          type="text"
          autocomplete="off"
          value="${escapeHtml(value || "")}"
          placeholder="offen"
          aria-label="Ergebnis eintragen"
        />
        ${showSets ? `<span class="matrix-sets">${escapeHtml(storedSets)}</span>` : ""}
      </td>
    `;
  }

  /** Gespiegelte oder noch offene Zelle der unteren Hälfte. */
  function renderMatrixMirroredCell(mirrored, resultScope = "", mirrorKey = "") {
    if (!mirrored) {
      return '<td class="matrix-cell is-open">offen</td>';
    }

    const storedSets = getNormalSetScoreValue(activeTournament, resultScope, mirrorKey);
    const showSets = isSetDetailsVisible() && storedSets;

    return `
      <td class="matrix-cell is-mirrored">
        ${escapeHtml(reverseScore(mirrored))}
        ${showSets ? `<span class="matrix-sets">${escapeHtml(reverseNormalSetScoreText(storedSets))}</span>` : ""}
      </td>
    `;
  }

  /**
   * Obere Hälfte wird erfasst, untere zeigt gespiegelt und grau, die
   * Diagonale ist getönt. Fehlende Begegnungen stehen als "offen".
   */
  function renderRoundRobinCell(rowIndex, columnIndex, results) {
    if (rowIndex === columnIndex) {
      return '<td class="matrix-cell is-diagonal"></td>';
    }

    if (rowIndex < columnIndex) {
      const key = `${rowIndex}-${columnIndex}`;
      return renderMatrixInputCell(key, results[key] || "");
    }

    const mirrorKey = `${columnIndex}-${rowIndex}`;
    return renderMatrixMirroredCell(results[mirrorKey], "", mirrorKey);
  }

  function renderTeamSheet() {
    const { playerRanking, teamSummary, results, rounds, doubles, doubleRounds } = analysis;
    const currentRoundNumber = getCurrentTeamRoundNumber(rounds.length);
    const currentRound = rounds[currentRoundNumber - 1];
    const currentDoubleRoundNumber = getCurrentDoubleRoundNumber(doubleRounds.length);
    const currentDoubleRound = doubleRounds[currentDoubleRoundNumber - 1];
    const roundPairings = currentRound?.pairings ?? [];
    const openInRound = roundPairings.filter((pairing) => !pairing.score).length;
    const matrixSize = `${analysis.teamAPlayers.length} × ${analysis.teamBPlayers.length}`;

    return `
      <div class="sheet-stack">
        <div class="work-head">
          <h3>Runde ${currentRoundNumber} erfassen</h3>
          <span class="work-count">${roundPairings.length - openInRound} von ${roundPairings.length} Einzeln</span>
        </div>

        <div class="work-intro">
          <p>Satzpunkte eintragen, kurz oder ausgeschrieben: „8, 3, 5“ wird mit Enter zu 3:0 und den Sätzen 11:8, 11:3, 11:5.</p>
          ${renderSetDetailsToggle()}
        </div>

        ${renderCurrentRoundEntries(currentRound)}

        <div class="work-action">
          <div class="round-control-bar">
            <button class="secondary-button" type="button" data-round-shift="-1" data-target-round="team" ${currentRoundNumber <= 1 ? "disabled" : ""}>Vorherige Runde</button>
            <label class="round-counter-input">
              <span class="sr-only">Runde</span>
              <input data-sheet-action="teamCurrentRound" type="number" min="1" max="${rounds.length}" value="${currentRoundNumber}" />
            </label>
            <span class="round-counter-total">von ${rounds.length}</span>
            <button class="primary-button" type="button" data-round-shift="1" data-target-round="team" ${currentRoundNumber >= rounds.length ? "disabled" : ""}>Nächste Runde</button>
          </div>
          ${
            openInRound > 0
              ? `<span class="action-reason">Noch ${openInRound} Ergebnis${openInRound === 1 ? "" : "se"} in dieser Runde offen.</span>`
              : ""
          }
        </div>

        <details class="work-details">
          <summary>Einzelmatrix ${matrixSize} anzeigen</summary>
          <div class="work-details-body">
            <div class="work-intro">
              <p>${escapeHtml(analysis.teamAName)} steht in den Zeilen, ${escapeHtml(analysis.teamBName)} in den Spalten. Ergebnis als 3:1 eintragen oder die Sätze — Enter rechnet um.</p>
              ${renderSetDetailsToggle()}
            </div>
            <div class="table-wrapper">
              <table class="data-table grid-matrix">
                <thead>
                  <tr>
                    <th>Spieler</th>
                    ${analysis.teamBPlayers
                      .map(
                        (player, index) =>
                          `<th class="is-centered" scope="col" data-voll="${escapeHtml(player)}">${escapeHtml(player)}</th>`
                      )
                      .join("")}
                  </tr>
                </thead>
                <tbody>
                  ${analysis.teamAPlayers
                    .map(
                      (player, rowIndex) => `
                        <tr>
                          <th class="matrix-player-cell" scope="row" data-voll="${escapeHtml(player)}">${escapeHtml(player)}</th>
                          ${analysis.teamBPlayers
                            .map(
                              (_, columnIndex) => `
                                ${renderMatrixInputCell(`${rowIndex}-${columnIndex}`, results[`${rowIndex}-${columnIndex}`] || "")}
                              `
                            )
                            .join("")}
                        </tr>
                      `
                    )
                    .join("")}
                </tbody>
              </table>
            </div>
          </div>
        </details>

        <details class="work-details">
          <summary>Alle Teamrunden anzeigen</summary>
          <div class="work-details-body">
            ${renderRoundOverviewToggle(rounds, currentRoundNumber, "Vollständige Teamrunden anzeigen")}
          </div>
        </details>

        ${
          doubles.length > 0
            ? `
              <section class="table-card current-round-card">
                <div class="section-heading compact">
                  <div>
                    <h3>Aktuelle Doppelrunde</h3>
                    <p>Hier bestimmst du pro Runde, ob der Rundenplan gilt oder ob du die Doppel manuell neu setzt.</p>
                  </div>
                </div>
                ${renderProgressSummary(
                  doubleRounds,
                  currentDoubleRoundNumber,
                  analysis.completedDoubles,
                  analysis.totalDoubles,
                  "Doppelspiele"
                )}
                <div class="round-control-bar team-round-bar">
                  <button class="round-nav-button" type="button" data-round-shift="-1" data-target-round="double" ${currentDoubleRoundNumber <= 1 ? "disabled" : ""}>Vorherige</button>
                  <span class="round-control-label">Runde</span>
                  <label class="round-counter-input">
                    <span class="sr-only">Doppelrunde</span>
                    <input data-sheet-action="doubleCurrentRound" type="number" min="1" max="${doubleRounds.length}" value="${currentDoubleRoundNumber}" />
                  </label>
                  <span class="round-counter-total">von ${doubleRounds.length}</span>
                  <button class="round-nav-button" type="button" data-round-shift="1" data-target-round="double" ${currentDoubleRoundNumber >= doubleRounds.length ? "disabled" : ""}>Nächste</button>
                </div>
                <label class="double-round-toggle">
                  <input data-sheet-action="doubleRoundManual" type="checkbox" ${currentDoubleRound?.manual ? "checked" : ""} />
                  <span>${currentDoubleRound?.manual ? "Manuelle Paarung aktiv" : "Rundenplan aktiv"}</span>
                </label>
                <div class="double-match-list">
                  ${renderDoubleRoundEntries(currentDoubleRound)}
                </div>
                ${renderRoundOverviewToggle(doubleRounds, currentDoubleRoundNumber, "Vollständige Doppelrunden anzeigen")}
              </section>
            `
            : ""
        }

        <details class="work-details">
          <summary>Spielplan mit Tischen und Zeiten</summary>
          <div class="work-details-body">
            ${renderScheduleConfigSection()}
            ${activeTournament.schedule.enabled ? renderScheduleSection() : ""}
          </div>
        </details>

        <details class="work-details">
          <summary>Spielerstatistik anzeigen</summary>
          <div class="work-details-body">
            ${renderPlayerStatsFontControls()}
            <div class="table-wrapper player-stats-table-shell" data-font-size-target="playerStats">
              ${renderTeamRankingTable(playerRanking)}
            </div>
          </div>
        </details>
      </div>
    `;
  }

  function renderGroupsKnockoutSheet() {
    const currentGroupRoundNumber = getCurrentGroupsRoundNumber(analysis.groupRoundSchedule.length);
    const currentGroupRound = analysis.groupRoundSchedule[currentGroupRoundNumber - 1];
    const currentKnockoutRoundNumber = getCurrentKnockoutRoundNumber(analysis.knockoutRounds.length);
    const currentKnockoutRound = analysis.knockoutRounds[currentKnockoutRoundNumber - 1];

    const roundPairings = currentGroupRound?.pairings ?? [];
    const openInRound = roundPairings.filter((pairing) => !pairing.score).length;
    const isLastGroupRound = currentGroupRoundNumber >= analysis.groupRoundSchedule.length;
    const openGroupMatches = analysis.totalGroupMatches - analysis.completedGroupMatches;

    // Das Format hat zwei Phasen; die Arbeitsfläche führt nur die laufende.
    return `
      <div class="sheet-stack">
        <div class="work-head">
          <h3>Gruppenrunde ${currentGroupRoundNumber} erfassen</h3>
          <span class="work-count">${roundPairings.length - openInRound} von ${roundPairings.length} Spielen</span>
        </div>

        <div class="work-intro">
          <p>Ergebnisse aus allen Gruppen derselben Runde gesammelt eintragen. Satzpunkte kurz oder ausgeschrieben; Enter übernimmt.</p>
          ${renderSetDetailsToggle()}
        </div>

        ${renderCurrentRoundEntries(currentGroupRound)}

        ${renderUnresolvedTiesBlock()}

        <div class="work-action">
          <button class="primary-button" type="button" data-round-shift="0" data-target-round="knockout" ${analysis.groupStageComplete ? "" : "disabled"}>
            KO-Runde öffnen
          </button>
          ${
            analysis.groupStageComplete
              ? ""
              : `<span class="action-reason">${
                  analysis.qualificationBlocked
                    ? "Gleichstand offen — bis die Turnierleitung entschieden hat, steht nicht fest, wer einzieht."
                    : isLastGroupRound
                      ? `Runde ${currentGroupRoundNumber} ist die letzte Gruppenrunde — noch ${openGroupMatches} Spiel${openGroupMatches === 1 ? "" : "e"} offen.`
                      : `Noch ${openGroupMatches} Gruppenspiel${openGroupMatches === 1 ? "" : "e"} offen.`
                }</span>`
          }
          ${
            isLastGroupRound
              ? ""
              : `<button class="link-button" type="button" data-round-shift="1" data-target-round="groupStage">Weiter zu Gruppenrunde ${currentGroupRoundNumber + 1}</button>`
          }
          ${
            currentGroupRoundNumber > 1
              ? `<button class="link-button" type="button" data-round-shift="-1" data-target-round="groupStage">Zurück zu Gruppenrunde ${currentGroupRoundNumber - 1}</button>`
              : ""
          }
        </div>

        <div class="action-row work-settings">
          ${renderRandomDrawSection(
            "shuffle-groups-knockout",
            "Teilnehmer neu auslosen",
            "Mischt die Teilnehmer zufällig und verteilt sie danach neu auf die Gruppen.",
            "Möglich solange die Gruppenphase noch nicht gestartet ist.",
            hasGroupsKnockoutDrawStarted(activeTournament)
          )}
        </div>

        <section class="knockout-preview">
          <h3 class="section-subheading">KO-Runde</h3>
          ${
            analysis.groupStageComplete
              ? renderKnockoutRounds(currentKnockoutRound, currentKnockoutRoundNumber)
              : `<p class="knockout-preview-note">${
                  analysis.qualificationBlocked
                    ? "Alle Gruppenspiele sind gespielt. Ein Gleichstand am Qualifikationsschnitt ist noch offen — erst danach steht das Raster."
                    : "Wird aus den Gruppentabellen gebildet. Die Plätze stehen als Herkunft, bis die Gruppen abgeschlossen sind."
                }</p>
                 ${renderKnockoutPreview()}`
          }
        </section>

        ${renderRoundOverviewToggle(analysis.groupRoundSchedule, currentGroupRoundNumber, "Alle Gruppenrunden anzeigen")}

        <details class="work-details">
          <summary>Gruppenmatrizen anzeigen</summary>
          <div class="work-details-body groups-grid">
            ${analysis.groups.map((group) => renderGroupStageCard(group)).join("")}
          </div>
        </details>

        ${
          analysis.finalStandings.length > 0
            ? `<details class="work-details" open>
                <summary>Finalstand</summary>
                <div class="work-details-body table-wrapper">
                  ${renderFinalStandingsTable(analysis.finalStandings)}
                </div>
              </details>`
            : ""
        }
      </div>
    `;
  }

  function renderGroupStageCard(group) {
    return `
      <article class="table-card group-stage-card">
        <div class="section-heading compact">
          <div>
            <h3>${escapeHtml(group.name)}</h3>
            <p>${group.completedMatches} von ${group.totalMatches} Spielen eingetragen.</p>
          </div>
          <span class="round-status-badge ${group.completedMatches === group.totalMatches ? "is-complete" : group.completedMatches > 0 ? "is-progress" : "is-pending"}">
            ${group.completedMatches === group.totalMatches ? "Fertig" : "Offen"}
          </span>
        </div>
        <div class="table-wrapper">
          <table class="matrix-table group-matrix-table">
            <thead>
              <tr>
                <th>Teilnehmer</th>
                ${group.players.map((player) => `<th>${escapeHtml(player.name)}</th>`).join("")}
              </tr>
            </thead>
            <tbody>
              ${group.players
                .map(
                  (player, rowIndex) => `
                    <tr>
                      <th>${escapeHtml(player.name)}</th>
                      ${group.players.map((_, columnIndex) => renderGroupMatrixCell(group, rowIndex, columnIndex)).join("")}
                    </tr>
                  `
                )
                .join("")}
            </tbody>
          </table>
        </div>
        <div class="table-wrapper group-ranking-wrapper">
          ${renderGroupRankingTable(group.ranking)}
        </div>
      </article>
    `;
  }

  function renderGroupMatrixCell(group, rowIndex, columnIndex) {
    if (rowIndex === columnIndex) {
      return '<td class="matrix-cell is-diagonal"></td>';
    }

    if (rowIndex < columnIndex) {
      const key = `group-${group.groupIndex}-${rowIndex}-${columnIndex}`;
      return renderMatrixInputCell(key, group.results[`${rowIndex}-${columnIndex}`] || "", "group");
    }

    // B109: Ohne den Schlüssel schlug `getNormalSetScoreValue` `setScores[""]`
    // nach — die gespiegelte untere Hälfte der Gruppenmatrix zeigte nie
    // Satzdetails, während dieselbe Zelle im Jeder-gegen-jeden sie hatte.
    // Der Ablageschlüssel der Sätze trägt hier die Gruppennummer.
    const mirrorKey = `group-${group.groupIndex}-${columnIndex}-${rowIndex}`;
    return renderMatrixMirroredCell(group.results[`${columnIndex}-${rowIndex}`], "group", mirrorKey);
  }

  /**
   * Gruppentabelle für die Randspalte (11a): keine Rahmen, nur Haarlinien.
   * Die Qualifikanten stehen normal, der Rest blass — vor den Spielen ist
   * niemand qualifiziert, deshalb entscheidet allein die aktuelle Platzierung.
   */
  function renderGroupRailStanding(group) {
    const ranking = group.ranking ?? [];

    return `
      <section class="rail-block">
        <h3 class="rail-heading">${escapeHtml(group.name || "")}</h3>
        <div class="rail-standing">
          ${ranking
            .map(
              (player) => `
                <div class="rail-standing-row ${player.isQualified ? "" : "is-dimmed"}">
                  <span class="rail-standing-rank">${player.place}</span>
                  <span class="rail-standing-name">${escapeHtml(player.name || "")}</span>
                  <span class="rail-standing-record">${player.wins ?? 0}–${player.losses ?? 0}</span>
                  <span class="rail-standing-sets">${formatSignedValue(player.setDiff ?? 0)}</span>
                </div>
              `
            )
            .join("")}
        </div>
      </section>
    `;
  }

  function renderGroupRankingTable(ranking) {
    return `
      <table class="stats-table group-ranking-table">
        <thead>
          <tr>
            <th>Platz</th>
            <th>Teilnehmer</th>
            <th>Bilanz</th>
            <th>Sätze&nbsp;+</th>
            <th>Sätze&nbsp;−</th>
            <th>Differenz</th>
            <th>KO</th>
          </tr>
        </thead>
        <tbody>
          ${ranking.map((player) => `
            <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
              <td>${player.place}${player.sharedPlace ? " geteilt" : ""}</td>
              <td>${escapeHtml(player.name)}${renderTieDecisionBadge(player)}</td>
              <td>${player.wins}/${player.losses}</td>
              <td>${player.setsWon}</td>
              <td>${player.setsLost}</td>
              <td>${player.setDiff}</td>
              <td>${player.blocksQualification ? "Gleichstand offen" : player.isQualified ? "Qualifiziert" : "-"}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  /**
   * Vorschau des KO-Rasters, solange die Gruppen laufen: keine Kästen,
   * sondern dieselben Listenzeilen wie oben — mit der Herkunft der Plätze
   * statt leerer Felder. Die Setzung folgt `buildKnockoutBracket`:
   * Qualifikanten nach Platz sortiert, dann Erster gegen Letzten.
   */
  function renderKnockoutPreview() {
    const groups = analysis.groups ?? [];
    const perGroup = Math.max(1, analysis.qualifiersPerGroup ?? 2);

    if (groups.length === 0) {
      return `<p class="knockout-preview-note">Noch keine Gruppen angelegt.</p>`;
    }

    const seeds = [];
    for (let rank = 1; rank <= perGroup; rank += 1) {
      groups.forEach((group) => seeds.push(describeGroupSlot(rank, group.name)));
    }

    let bracketSize = 2;
    while (bracketSize < Math.max(2, seeds.length)) {
      bracketSize *= 2;
    }

    const padded = [...seeds, ...Array.from({ length: bracketSize - seeds.length }, () => "Freilos")];
    const matchCount = bracketSize / 2;
    const roundName = getPreviewRoundName(matchCount);

    const rows = Array.from({ length: matchCount }, (_, index) => ({
      a: padded[index],
      b: padded[bracketSize - 1 - index],
      label: matchCount === 1 ? roundName : `${roundName} ${index + 1}`
    }));

    if (analysis.placementMatchesEnabled && matchCount === 2) {
      rows.push({
        a: `Verlierer ${roundName} 1`,
        b: `Verlierer ${roundName} 2`,
        label: "Platz 3",
        isPlacement: true
      });
    }

    return `
      <div class="knockout-preview-list">
        ${rows
          .map(
            (row) => `
              <div class="knockout-preview-row ${row.isPlacement ? "is-placement" : ""}" ${
                row === rows[rows.length - 1] ? 'data-abweichung="Abschlusslinie der Liste"' : ""
              }>
                <span class="knockout-preview-name">${escapeHtml(row.a)}</span>
                <span class="knockout-preview-versus">gegen</span>
                <span class="knockout-preview-name">${escapeHtml(row.b)}</span>
                <span class="knockout-preview-label">${escapeHtml(row.label)}</span>
              </div>
            `
          )
          .join("")}
      </div>
    `;
  }

  function describeGroupSlot(rank, groupName) {
    const ordinals = ["Sieger", "Zweiter", "Dritter", "Vierter", "Fünfter", "Sechster"];
    const ordinal = ordinals[rank - 1] || `Platz ${rank}`;
    return `${ordinal} ${groupName}`;
  }

  function getPreviewRoundName(matchCount) {
    if (matchCount === 1) {
      return "Finale";
    }
    if (matchCount === 2) {
      return "Halbfinale";
    }
    if (matchCount === 4) {
      return "Viertelfinale";
    }
    return "KO-Runde";
  }

  function renderKnockoutRounds(currentRound, currentRoundNumber) {
    return `
      <div class="progress-strip">
        <span class="progress-pill">Qualifikanten: ${analysis.qualifiers.length}</span>
        <span class="progress-pill">KO-Spiele: ${analysis.completedKnockoutMatches}/${analysis.totalKnockoutMatches}</span>
      </div>
      ${analysis.knockoutRounds.length > 0 ? `
        <div class="round-control-bar">
          <button class="round-nav-button" type="button" data-round-shift="-1" data-target-round="knockout" ${currentRoundNumber <= 1 ? "disabled" : ""}>Vorherige</button>
          <span class="round-control-label">KO-Runde</span>
          <label class="round-counter-input">
            <span class="sr-only">KO-Runde</span>
            <input data-sheet-action="knockoutCurrentRound" type="number" min="1" max="${analysis.knockoutRounds.length}" value="${currentRoundNumber}" />
          </label>
          <span class="round-counter-total">von ${analysis.knockoutRounds.length}</span>
          <button class="round-nav-button" type="button" data-round-shift="1" data-target-round="knockout" ${currentRoundNumber >= analysis.knockoutRounds.length ? "disabled" : ""}>Nächste</button>
        </div>
        <div class="knockout-round-focus">
          <h4>${escapeHtml(currentRound?.roundName || "KO-Runde")}</h4>
          <div class="knockout-match-grid">
            ${(currentRound?.pairings ?? []).map(renderKnockoutMatchCard).join("")}
          </div>
        </div>
      ` : ""}
      ${analysis.placementMatches.length > 0 ? `
        <div class="knockout-round-focus placement-round-focus">
          <h4>Platzierungsspiel</h4>
          <div class="knockout-match-grid">
            ${analysis.placementMatches.map(renderKnockoutMatchCard).join("")}
          </div>
        </div>
      ` : ""}
      <div class="knockout-round-grid">
        ${analysis.knockoutRounds.map((round) => renderKnockoutRoundCard(round, round.roundNumber === currentRoundNumber)).join("")}
      </div>
    `;
  }

  function renderKnockoutRoundCard(round, isActive) {
    const status = getRoundStatus(round);
    return `
      <article class="round-card knockout-round-card ${isActive ? "is-active-round" : ""}">
        <div class="round-card-header">
          <h4>${escapeHtml(round.roundName)}</h4>
          <span class="round-status-badge ${status.className}">${escapeHtml(status.label)}</span>
        </div>
        <div class="knockout-match-stack">
          ${round.pairings.map(renderKnockoutMatchSummary).join("")}
        </div>
      </article>
    `;
  }

  function renderKnockoutMatchSummary(match) {
    return `
      <div class="round-pairing ${match.isComplete ? "is-complete" : ""}">
        <span>${escapeHtml(match.playerA)} - ${escapeHtml(match.playerB)}</span>
        <strong>${match.isBye ? "Freilos" : match.score || "offen"}</strong>
      </div>
    `;
  }

  function renderKnockoutMatchCard(match) {
    const disabled = !match.isPlayable;
    const helper = match.isBye
      ? "Freilos - automatisch weiter"
      : match.isReady
        ? "Ergebnis eintragen"
        : "Wartet auf vorherige Spiele";

    return `
      <article class="knockout-match-card ${match.isComplete ? "is-complete" : ""}">
        <div>
          <strong>${escapeHtml(match.playerA)} - ${escapeHtml(match.playerB)}</strong>
          <span>${escapeHtml(helper)}</span>
        </div>
        ${renderNormalResultControlStack(match.id, match.score || "", readMatchStatusValue(activeTournament, "knockout", match.id), "compact-select", false, "knockout", disabled)}
      </article>
    `;
  }

  function renderFinalStandingsTable(standings) {
    return `
      <table class="stats-table">
        <thead>
          <tr>
            <th>Platz</th>
            <th>Teilnehmer</th>
            <th>Qualifikation</th>
          </tr>
        </thead>
        <tbody>
          ${standings.map((player) => `
            <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
              <td>${player.place}${player.sharedPlace ? " geteilt" : ""}</td>
              <td>${escapeHtml(player.name)}</td>
              <td>${escapeHtml(player.seedLabel || player.groupName)}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  function renderScheduleSection() {
    const schedule = analysis.schedule;
    if (!schedule) {
      return "";
    }

    return [
      "      <section class=\"table-card schedule-card\">",
      "        <details class=\"details-toggle schedule-toggle\">",
      "          <summary>Spielplan anzeigen (" + schedule.completedMatches + "/" + schedule.totalMatches + " gespielt)</summary>",
      "          <div class=\"details-toggle-body schedule-toggle-body\">",
      "            <div class=\"schedule-meta-row\">",
      "              <span>Start " + escapeHtml(schedule.startTime) + "</span>",
      "              <span>Ende ca. " + escapeHtml(schedule.endTime) + "</span>",
      "              <span>" + schedule.config.fieldCount + " Tisch" + (schedule.config.fieldCount === 1 ? "" : "e") + "</span>",
      "              <span>" + schedule.config.matchDurationMinutes + " Min. + " + schedule.config.breakMinutes + " Min. Puffer</span>",
      "            </div>",
      "            <div class=\"table-wrapper\">",
      renderScheduleTable(schedule),
      "            </div>",
      renderCompactScheduleList(schedule),
      "          </div>",
      "        </details>",
      "      </section>"
    ].join("");
  }

  function renderScheduleTable(schedule) {
    if (schedule.matches.length === 0) {
      return "<p class=\"muted-text\">Noch keine Spiele im Plan.</p>";
    }

    const rows = schedule.matches
      .map((match) => [
        "                <tr class=\"" + (match.status === "gespielt" ? "is-complete" : "") + "\">",
        "                  <td>" + escapeHtml(match.plannedTime) + "</td>",
        "                  <td>" + escapeHtml(match.fieldName) + "</td>",
        "                  <td>" + escapeHtml(match.roundLabel) + "</td>",
        "                  <td><span class=\"schedule-match-type\">" + escapeHtml(match.matchType) + "</span> " + escapeHtml(match.matchLabel) + "</td>",
        "                  <td><span class=\"round-status-badge " + (match.status === "gespielt" ? "is-complete" : "is-pending") + "\">" + escapeHtml(match.status) + "</span></td>",
        "                </tr>"
      ].join(""))
      .join("");

    return [
      "      <table class=\"stats-table schedule-table\">",
      "        <thead>",
      "          <tr>",
      "            <th>Uhrzeit</th>",
      "            <th>Tisch</th>",
      "            <th>Runde</th>",
      "            <th>Begegnung</th>",
      "            <th>Status</th>",
      "          </tr>",
      "        </thead>",
      "        <tbody>",
      rows,
      "        </tbody>",
      "      </table>"
    ].join("");
  }

  function renderCompactScheduleList(schedule) {
    if (schedule.matches.length === 0) {
      return "<p class=\"compact-schedule-empty muted-text\">Noch keine Spiele im Plan.</p>";
    }

    const rows = schedule.matches
      .map((match) => {
        const statusClass = match.status === "gespielt" ? "is-complete" : "is-pending";
        return `
          <article class="compact-schedule-row ${match.status === "gespielt" ? "is-complete" : ""}">
            <div class="compact-schedule-time">
              <strong>${escapeHtml(match.plannedTime)}</strong>
              <span>${escapeHtml(match.fieldName)}</span>
            </div>
            <div class="compact-schedule-main">
              <div class="compact-schedule-meta">
                <span>${escapeHtml(match.roundLabel)}</span>
                <span class="schedule-match-type">${escapeHtml(match.matchType)}</span>
              </div>
              <strong>${escapeHtml(match.matchLabel)}</strong>
            </div>
            <span class="round-status-badge ${statusClass}">${escapeHtml(match.status)}</span>
          </article>
        `;
      })
      .join("");

    return `<div class="compact-schedule-list" aria-label="Kompakter Spielplan">${rows}</div>`;
  }

  function renderDoubleMatchEntry(entry) {
    const helperText =
      entry.teamADouble && entry.teamBDouble
        ? "Paarung wählen und Ergebnis eintragen."
        : "Bitte für diese Runde auf beiden Seiten ein Doppel auswählen.";

    return `
      <div class="double-match-row ${entry.score ? "is-complete" : ""}">
        <div class="double-match-copy">
          <strong>Doppel ${entry.pairingNumber}</strong>
          <span>${helperText}</span>
        </div>
        <div class="double-match-controls">
          <label>
            <span>${escapeHtml(analysis.teamAName)}</span>
            ${renderDoubleAssignmentSelect("teamA", entry)}
          </label>
          <label>
            <span>${escapeHtml(analysis.teamBName)}</span>
            ${renderDoubleAssignmentSelect("teamB", entry)}
          </label>
          <label>
            <span>Ergebnis</span>
            ${renderNormalResultControlStack(entry.id, entry.score || "", entry.matchStatus, "compact-select", false, "double", !entry.isComplete)}
          </label>
        </div>
      </div>
    `;
  }

  function renderDoubleRoundEntries(round) {
    if (!round) {
      return "<p>Keine Doppelrunde verfügbar.</p>";
    }

    return round.pairings.map((entry) => renderDoubleMatchEntry(entry)).join("");
  }

  function renderDoubleAssignmentSelect(side, entry) {
    const isTeamA = side === "teamA";
    const selectedId = isTeamA ? entry.teamADoubleId : entry.teamBDoubleId;
    const options = analysis.doubles
      .map((entry) => {
        const label = isTeamA ? entry.teamALabel : entry.teamBLabel;
        return {
          id: entry.id,
          label: label || `Doppel ${entry.order} unvollständig`,
          order: entry.order
        };
      })
      .filter((entry) => entry.id);
    const action = isTeamA ? "doubleRoundPairTeamA" : "doubleRoundPairTeamB";

    return `
      <select
        class="score-select compact-select double-assignment-select"
        data-sheet-action="${action}"
        data-double-pairing-id="${entry.id}"
        ${entry.manual ? "" : "disabled"}
      >
        <option value="" ${selectedId ? "" : "selected"}>Doppel wählen</option>
        ${options
          .map(
            (option) => `
              <option
                value="${option.id}"
                ${option.id === selectedId ? "selected" : ""}
              >
                Doppel ${option.order}: ${escapeHtml(option.label)}
              </option>
            `
          )
          .join("")}
      </select>
    `;
  }

  function renderRoundOverviewToggle(rounds, currentRoundNumber, summaryLabel) {
    const completedRounds = rounds.filter((round) => getRoundStatus(round).isComplete).length;
    return `
      <details class="round-overview-toggle">
        <summary>${escapeHtml(summaryLabel)} (${completedRounds}/${rounds.length} fertig)</summary>
        <div class="round-overview-body">
          <div class="round-plan-grid">
            ${rounds
              .map((round) => renderRoundCard(round, round.roundNumber === currentRoundNumber))
              .join("")}
          </div>
        </div>
      </details>
    `;
  }

  function renderPlayerStatsFontControls() {
    const currentIndex = PLAYER_STATS_FONT_SIZES.indexOf(playerStatsFontSize);

    return `
      <div class="font-size-toolbar" aria-label="Schriftgröße der detaillierten Spielerstatistik">
        <span class="font-size-toolbar-label">Schrift</span>
        <div class="font-size-button-row">
          <button class="font-size-button" type="button" data-font-size-step="-1" aria-label="Schrift kleiner" ${currentIndex <= 0 ? "disabled" : ""}>-</button>
          <button class="font-size-button" type="button" data-font-size-step="1" aria-label="Schrift größer" ${currentIndex >= PLAYER_STATS_FONT_SIZES.length - 1 ? "disabled" : ""}>+</button>
        </div>
      </div>
    `;
  }

  function renderRoundRobinRankingTable(ranking) {
    if (isFixedSetMatchMode(analysis.matchMode)) {
      return `
        <table class="stats-table">
          <thead>
            <tr>
              <th>Platz</th>
              <th>Spieler</th>
              <th>Punkte</th>
              <th>Satzbilanz</th>
              <th>Differenz</th>
            </tr>
          </thead>
          <tbody>
            ${ranking
              .map(
                (player) => `
                  <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
                    <td>${player.place}${player.sharedPlace ? " geteilt" : ""}</td>
                    <td>${escapeHtml(player.name)}${renderTieDecisionBadge(player)}</td>
                    <td>${player.points}</td>
                    <td>${player.setsWon}/${player.setsLost}</td>
                    <td>${player.setDiff}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      `;
    }

    return `
      <table class="stats-table">
        <thead>
          <tr>
            <th>Platz</th>
            <th>Spieler</th>
            <th>Punkte</th>
            <th>Bilanz</th>
            <th>Sätze&nbsp;+</th>
            <th>Sätze&nbsp;−</th>
            <th>Differenz</th>
          </tr>
        </thead>
        <tbody>
          ${ranking
            .map(
              (player) => `
                <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
                  <td>${player.place}${player.sharedPlace ? " geteilt" : ""}</td>
                  <td>${escapeHtml(player.name)}${renderTieDecisionBadge(player)}</td>
                  <td>${player.points}</td>
                  <td>${player.wins}/${player.losses}</td>
                  <td>${player.setsWon}</td>
                  <td>${player.setsLost}</td>
                  <td>${player.setDiff}</td>
                </tr>
              `
            )
            .join("")}
        </tbody>
      </table>
    `;
  }

  function renderTeamRankingTable(playerRanking) {
    if (analysis.teamSummary.hasDoubles && isFixedSetMatchMode(analysis.matchMode)) {
      return `
        <table class="stats-table">
          <thead>
            <tr>
              <th>Platz</th>
              <th>Spieler</th>
              <th>Team</th>
              <th>Spielbilanz</th>
              <th>Einzel</th>
              <th>Doppel</th>
              <th>Satzbilanz</th>
              <th>Differenz</th>
            </tr>
          </thead>
          <tbody>
            ${playerRanking
              .map(
                (player) => `
                  <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
                    <td>${player.place}</td>
                    <td>${escapeHtml(player.name)}</td>
                    <td>${escapeHtml(player.team)}</td>
                    <td>${player.matchesWon}/${player.matchesLost}</td>
                    <td>${player.singlesWon}/${player.singlesLost}</td>
                    <td>${player.doublesWon}/${player.doublesLost}</td>
                    <td>${player.setsWon}/${player.setsLost}</td>
                    <td>${player.setDiff}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      `;
    }

    if (isFixedSetMatchMode(analysis.matchMode)) {
      return `
        <table class="stats-table">
          <thead>
            <tr>
              <th>Platz</th>
              <th>Spieler</th>
              <th>Team</th>
              <th>Satzbilanz</th>
              <th>Differenz</th>
            </tr>
          </thead>
          <tbody>
            ${playerRanking
              .map(
                (player) => `
                  <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
                    <td>${player.place}</td>
                    <td>${escapeHtml(player.name)}</td>
                    <td>${escapeHtml(player.team)}</td>
                    <td>${player.setsWon}/${player.setsLost}</td>
                    <td>${player.setDiff}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      `;
    }

    if (analysis.teamSummary.hasDoubles) {
      return `
        <table class="stats-table">
          <thead>
            <tr>
              <th>Platz</th>
              <th>Spieler</th>
              <th>Team</th>
              <th>Spielbilanz</th>
              <th>Einzel</th>
              <th>Doppel</th>
              <th>Sätze&nbsp;+</th>
              <th>Sätze&nbsp;−</th>
              <th>Differenz</th>
            </tr>
          </thead>
          <tbody>
            ${playerRanking
              .map(
                (player) => `
                  <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
                    <td>${player.place}</td>
                    <td>${escapeHtml(player.name)}</td>
                    <td>${escapeHtml(player.team)}</td>
                    <td>${player.matchesWon}/${player.matchesLost}</td>
                    <td>${player.singlesWon}/${player.singlesLost}</td>
                    <td>${player.doublesWon}/${player.doublesLost}</td>
                    <td>${player.setsWon}</td>
                    <td>${player.setsLost}</td>
                    <td>${player.setDiff}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      `;
    }

    return `
      <table class="stats-table">
        <thead>
          <tr>
            <th>Platz</th>
            <th>Spieler</th>
            <th>Team</th>
            <th>Einzelbilanz</th>
            <th>Sätze&nbsp;+</th>
            <th>Sätze&nbsp;−</th>
            <th>Differenz</th>
          </tr>
        </thead>
        <tbody>
          ${playerRanking
              .map(
                (player) => `
                  <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
                    <td>${player.place}</td>
                    <td>${escapeHtml(player.name)}</td>
                    <td>${escapeHtml(player.team)}</td>
                    <td>${player.matchesWon}/${player.matchesLost}</td>
                    <td>${player.setsWon}</td>
                    <td>${player.setsLost}</td>
                    <td>${player.setDiff}</td>
                  </tr>
                `
            )
            .join("")}
        </tbody>
      </table>
    `;
  }

  function getPlayerStatsFontSizeClass() {
    return `is-font-${playerStatsFontSize}`;
  }

  function applyPlayerStatsFontSizeUI() {
    tournamentSheet.querySelectorAll("[data-font-size-target='playerStats']").forEach((element) => {
      element.classList.remove("is-font-small", "is-font-medium", "is-font-large");
      element.classList.add(getPlayerStatsFontSizeClass());
    });

    const currentIndex = PLAYER_STATS_FONT_SIZES.indexOf(playerStatsFontSize);
    tournamentSheet.querySelectorAll("[data-font-size-step]").forEach((button) => {
      const step = Number(button.dataset.fontSizeStep);
      button.disabled =
        (step < 0 && currentIndex <= 0) ||
        (step > 0 && currentIndex >= PLAYER_STATS_FONT_SIZES.length - 1);
    });
  }

  function renderPlayerMatchName(name, status) {
    const normalizedStatus = PLAYER_STATUSES[status] ? status : "active";
    const statusBadge = normalizedStatus === "active"
      ? ""
      : `<span class="player-status-badge is-${normalizedStatus}">${escapeHtml(getPlayerStatusLabel(normalizedStatus))}</span>`;

    return `<span class="player-name-with-status ${normalizedStatus === "withdrawn" ? "is-withdrawn" : ""}">${escapeHtml(name)}${statusBadge}</span>`;
  }

  function renderMatchResultControls(
    key,
    selectedValue,
    selectedStatus = "normal",
    extraClass = "",
    reverseForDisplay = false,
    resultScope = "",
    isDisabled = false
  ) {
    const normalizedStatus = MATCH_STATUSES[selectedStatus] ? selectedStatus : "normal";
    const statusLabel = getMatchStatusLabel(normalizedStatus);
    // Der gesetzte Sonderstatus steht als stille Marke unter dem Feld; das
    // Auswahlfeld bleibt zugeklappt, sonst deckt es die nächste Zeile zu.
    // B027: eigene Kennung je Klappe — sonst öffnet die Zustandsrettung nach
    // jedem Commit alle, weil jede Summary „!" heißt.
    // B078: tabindex="-1" nimmt den unsichtbaren Auslöser aus der Tab-Kette;
    // ein blindes Enter riss dort sonst acht Klappen auf.
    const anomalyDetails = [
      `<details class="match-anomaly-control ${normalizedStatus !== "normal" ? "is-active" : ""}" data-details-id="anomaly:${escapeHtml(key)}:${escapeHtml(resultScope)}">`,
      '<summary class="match-anomaly-trigger" tabindex="-1" title="Sonderstatus setzen" aria-label="Sonderstatus setzen">!</summary>',
      '<div class="match-anomaly-panel">',
      renderMatchStatusSelect(key, normalizedStatus, reverseForDisplay, resultScope, isDisabled),
      "</div>",
      "</details>"
    ].join("");

    return [
      '<div class="match-result-controls">',
      renderQuickResultField(key, selectedValue, extraClass, reverseForDisplay, resultScope, isDisabled),
      anomalyDetails,
      normalizedStatus !== "normal"
        ? `<span class="match-status-line"><span class="match-status-chip">${escapeHtml(statusLabel)}</span></span>`
        : "",
      "</div>"
    ].join("");
  }

  function renderMatchStatusSelect(
    key,
    selectedStatus = "normal",
    reverseForDisplay = false,
    resultScope = "",
    isDisabled = false
  ) {
    const normalizedStatus = MATCH_STATUSES[selectedStatus] ? selectedStatus : "normal";
    const options = MATCH_STATUS_ORDER.map((statusId) =>
      "<option value=\"" + statusId + "\" " + (normalizedStatus === statusId ? "selected" : "") + ">" + escapeHtml(MATCH_STATUSES[statusId].label) + "<\/option>"
    ).join("");

    return [
      "<select class=\"match-status-select\" data-match-status-key=\"" + key + "\" data-match-status-reverse=\"" + (reverseForDisplay ? "true" : "false") + "\" data-match-status-scope=\"" + resultScope + "\" " + (isDisabled ? "disabled" : "") + ">",
      options,
      "<\/select>"
    ].join("");
  }

  function getSportPreset(presetId) {
    return SPORT_PRESETS.find((preset) => preset.id === presetId) || SPORT_PRESETS[0];
  }

  function getDefaultTournamentName(preset) {
    return `${preset.sport}-Turnier`;
  }

  function createWizardState(presetId = SPORT_PRESETS[0].id) {
    const preset = getSportPreset(presetId);
    return {
      step: 0,
      presetId: preset.id,
      sport: preset.sport,
      tournamentName: getDefaultTournamentName(preset),
      isNameCustom: false,
      format: preset.format,
      playerCount: preset.playerCount,
      playerNames: Array.from({ length: preset.playerCount }, (_, index) => `Spieler ${index + 1}`),
      teamAName: "Team A",
      teamBName: "Team B",
      teamACount: preset.teamACount,
      teamBCount: preset.teamBCount,
      groupCount: 2,
      qualifiersPerGroup: 2,
      placementMatchesEnabled: true,
      matchMode: preset.matchMode
    };
  }

  function applyWizardPreset(presetId) {
    const previousPreset = getSportPreset(tournamentWizardState.presetId);
    const nextPreset = getSportPreset(presetId);
    const shouldReplaceName =
      !tournamentWizardState.isNameCustom ||
      tournamentWizardState.tournamentName === getDefaultTournamentName(previousPreset);

    tournamentWizardState = {
      ...tournamentWizardState,
      presetId: nextPreset.id,
      sport: nextPreset.sport,
      tournamentName: shouldReplaceName
        ? getDefaultTournamentName(nextPreset)
        : tournamentWizardState.tournamentName,
      isNameCustom: shouldReplaceName ? false : tournamentWizardState.isNameCustom,
      format: nextPreset.format,
      playerCount: nextPreset.playerCount,
      playerNames: Array.from({ length: nextPreset.playerCount }, (_, index) => `Spieler ${index + 1}`),
      teamACount: nextPreset.teamACount,
      teamBCount: nextPreset.teamBCount,
      groupCount: 2,
      qualifiersPerGroup: 2,
      placementMatchesEnabled: true,
      matchMode: nextPreset.matchMode
    };
  }

  function handleOpenTournamentWizard() {
    tournamentWizardState = createWizardState();
    renderTournamentWizard();
    tournamentWizardDialog.showModal();
    tournamentWizardContent.querySelector(".wizard-body input, .wizard-body select, .wizard-body button")?.focus();
  }

  function handleTournamentWizardBackdropClick(event) {
    if (event.target === tournamentWizardDialog) {
      tournamentWizardDialog.close();
    }
  }

  function handleTournamentWizardClick(event) {
    const closeButton = event.target.closest("[data-wizard-close]");
    if (closeButton) {
      tournamentWizardDialog.close();
      return;
    }

    const formatButton = event.target.closest("[data-wizard-format]");
    if (formatButton && !formatButton.disabled) {
      const currentDefaultName = tournamentWizardState.format === "ttRace"
        ? BTTV_TT_RACE_NAME
        : getDefaultTournamentName(getSportPreset(tournamentWizardState.presetId));
      const nextFormat = ["team", "groupsKnockout", "ttRace"].includes(formatButton.dataset.wizardFormat)
        ? formatButton.dataset.wizardFormat
        : "roundRobin";
      const shouldReplaceName =
        !tournamentWizardState.isNameCustom || tournamentWizardState.tournamentName === currentDefaultName;

      tournamentWizardState.format = nextFormat;
      if (shouldReplaceName) {
        tournamentWizardState.tournamentName = nextFormat === "ttRace"
          ? BTTV_TT_RACE_NAME
          : getDefaultTournamentName(getSportPreset(tournamentWizardState.presetId));
        tournamentWizardState.isNameCustom = false;
      }
      renderTournamentWizard();
      return;
    }

    const gotoButton = event.target.closest("[data-wizard-goto]");
    if (gotoButton) {
      tournamentWizardState.step = clampPositiveInteger(
        Number(gotoButton.dataset.wizardGoto),
        0,
        TOURNAMENT_WIZARD_STEPS.length - 1
      );
      renderTournamentWizard();
      return;
    }

    const stepButton = event.target.closest("[data-wizard-step-shift]");
    if (stepButton) {
      const shift = Number.parseInt(stepButton.dataset.wizardStepShift, 10);
      tournamentWizardState.step = clampPositiveInteger(
        tournamentWizardState.step + shift,
        0,
        TOURNAMENT_WIZARD_STEPS.length - 1
      );
      renderTournamentWizard();
      return;
    }

    const createButton = event.target.closest("[data-wizard-create]");
    if (createButton) {
      handleCreateTournamentFromWizard();
    }
  }

  function handleTournamentWizardInput(event) {
    const field = event.target.dataset.wizardField;
    if (!field || !tournamentWizardState) {
      return;
    }

    switch (field) {
      case "tournamentName":
        tournamentWizardState.tournamentName = event.target.value;
        tournamentWizardState.isNameCustom = true;
        break;
      case "sportPreset":
        applyWizardPreset(event.target.value);
        renderTournamentWizard();
        break;
      case "playerCount":
        tournamentWizardState.playerCount = tournamentWizardState.format === "groupsKnockout"
          ? clampCount(event.target.value, 4, 100)
          : clampCount(event.target.value);
        if (event.type === "change") {
          clearTimeout(tournamentWizardPlayerCountRenderTimer);
          renderTournamentWizard();
        } else {
          clearTimeout(tournamentWizardPlayerCountRenderTimer);
          tournamentWizardPlayerCountRenderTimer = setTimeout(renderTournamentWizard, 250);
        }
        break;
      case "playerName":
        tournamentWizardState.playerNames[Number(event.target.dataset.index)] = event.target.value;
        break;
      case "teamAName":
        tournamentWizardState.teamAName = event.target.value;
        break;
      case "teamBName":
        tournamentWizardState.teamBName = event.target.value;
        break;
      case "teamACount":
        tournamentWizardState.teamACount = clampCount(event.target.value);
        break;
      case "teamBCount":
        tournamentWizardState.teamBCount = clampCount(event.target.value);
        break;
      case "groupCount":
        tournamentWizardState.groupCount = clampPositiveInteger(event.target.value, 2, 8);
        break;
      case "qualifiersPerGroup":
        tournamentWizardState.qualifiersPerGroup = clampPositiveInteger(event.target.value, 1, 10);
        break;
      case "placementMatchesEnabled":
        tournamentWizardState.placementMatchesEnabled = Boolean(event.target.checked);
        break;
      case "matchMode":
        tournamentWizardState.matchMode = event.target.value;
        break;
      default:
        break;
    }
  }

  /** Jeder Schritt stellt eine Frage; der Kicker zählt die Schritte. */
  const WIZARD_QUESTIONS = ["Welches Format?", "Woher kommen die Teilnehmer?", "Wie wird gespielt?", "Passt das so?"];

  function renderTournamentWizard() {
    const step = tournamentWizardState.step;
    const formatLabel = WIZARD_FORMATS.find((format) => format.id === tournamentWizardState.format)?.label || "";
    const kicker = step > 0 && formatLabel
      ? `Schritt ${step + 1} von ${TOURNAMENT_WIZARD_STEPS.length} · ${formatLabel}`
      : `Schritt ${step + 1} von ${TOURNAMENT_WIZARD_STEPS.length}`;

    tournamentWizardContent.innerHTML = `
      <div class="wizard-header">
        <div>
          <p class="kicker">${escapeHtml(kicker)}</p>
          <h2 id="wizardTitle">${escapeHtml(WIZARD_QUESTIONS[step] || TOURNAMENT_WIZARD_STEPS[step])}</h2>
        </div>
        <button class="wizard-close" type="button" data-wizard-close aria-label="Assistent schließen" title="Schließen">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true" focusable="false">
            <path d="M6 6l12 12" /><path d="M18 6L6 18" />
          </svg>
        </button>
      </div>
      ${renderTournamentWizardProgress(step)}
      <div class="wizard-body">
        ${renderTournamentWizardStep(step)}
      </div>
      ${renderTournamentWizardFooter(step)}
    `;
  }

  function renderTournamentWizardProgress(activeStep) {
    return `
      <ol class="wizard-progress" aria-label="Fortschritt im Assistenten">
        ${TOURNAMENT_WIZARD_STEPS.map(
          (label, index) => `
            <li class="wizard-progress-item ${index <= activeStep ? "is-reached" : ""}">
              ${index + 1} ${escapeHtml(label)}
            </li>
          `
        ).join("")}
      </ol>
    `;
  }

  function renderTournamentWizardStep(step) {
    if (step === 0) {
      return renderTournamentWizardFormatStep();
    }
    if (step === 1) {
      return renderTournamentWizardParticipantsStep();
    }
    if (step === 2) {
      return renderTournamentWizardMatchStep();
    }
    return renderTournamentWizardSummaryStep();
  }

  /** Format als Zeilenliste, darunter der freiwillige Turniername. */
  function renderTournamentWizardFormatStep() {
    return `
      <div class="wizard-format-list">
        ${WIZARD_FORMATS.map(
          (format) => `
            <button
              class="wizard-format-row ${tournamentWizardState.format === format.id ? "is-active" : ""}"
              type="button"
              data-wizard-format="${format.id}"
              ${format.available ? "" : "disabled"}
            >
              <span class="wizard-format-dot" aria-hidden="true"></span>
              <span class="wizard-format-text">
                <span class="wizard-format-title">${escapeHtml(format.label)}</span>
                <span class="wizard-format-description">${escapeHtml(format.description)}</span>
              </span>
              <span class="tag ${
                !format.available ? "tag-plain" : format.official ? "tag-accent" : "tag-neutral"
              }" title="${
                !format.available
                  ? "Dieses Format ist noch nicht gebaut."
                  : format.official
                    ? "Offizielles Verbandsformat mit eigenem Regelwerk."
                    : "Vereinsformat ohne Verbandsvorgaben."
              }">${!format.available ? "noch nicht" : format.official ? "offiziell" : "vereinsintern"}</span>
            </button>
          `
        ).join("")}
      </div>

      <div class="wizard-name-field">
        <label for="wizardTournamentName">Turniername</label>
        <div class="wizard-name-input">
          <input
            id="wizardTournamentName"
            data-wizard-field="tournamentName"
            type="text"
            value="${escapeHtml(tournamentWizardState.tournamentName)}"
            placeholder="z. B. Vereinsabend, Stadtmeisterschaft"
          />
          <p class="wizard-name-note">Wird eine click-TT XML geladen, ersetzt ihr offizieller Name diesen Eintrag.</p>
        </div>
      </div>
    `;
  }

  function renderTournamentWizardParticipantsStep() {
    // Zwei gleichwertige Wege, keiner blockiert das Anlegen.
    if (tournamentWizardState.format === "ttRace") {
      return `
        <div class="wizard-path-list">
          <div class="wizard-path">
            <strong>Aus click-TT übernehmen</strong>
            <span>Namen, IDs, Vereine und TTR-Werte kommen aus der XML. Voraussetzung für den Ergebnis-Export ins Portal.</span>
          </div>
          <div class="wizard-path">
            <strong>Selbst eintragen</strong>
            <span>Teilnehmer im Turnier anlegen. Der Export bleibt dann eine Vorschau.</span>
          </div>
        </div>
        <p class="wizard-name-note">Beides lässt sich nach dem Erstellen im TT-Race wählen.</p>
      `;
    }

    if (tournamentWizardState.format === "team") {
      return `
        <div class="wizard-field-grid two-columns">
          <label>
            <span>Teamname A</span>
            <input data-wizard-field="teamAName" type="text" value="${escapeHtml(tournamentWizardState.teamAName)}" placeholder="Team A" />
          </label>
          <label>
            <span>Teamgröße A</span>
            <input data-wizard-field="teamACount" type="number" min="2" max="100" value="${tournamentWizardState.teamACount}" />
          </label>
          <label>
            <span>Teamname B</span>
            <input data-wizard-field="teamBName" type="text" value="${escapeHtml(tournamentWizardState.teamBName)}" placeholder="Team B" />
          </label>
          <label>
            <span>Teamgröße B</span>
            <input data-wizard-field="teamBCount" type="number" min="2" max="100" value="${tournamentWizardState.teamBCount}" />
          </label>
        </div>
      `;
    }

    if (tournamentWizardState.format === "groupsKnockout") {
      const names = ensureLength(
        tournamentWizardState.playerNames,
        tournamentWizardState.playerCount,
        "Spieler"
      );

      return `
        <div class="wizard-participant-step">
          <div class="wizard-field-grid two-columns">
            <label>
              <span>Anzahl der Teilnehmer</span>
              <input data-wizard-field="playerCount" type="number" min="4" max="100" value="${tournamentWizardState.playerCount}" />
            </label>
            <label>
              <span>Gruppen</span>
              <input data-wizard-field="groupCount" type="number" min="2" max="8" value="${tournamentWizardState.groupCount}" />
            </label>
            <label>
              <span>Qualifikanten je Gruppe</span>
              <input data-wizard-field="qualifiersPerGroup" type="number" min="1" max="10" value="${tournamentWizardState.qualifiersPerGroup}" />
            </label>
            <label class="wizard-checkbox-field">
              <input data-wizard-field="placementMatchesEnabled" type="checkbox" ${tournamentWizardState.placementMatchesEnabled ? "checked" : ""} />
              <span>Spiel um Platz 3</span>
            </label>
          </div>
          ${renderTournamentWizardPlayerNameGrid(names)}
        </div>
      `;
    }

    const names = ensureLength(
      tournamentWizardState.playerNames,
      tournamentWizardState.playerCount,
      "Spieler"
    );

    return `
      <div class="wizard-participant-step">
        <div class="wizard-field-grid">
          <label>
            <span>Anzahl der Teilnehmer</span>
            <input data-wizard-field="playerCount" type="number" min="2" max="100" value="${tournamentWizardState.playerCount}" />
          </label>
        </div>
        ${renderTournamentWizardPlayerNameGrid(names)}
      </div>
    `;
  }

  function renderTournamentWizardPlayerNameGrid(names) {
    return `
      <section class="wizard-player-names">
        <div class="section-heading compact">
          <div>
            <h3>Teilnehmer</h3>
            <p>Du kannst die Namen jetzt eintragen oder später unter „Teilnehmer“ ergänzen.</p>
          </div>
        </div>
        <div class="wizard-player-name-grid">
          ${names
            .map(
              (name, index) => `
                <label>
                  <span>Teilnehmer ${index + 1}</span>
                  <input data-wizard-field="playerName" data-index="${index}" type="text" value="${escapeHtml(name)}" placeholder="Spieler ${index + 1}" />
                </label>
              `
            )
            .join("")}
        </div>
      </section>
    `;
  }

  function renderTournamentWizardMatchStep() {
    if (tournamentWizardState.format === "ttRace") {
      return `
        <div class="wizard-info-panel">
          <strong>BTTV Bavarian TT-Race</strong>
          <span>Voreingestellt sind 3 Gewinnsätze, TTR-Auslosung, 6 Schweizer Runden und 9 bis 16 aktive Teilnehmer.</span>
        </div>
      `;
    }

    return `
      <div class="wizard-field-grid">
        <label>
          <span>Satz-/Matchmodus</span>
          <select data-wizard-field="matchMode">
            ${MATCH_MODE_ORDER.map(
              (modeId) => `
                <option value="${modeId}" ${tournamentWizardState.matchMode === modeId ? "selected" : ""}>
                  ${escapeHtml(MATCH_MODES[modeId].label)}
                </option>
              `
            ).join("")}
          </select>
        </label>
      </div>
    `;
  }

  /** Zeilen mit ändern-Link je Angabe; feste Werte tragen keinen Link. */
  function renderTournamentWizardSummaryStep() {
    return `
      <div class="wizard-summary">
        ${getTournamentWizardSummary()
          .map(
            (entry) => `
              <div class="wizard-summary-row">
                <span class="wizard-summary-label">${escapeHtml(entry.label)}</span>
                <span class="wizard-summary-value">
                  ${escapeHtml(entry.value)}
                  ${entry.note ? `<span class="wizard-summary-note">${escapeHtml(entry.note)}</span>` : ""}
                </span>
                ${
                  Number.isInteger(entry.step)
                    ? `<button class="link-button wizard-summary-change" type="button" data-wizard-goto="${entry.step}">ändern</button>`
                    : '<span class="wizard-summary-fixed">fest</span>'
                }
              </div>
            `
          )
          .join("")}
      </div>
    `;
  }

  function renderTournamentWizardFooter(step) {
    const isLastStep = step === TOURNAMENT_WIZARD_STEPS.length - 1;
    return `
      <div class="wizard-footer">
        <button class="link-button" type="button" data-wizard-close>Abbrechen</button>
        <div class="wizard-footer-actions">
          ${step === 0 ? "" : '<button class="secondary-button" type="button" data-wizard-step-shift="-1">Zurück</button>'}
          ${
            isLastStep
              ? `<button class="primary-button" type="button" data-wizard-create>Turnier erstellen</button>`
              : `<button class="primary-button" type="button" data-wizard-step-shift="1">Weiter</button>`
          }
        </div>
      </div>
    `;
  }

  function getTournamentWizardSummary() {
    const formatLabel = WIZARD_FORMATS.find((format) => format.id === tournamentWizardState.format)?.label || "Jeder-gegen-jeden";
    const namedParticipants = getWizardNamedParticipantCount();
    const participantLabel =
      tournamentWizardState.format === "team"
        ? `${tournamentWizardState.teamAName || "Team A"} (${tournamentWizardState.teamACount}) gegen ${tournamentWizardState.teamBName || "Team B"} (${tournamentWizardState.teamBCount})`
        : tournamentWizardState.format === "ttRace"
          ? "Import aus click-TT XML"
          : tournamentWizardState.format === "groupsKnockout"
            ? `${tournamentWizardState.playerCount} Teilnehmer, ${namedParticipants} benannt, ${tournamentWizardState.groupCount} Gruppen, ${tournamentWizardState.qualifiersPerGroup} weiter`
            : `${tournamentWizardState.playerCount} Teilnehmer, ${namedParticipants} benannt`;
    const matchModeLabel = tournamentWizardState.format === "ttRace"
      ? "3 Gewinnsätze, TTR-Auslosung, 6 Runden"
      : MATCH_MODES[tournamentWizardState.matchMode].label;

    const isRace = tournamentWizardState.format === "ttRace";

    return [
      { label: "Format", value: formatLabel, step: 0 },
      { label: "Name", value: getWizardTournamentName(), step: 0 },
      { label: "Teilnehmer", value: participantLabel, step: 1 },
      { label: "Spielmodus", value: matchModeLabel, step: isRace ? null : 2 }
    ];
  }

  function getWizardNamedParticipantCount() {
    return ensureLength(tournamentWizardState.playerNames, tournamentWizardState.playerCount, "Spieler")
      .filter((name, index) => name.trim() && name.trim() !== `Spieler ${index + 1}`)
      .length;
  }

  function getWizardTournamentName() {
    const fallbackPreset = getSportPreset(tournamentWizardState.presetId);
    return tournamentWizardState.tournamentName.trim() || getDefaultTournamentName(fallbackPreset);
  }

  function buildTournamentStateFromWizard() {
    if (tournamentWizardState.format === "ttRace") {
      return createBttvTtRaceStarterState(getWizardTournamentName());
    }

    const mode = ["team", "groupsKnockout"].includes(tournamentWizardState.format)
      ? tournamentWizardState.format
      : "roundRobin";
    const state = createStateForMode(mode);
    const tournamentName = getWizardTournamentName();

    state.tabName = tournamentName;
    state.tournamentName = tournamentName;
    state.matchMode = MATCH_MODES[tournamentWizardState.matchMode]
      ? tournamentWizardState.matchMode
      : getSportPreset(tournamentWizardState.presetId).matchMode;

    if (mode === "team") {
      const teamACount = clampCount(tournamentWizardState.teamACount);
      const teamBCount = clampCount(tournamentWizardState.teamBCount);
      state.team.teamAName = tournamentWizardState.teamAName.trim() || "Team A";
      state.team.teamBName = tournamentWizardState.teamBName.trim() || "Team B";
      state.team.teamACount = teamACount;
      state.team.teamBCount = teamBCount;
      state.team.teamAPlayers = ensureLength([], teamACount, "Spieler A");
      state.team.teamBPlayers = ensureLength([], teamBCount, "Spieler B");
      state.team.currentRound = 1;
      return state;
    }

    if (mode === "groupsKnockout") {
      const playerCount = clampCount(tournamentWizardState.playerCount, 4, 100);
      state.groupsKnockout.playerCount = playerCount;
      state.groupsKnockout.groupCount = clampPositiveInteger(tournamentWizardState.groupCount, 2, 8);
      state.groupsKnockout.qualifiersPerGroup = clampPositiveInteger(tournamentWizardState.qualifiersPerGroup, 1, 10);
      state.groupsKnockout.placementMatchesEnabled = Boolean(tournamentWizardState.placementMatchesEnabled);
      state.groupsKnockout.playerNames = ensureLength(tournamentWizardState.playerNames, playerCount, "Spieler");
      state.groupsKnockout.currentGroupRound = 1;
      state.groupsKnockout.currentKnockoutRound = 1;
      return state;
    }

    const playerCount = clampCount(tournamentWizardState.playerCount);
    state.roundRobin.playerCount = playerCount;
    state.roundRobin.playerNames = ensureLength(tournamentWizardState.playerNames, playerCount, "Spieler");
    state.roundRobin.currentRound = 1;
    return state;
  }

  function handleCreateTournamentFromWizard() {
    const tournamentState = buildTournamentStateFromWizard();
    const selectedMode = tournamentState.mode;
    const isRace = Boolean(tournamentState.ttRace);
    activeWorkspaceView = "input";
    saveWorkspaceView();

    updateWorkspace((draft) => {
      const tournament = createTournamentRecord(tournamentState);
      draft.tournaments.push(tournament);
      draft.activeTournamentId = tournament.id;
    }, "Tischtennis-Turnier über Assistent angelegt");

    tournamentWizardDialog.close();
    showInfo(
      isRace
        ? `${getWizardTournamentName()} wurde angelegt. Importiere jetzt die click-TT Teilnehmer-XML.`
        : `${getWizardTournamentName()} wurde als Tischtennis-${MODES[selectedMode].label} angelegt.`
    );
  }

  function handleAddTournamentTab(modeId) {
    if (modeId === "ttRace") {
      activeWorkspaceView = "input";
      saveWorkspaceView();
      updateWorkspace((draft) => {
        const tournament = createTournamentRecord(createBttvTtRaceStarterState());
        draft.tournaments.push(tournament);
        draft.activeTournamentId = tournament.id;
      }, "Neues BTTV TT-Race angelegt");
      showInfo(`${BTTV_TT_RACE_NAME} wurde angelegt. Importiere jetzt die click-TT Teilnehmer-XML.`);
      return;
    }

    const selectedMode = ["team", "groupsKnockout"].includes(modeId) ? modeId : "roundRobin";
    updateWorkspace((draft) => {
      const tournament = createTournamentRecord(createStateForMode(selectedMode));
      draft.tournaments.push(tournament);
      draft.activeTournamentId = tournament.id;
    }, "Neues Turnier angelegt");
    showInfo(`Ein neues Turnier im Format ${MODES[selectedMode].label} wurde angelegt.`);
  }

  function buildCopyLabel(label) {
    return `${label} Kopie`;
  }

  function handleDuplicateTournament() {
    const currentLabel = getTournamentLabel(activeTournament, getActiveTournamentIndex());
    duplicateTournamentText.textContent = `${currentLabel} als neues Turnier anlegen?`;
    duplicateTournamentDialog.showModal();
  }

  function handleDuplicateTournamentDialogClick(event) {
    if (event.target === duplicateTournamentDialog || event.target.closest("[data-duplicate-cancel]")) {
      duplicateTournamentDialog.close();
      return;
    }

    const choiceButton = event.target.closest("[data-duplicate-choice]");
    if (!choiceButton) {
      return;
    }

    duplicateActiveTournament(choiceButton.dataset.duplicateChoice === "with-results");
    duplicateTournamentDialog.close();
  }

  function duplicateActiveTournament(includeResults) {
    const currentLabel = getTournamentLabel(activeTournament, getActiveTournamentIndex());
    const duplicateState = createReusableTournamentState(activeTournament, includeResults);
    const duplicateLabel = buildCopyLabel(currentLabel);
    duplicateState.tabName = duplicateLabel;
    duplicateState.tournamentName = duplicateLabel;

    updateWorkspace((draft) => {
      const duplicate = createTournamentFromReusableState(duplicateState);
      draft.tournaments.push(duplicate);
      draft.activeTournamentId = duplicate.id;
    }, includeResults ? "Turnier mit Ergebnissen dupliziert" : "Turnier ohne Ergebnisse dupliziert");

    showInfo(
      includeResults
        ? `${currentLabel} wurde inklusive Ergebnissen dupliziert.`
        : `${currentLabel} wurde ohne Ergebnisse dupliziert.`
    );
  }

  function handleSaveTemplate() {
    const currentLabel = getTournamentLabel(activeTournament, getActiveTournamentIndex());
    const suggestedName = activeTournament.tabName || activeTournament.tournamentName || currentLabel;
    const templateName = window.prompt("Name für die Vorlage:", suggestedName);

    if (templateName === null) {
      return;
    }

    const trimmedName = templateName.trim();
    if (!trimmedName) {
      showInfo("Die Vorlage braucht einen Namen.");
      return;
    }

    const includeResults = Boolean(templateIncludeResults.checked);
    const now = new Date().toISOString();
    const existingTemplate = tournamentTemplates.find(
      (template) => template.name.toLocaleLowerCase("de-DE") === trimmedName.toLocaleLowerCase("de-DE")
    );
    const nextTemplate = {
      id: existingTemplate?.id || createTemplateId(),
      name: trimmedName,
      createdAt: existingTemplate?.createdAt || now,
      updatedAt: now,
      includeResults,
      state: createReusableTournamentState(activeTournament, includeResults)
    };

    if (existingTemplate) {
      const shouldReplace = window.confirm(
        `Die Vorlage „${trimmedName}“ existiert bereits. Überschreiben?`
      );

      if (!shouldReplace) {
        showInfo("Vorlage wurde nicht geändert.");
        return;
      }

      tournamentTemplates = tournamentTemplates.map((template) =>
        template.id === existingTemplate.id ? nextTemplate : template
      );
    } else {
      tournamentTemplates = [...tournamentTemplates, nextTemplate];
    }

    if (saveTournamentTemplates()) {
      renderTemplateControls();
      templateSelect.value = nextTemplate.id;
      showInfo(
        includeResults
          ? `Vorlage „${trimmedName}“ wurde mit Ergebnissen gespeichert.`
          : `Vorlage „${trimmedName}“ wurde ohne Ergebnisse gespeichert.`
      );
    }
  }

  function handleLoadTemplate() {
    const template = getSelectedTemplate();
    if (!template) {
      showInfo("Bitte zuerst eine Vorlage auswählen.");
      return;
    }

    const templateState = createReusableTournamentState(template.state, template.includeResults);
    templateState.tabName = template.name;
    if (!templateState.tournamentName) {
      templateState.tournamentName = template.name;
    }

    updateWorkspace((draft) => {
      const tournament = createTournamentFromReusableState(templateState);
      draft.tournaments.push(tournament);
      draft.activeTournamentId = tournament.id;
    }, "Vorlage als neues Turnier geladen");

    showInfo(
      template.includeResults
        ? `Vorlage „${template.name}“ wurde inklusive Ergebnissen als neues Turnier geladen.`
        : `Vorlage „${template.name}“ wurde ohne Ergebnisse als neues Turnier geladen.`
    );
  }

  function handleDeleteTemplate() {
    const template = getSelectedTemplate();
    if (!template) {
      showInfo("Bitte zuerst eine Vorlage auswählen.");
      return;
    }

    const shouldDelete = window.confirm(
      `Vorlage „${template.name}“ wirklich löschen?\n\nGeöffnete Turniere bleiben unverändert.`
    );

    if (!shouldDelete) {
      showInfo("Vorlage wurde nicht gelöscht.");
      return;
    }

    tournamentTemplates = tournamentTemplates.filter((entry) => entry.id !== template.id);

    if (saveTournamentTemplates()) {
      renderTemplateControls();
      showInfo(`Vorlage „${template.name}“ wurde gelöscht.`);
    }
  }

  function handleRenameTournamentTab(tournamentId) {
    const tournament = workspace.tournaments.find((entry) => entry.id === tournamentId);
    if (!tournament) {
      return;
    }

    const suggestedName = tournament.tabName || tournament.tournamentName || "";
    const nextName = window.prompt("Neuen Namen für dieses Turnier eingeben:", suggestedName);

    if (nextName === null) {
      return;
    }

    updateTournamentById(tournamentId, (draftTournament) => {
      const linkedName = nextName.trim();
      draftTournament.tabName = linkedName;
      draftTournament.tournamentName = linkedName;
    }, "Turniername aktualisiert");
  }

  function persistTournamentTabOrder(orderedTournamentIds) {
    if (!Array.isArray(orderedTournamentIds) || orderedTournamentIds.length !== workspace.tournaments.length) {
      return;
    }

    const currentOrder = workspace.tournaments.map((entry) => entry.id);
    if (JSON.stringify(currentOrder) === JSON.stringify(orderedTournamentIds)) {
      return;
    }

    updateWorkspace((draft) => {
      const rankById = new Map(orderedTournamentIds.map((id, index) => [id, index]));
      draft.tournaments.sort((left, right) => rankById.get(left.id) - rankById.get(right.id));
    }, "Turniere neu angeordnet");
  }

  function handleTournamentTabPointerDown(event) {
    if (event.button !== 0) {
      return;
    }

    const tournamentId = event.currentTarget.dataset.tabDrag;
    if (!tournamentId) {
      return;
    }

    const draggedShell = tabsElement.querySelector(`[data-tab-shell="${tournamentId}"]`);
    if (!draggedShell) {
      return;
    }

    event.preventDefault();

    const shellBounds = draggedShell.getBoundingClientRect();
    const placeholder = createTournamentTabPlaceholder(draggedShell, shellBounds);
    draggedShell.parentNode.insertBefore(placeholder, draggedShell);
    document.body.appendChild(draggedShell);

    draggedShell.classList.add("is-dragging");
    draggedShell.style.width = `${shellBounds.width}px`;
    draggedShell.style.height = `${shellBounds.height}px`;
    draggedShell.style.left = `${shellBounds.left}px`;
    draggedShell.style.top = `${shellBounds.top}px`;

    draggedTournamentState = {
      tournamentId,
      draggedShell,
      placeholder,
      offsetX: event.clientX - shellBounds.left,
      top: shellBounds.top,
      pointerId: event.pointerId
    };

    updateDraggedTournamentPosition(event.clientX);
    window.addEventListener("pointermove", handleTournamentTabPointerMove);
    window.addEventListener("pointerup", handleTournamentTabPointerUp);
    window.addEventListener("pointercancel", handleTournamentTabPointerUp);
  }

  function handleTournamentTabPointerMove(event) {
    if (!draggedTournamentState || event.pointerId !== draggedTournamentState.pointerId) {
      return;
    }

    autoScrollTournamentTabs(event.clientX);
    updateDraggedTournamentPosition(event.clientX);
    previewTournamentTabPlaceholder(event.clientX);
  }

  function handleTournamentTabPointerUp(event) {
    if (!draggedTournamentState || event.pointerId !== draggedTournamentState.pointerId) {
      return;
    }

    finishTournamentTabDrag();
  }

  function finishTournamentTabDrag() {
    if (!draggedTournamentState) {
      return;
    }

    const { draggedShell, placeholder } = draggedTournamentState;
    const nextOrder = getRenderedTournamentTabOrder();

    placeholder.parentNode.insertBefore(draggedShell, placeholder);
    restoreDraggedTournamentShell(draggedShell);
    placeholder.remove();

    draggedTournamentState = null;
    window.removeEventListener("pointermove", handleTournamentTabPointerMove);
    window.removeEventListener("pointerup", handleTournamentTabPointerUp);
    window.removeEventListener("pointercancel", handleTournamentTabPointerUp);

    persistTournamentTabOrder(nextOrder);
    renderTabs();
  }

  function createTournamentTabPlaceholder(draggedShell, shellBounds) {
    const placeholder = document.createElement("div");
    placeholder.className = `tab-chip-shell tab-chip-placeholder ${draggedShell.classList.contains("is-active") ? "is-active" : ""}`;
    placeholder.dataset.tabPlaceholder = draggedShell.dataset.tabShell;
    placeholder.innerHTML = `<div class="tab-chip tab-chip-placeholder-card" aria-hidden="true"></div>`;
    placeholder.style.width = `${shellBounds.width}px`;
    placeholder.style.height = `${shellBounds.height}px`;
    return placeholder;
  }

  function restoreDraggedTournamentShell(draggedShell) {
    draggedShell.classList.remove("is-dragging");
    draggedShell.style.width = "";
    draggedShell.style.height = "";
    draggedShell.style.left = "";
    draggedShell.style.top = "";
  }

  function updateDraggedTournamentPosition(pointerX) {
    if (!draggedTournamentState) {
      return;
    }

    const { draggedShell, offsetX, top } = draggedTournamentState;
    draggedShell.style.left = `${pointerX - offsetX}px`;
    draggedShell.style.top = `${top}px`;
  }

  function previewTournamentTabPlaceholder(pointerX) {
    if (!draggedTournamentState) {
      return;
    }

    const { placeholder } = draggedTournamentState;
    const tabShells = [...tabsElement.querySelectorAll("[data-tab-shell]")];
    const referenceNode = tabShells.find((shell) => {
      const bounds = shell.getBoundingClientRect();
      return pointerX < bounds.left + bounds.width / 2;
    }) || null;

    if (
      (referenceNode && placeholder.nextElementSibling === referenceNode) ||
      (!referenceNode && placeholder === tabsElement.lastElementChild)
    ) {
      return;
    }

    const previousPositions = captureTournamentTabPositions();
    tabsElement.insertBefore(placeholder, referenceNode);
    animateTournamentTabPositions(previousPositions);
  }

  function captureTournamentTabPositions() {
    const positions = new Map();
    tabsElement.querySelectorAll("[data-tab-shell], [data-tab-placeholder]").forEach((shell) => {
      positions.set(shell.dataset.tabShell || shell.dataset.tabPlaceholder, shell.getBoundingClientRect().left);
    });
    return positions;
  }

  function animateTournamentTabPositions(previousPositions) {
    tabsElement.querySelectorAll("[data-tab-shell], [data-tab-placeholder]").forEach((shell) => {
      const shellId = shell.dataset.tabShell || shell.dataset.tabPlaceholder;
      const previousLeft = previousPositions.get(shellId);
      if (previousLeft === undefined) {
        return;
      }

      const deltaX = previousLeft - shell.getBoundingClientRect().left;
      if (Math.abs(deltaX) < 1) {
        return;
      }

      shell.animate(
        [
          { transform: `translateX(${deltaX}px) scale(0.985)` },
          { transform: "translateX(0) scale(1)" }
        ],
        {
          duration: 260,
          easing: "cubic-bezier(0.22, 1, 0.36, 1)"
        }
      );
    });
  }

  function getRenderedTournamentTabOrder() {
    if (draggedTournamentState) {
      return [...tabsElement.children].map((shell) =>
        shell.dataset.tabShell || shell.dataset.tabPlaceholder
      );
    }

    return [...tabsElement.querySelectorAll("[data-tab-shell]")].map((shell) => shell.dataset.tabShell);
  }

  function autoScrollTournamentTabs(pointerX) {
    const bounds = tabsElement.getBoundingClientRect();
    const edgeThreshold = 72;

    if (pointerX < bounds.left + edgeThreshold) {
      tabsElement.scrollLeft -= Math.ceil((bounds.left + edgeThreshold - pointerX) / 8);
      return;
    }

    if (pointerX > bounds.right - edgeThreshold) {
      tabsElement.scrollLeft += Math.ceil((pointerX - (bounds.right - edgeThreshold)) / 8);
    }
  }

  function handleDeleteTournamentTab(tournamentId) {
    const tournamentIndex = workspace.tournaments.findIndex((entry) => entry.id === tournamentId);
    const tournament = workspace.tournaments[tournamentIndex];
    if (!tournament) {
      return;
    }

    if (workspace.tournaments.length <= 1) {
      showInfo("Das letzte Turnier bleibt bestehen und kann nicht gelöscht werden.");
      return;
    }

    const currentLabel = getTournamentLabel(tournament, tournamentIndex);
    const shouldDelete = window.confirm(
      `${currentLabel} wirklich löschen?\n\n` +
        "Das entfernt dieses Turnier inklusive seiner gespeicherten Daten."
    );

    if (!shouldDelete) {
      showInfo("Das Turnier wurde nicht gelöscht.");
      return;
    }

    updateWorkspace((draft) => {
      const index = draft.tournaments.findIndex((entry) => entry.id === tournamentId);
      if (index === -1) {
        return;
      }

      const wasActive = draft.activeTournamentId === tournamentId;
      draft.tournaments.splice(index, 1);

      if (wasActive) {
        const fallbackTournament = draft.tournaments[Math.max(0, index - 1)] || draft.tournaments[0];
        draft.activeTournamentId = fallbackTournament.id;
      }
    }, "Turnier gelöscht");

    showInfo(`${currentLabel} wurde entfernt.`);
  }

  function handleClearCurrentTournament() {
    const currentLabel = getTournamentLabel(activeTournament, getActiveTournamentIndex());
    const shouldClear = window.confirm(
      `${currentLabel} wirklich komplett leeren?\n\n` +
        "Dabei werden Turniername, Spieler und alle Ergebnisse im laufenden Turnier zurückgesetzt."
    );

    if (!shouldClear) {
      return;
    }

    updateActiveTournament((tournament) => {
      const id = tournament.id;
      const freshTournament = createTournamentRecord(createStateForMode(tournament.mode), id);
      Object.keys(tournament).forEach((key) => {
        delete tournament[key];
      });
      Object.assign(tournament, freshTournament);
    }, "Aktives Turnier geleert");
    showInfo(`${currentLabel} wurde geleert. Das Turnier bleibt in der Liste, damit du es neu verwenden kannst.`);
  }

  function handleResetResults() {
    const currentLabel = getTournamentLabel(activeTournament, getActiveTournamentIndex());
    const shouldReset = window.confirm(
      `${currentLabel}: nur die Ergebnisse leeren?\n\n` +
        "Spieler, Teamnamen und Turniername bleiben erhalten."
    );

    if (!shouldReset) {
      return;
    }

    updateActiveTournament((tournament) => {
      if (tournament.mode === "team") {
        tournament.team.results = {};
        tournament.team.setScores = {};
        tournament.team.matchStatuses = {};
        tournament.team.doubleResults = {};
        tournament.team.doubleSetScores = {};
        tournament.team.doubleMatchStatuses = {};
      } else if (tournament.mode === "groupsKnockout") {
        tournament.groupsKnockout.groupResults = {};
        tournament.groupsKnockout.groupSetScores = {};
        tournament.groupsKnockout.knockoutResults = {};
        tournament.groupsKnockout.knockoutSetScores = {};
      } else {
        tournament.roundRobin.results = {};
        tournament.roundRobin.setScores = {};
        tournament.roundRobin.matchStatuses = {};
      }
      if (tournament.ttRace) {
        tournament.ttRace.rounds = [];
      }
      if (tournament.clicktt?.setScores) {
        tournament.clicktt.setScores = {};
      }
    }, "Ergebnisse gelöscht");
    showInfo("Alle eingetragenen Ergebnisse des aktiven Turniers wurden entfernt. Die Konfiguration bleibt erhalten.");
  }

  function handleDrawAction(event) {
    const action = event.currentTarget.dataset.drawAction;

    if (action === "shuffle-round-robin") {
      handleShuffleRoundRobinDraw();
      return;
    }

    if (action === "shuffle-groups-knockout") {
      handleShuffleGroupsKnockoutDraw();
    }
  }

  function handleShuffleRoundRobinDraw() {
    if (hasRoundRobinDrawStarted(activeTournament)) {
      showInfo("Jeder-gegen-jeden kann nur vor dem ersten eingetragenen Ergebnis neu ausgelost werden.");
      return;
    }

    updateActiveTournament((tournament) => {
      tournament.roundRobin = shuffleRoundRobinDraw(tournament.roundRobin);
    }, "Jeder-gegen-jeden neu ausgelost");
    showInfo("Teilnehmer wurden zufällig neu ausgelost. Der Rundenplan wurde entsprechend aktualisiert.");
  }

  function handleShuffleGroupsKnockoutDraw() {
    if (hasGroupsKnockoutDrawStarted(activeTournament)) {
      showInfo("Gruppen + KO kann nur vor dem ersten eingetragenen Gruppenergebnis neu ausgelost werden.");
      return;
    }

    updateActiveTournament((tournament) => {
      tournament.groupsKnockout = shuffleGroupsKnockoutDraw(tournament.groupsKnockout);
    }, "Gruppen + KO neu ausgelost");
    showInfo("Teilnehmer wurden zufällig neu ausgelost und neu auf die Gruppen verteilt.");
  }

  function handleLoadExample() {
    const currentLabel = getTournamentLabel(activeTournament, getActiveTournamentIndex());
    const shouldLoadExample = window.confirm(
      `${currentLabel} mit Beispieldaten fuellen?\n\n` +
        "Die aktuellen Daten in diesem Turnier werden dabei überschrieben.\n\n" +
        'Falls du fortfahren möchtest, kannst du die letzte Änderung danach mit "Zurück" wiederherstellen.'
    );

    if (!shouldLoadExample) {
      return;
    }

    const exampleState =
      activeTournament.mode === "team"
        ? exampleTeamState
        : activeTournament.mode === "groupsKnockout"
          ? exampleGroupsKnockoutState
          : exampleRoundRobinState;
    updateActiveTournament((tournament) => {
      const exampleCopy = createTournamentRecord(cloneValue(exampleState), tournament.id);
      Object.keys(tournament).forEach((key) => {
        delete tournament[key];
      });
      Object.assign(tournament, exampleCopy);
    }, "Beispieldaten geladen");
  }

  async function handleClickTtFileSelection(event) {
    const file = event.target.files?.[0];
    clickTtFileInput.value = "";

    if (!file) {
      return;
    }

    try {
      const text = await file.text();
      const bridge = await loadClickTtBridge();
      const imported = bridge.createTournamentStateFromClickttXml(text, {
        sourceFileName: file.name,
        importedAt: new Date().toISOString()
      });
      const starterOnlyImport = shouldUseClickTtStarterOnlyImport(imported.state);

      if (starterOnlyImport) {
        stripImportedResultsForStarterRun(imported.state);
      }

      const shouldImport = window.confirm(
        `${file.name} importieren?\n\n` +
          `${imported.state.roundRobin.playerCount} Teilnehmer aus „${imported.state.clicktt.competitionLabel}“ werden in das laufende Turnier übernommen.` +
          (starterOnlyImport
            ? "\n\nDie XML enthält bereits Ergebnisse. Für diesen leeren TT-Race-Probelauf werden nur Teilnehmer, IDs, Vereine und TTR übernommen."
            : "")
      );

      if (!shouldImport) {
        showInfo("click-TT Import wurde abgebrochen.");
        return;
      }

      const engine = await loadTtRaceEngine();
      imported.state.ttRace = engine.normalizeTtRaceTournament(imported.state.ttRace);
      clickTtImportDraft = null;
      updateActiveTournament((tournament) => {
        const importedRecord = createTournamentRecord(imported.state, tournament.id);
        Object.keys(tournament).forEach((key) => {
          delete tournament[key];
        });
        Object.assign(tournament, importedRecord);
      }, "click-TT XML importiert");
      showInfo(
        starterOnlyImport
          ? `${file.name} als Startliste importiert: ${imported.state.roundRobin.playerCount} Teilnehmer, keine alten Runden.`
          : `${file.name} importiert: ${imported.state.roundRobin.playerCount} Teilnehmer, click-TT IDs und TT-Race Engine sind verbunden.`
      );
    } catch (error) {
      console.error("click-TT XML konnte nicht gelesen werden.", error);
      showInfo(`Die click-TT XML-Datei konnte nicht importiert werden: ${error.message || "unbekannter Fehler"}`);
    }
  }

  function shouldUseClickTtStarterOnlyImport(importedState) {
    const isEmptyRaceStarter =
      isTtRaceTournament() &&
      (activeTournament.ttRace?.players ?? []).length === 0 &&
      (activeTournament.ttRace?.rounds ?? []).length === 0;
    const importedRoundCount = importedState?.ttRace?.rounds?.length ?? 0;
    const importedMatchCount = importedState?.clicktt?.importedMatchCount ?? 0;

    return isEmptyRaceStarter && (importedRoundCount > 0 || importedMatchCount > 0);
  }

  function stripImportedResultsForStarterRun(importedState) {
    importedState.roundRobin.results = {};
    importedState.roundRobin.setScores = {};
    importedState.roundRobin.matchStatuses = {};
    importedState.roundRobin.currentRound = 1;
    importedState.roundRobin.playerStatuses = Array.from(
      { length: importedState.roundRobin.playerCount },
      () => "active"
    );
    importedState.clicktt.importedMatchCount = 0;
    importedState.clicktt.importedPlayers = (importedState.clicktt.importedPlayers ?? []).map((player) => ({
      ...player,
      seed: null,
      placement: null,
      status: "active"
    }));
    importedState.ttRace.players = (importedState.ttRace.players ?? []).map((player) => ({
      ...player,
      seed: null,
      placement: null,
      status: "active"
    }));
    importedState.ttRace.rounds = [];
    importedState.ttRace.standings = [];
  }

  function handleRaceDayShellClick(event) {
    const tieButton = event.target.closest("[data-tie-decide]");
    if (tieButton && raceDayShell.contains(tieButton)) {
      handleTieDecideClick(tieButton.dataset.tieDecide);
      return;
    }

    const roundShiftButton = event.target.closest("[data-round-shift]");
    if (roundShiftButton && raceDayShell.contains(roundShiftButton)) {
      handleRoundShift({ currentTarget: roundShiftButton });
      return;
    }

    const actionButton = event.target.closest("[data-race-action]");
    if (!actionButton || !raceDayShell.contains(actionButton)) {
      return;
    }

    handleRaceAction(actionButton);
  }

  function handleRaceAction(actionButton) {
    const action = actionButton.dataset.raceAction;
    if (action === "choose-clicktt-file") {
      clickTtFileInput.click();
      return;
    }

    if (action === "load-race-demo") {
      handleLoadRaceDayDemo();
      return;
    }

    if (action === "generate-swiss-round") {
      handleGenerateSwissRound();
      return;
    }

    if (action === "redraw-initial-round") {
      handleRedrawInitialSwissRound();
      return;
    }

    if (action === "add-tt-race-player") {
      handleAddTtRacePlayer();
      return;
    }

    if (action === "remove-tt-race-player") {
      ttRaceEditingPlayerId = null;
      handleRemoveTtRacePlayer(actionButton.dataset.playerId);
      return;
    }

    // Bearbeitet wird immer nur die angeklickte Zeile.
    if (action === "edit-tt-race-player") {
      const playerId = actionButton.dataset.playerId;
      ttRaceEditingPlayerId = ttRaceEditingPlayerId === playerId ? null : playerId;
      renderRaceDayShell();
      return;
    }

    if (action === "apply-tt-race-player") {
      ttRaceEditingPlayerId = null;
      renderRaceDayShell();
      return;
    }

    if (action === "open-output") {
      activeWorkspaceView = "output";
      saveWorkspaceView();
      renderWorkspacePanels();
      return;
    }

    if (action === "open-setup") {
      activeWorkspaceView = "input";
      saveWorkspaceView();
      renderWorkspacePanels();
      document.querySelector("#config-heading")?.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }

    if (action === "copy-clicktt-xml") {
      handleCopyClickTtXml();
      return;
    }

    if (action === "download-clicktt-xml") {
      handleDownloadClickTtXml();
    }
  }

  function handleRaceDayShellChange(event) {
    if (
      event.target.matches("[data-tt-race-player-name]") ||
      event.target.matches("[data-tt-race-player-first]") ||
      event.target.matches("[data-tt-race-player-last]") ||
      event.target.matches("[data-tt-race-player-rating]") ||
      event.target.matches("[data-tt-race-player-status]")
    ) {
      handleTtRacePlayerFieldChange(event);
      return;
    }

    if (event.target.matches("[data-race-setting]")) {
      handleRaceSettingChange(event);
      return;
    }

    if (event.target.matches("[data-clicktt-set-key]")) {
      handleClickTtSetScoreChange(event);
      return;
    }

    if (event.target.matches("[data-tt-race-sets]")) {
      handleTtRaceSetScoreChange(event);
      return;
    }

    if (event.target.matches("[data-result-key]")) {
      handleResultChange(event);
      return;
    }

    if (event.target.matches("[data-match-status-key]")) {
      handleMatchStatusChange(event);
      return;
    }

    if (event.target.matches("[data-sheet-action]")) {
      handleSheetInput(event);
    }
  }

	  function handleRaceSettingChange(event) {
	    const setting = event.target.dataset.raceSetting;

    if (setting !== "regardTtrValues") {
      return;
    }
	
	    if ((activeTournament.ttRace?.rounds?.length ?? 0) > 0) {
	      event.target.checked = getTtRaceRegardTtrValues();
	      showInfo("TTR-Auslosung kann nach erzeugter erster Runde nicht mehr geändert werden.");
	      return;
	    }
	
	    const enabled = Boolean(event.target.checked);
    updateActiveTournament((tournament) => {
      const ttRaceSeed = isTtRaceTournament(tournament)
        ? tournament.ttRace
        : createTtRaceSeedFromActiveTournament(tournament);

      tournament.ttRace = {
        ...ttRaceSeed,
        settings: {
          maxRounds: 6,
          bttvRaceRules: false,
          ...(ttRaceSeed.settings ?? {}),
          regardTtrValues: enabled
        }
      };
    }, "TT-Race Einstellung geändert");

    showInfo(
      enabled
        ? "TTR-Werte werden bei der Auslosung berücksichtigt."
        : "TTR-Werte werden bei der Auslosung ignoriert."
    );
  }

  async function handleGenerateSwissRound() {
    try {
      const engine = await loadTtRaceEngine();
      const seed = isTtRaceTournament()
        ? activeTournament.ttRace
        : createTtRaceSeedFromActiveTournament(activeTournament);
      const normalized = engine.normalizeTtRaceTournament(seed);
      const generationState = getTtRaceGenerationStateFromTournament(normalized);

      if (!generationState.canGenerate) {
        showInfo(generationState.reason);
        return;
      }

      const nextRound = normalized.rounds.length > 0
        ? engine.createNextSwissRound(normalized)
        : engine.createInitialSwissRound(normalized);
      const nextTournament = engine.appendSwissRound(normalized, nextRound);

      updateActiveTournament((tournament) => {
        tournament.ttRace = nextTournament;
      }, "Schweizer Runde erzeugt");
      showInfo(`Schweizer Runde ${nextRound.roundNumber} wurde erzeugt.`);
    } catch (error) {
      console.error("Schweizer Runde konnte nicht erzeugt werden.", error);
      showInfo(`Schweizer Runde konnte nicht erzeugt werden: ${error.message || "unbekannter Fehler"}`);
    }
  }

  async function handleRedrawInitialSwissRound() {
    try {
      const redrawState = getTtRaceInitialRedrawState(activeTournament.ttRace);
      if (!redrawState.canRedraw) {
        showInfo(redrawState.reason || "Die erste Runde kann nicht neu gelost werden.");
        return;
      }

      const engine = await loadTtRaceEngine();
      const normalized = engine.normalizeTtRaceTournament(activeTournament.ttRace);
      const nextTournament = engine.redrawInitialSwissRound(normalized);

      updateActiveTournament((tournament) => {
        tournament.ttRace = nextTournament;
      }, "Erste Runde neu gelost");
      showInfo("Erste Runde wurde neu gelost. Ergebnisse sind noch leer.");
    } catch (error) {
      console.error("Erste Runde konnte nicht neu gelost werden.", error);
      showInfo(`Erste Runde konnte nicht neu gelost werden: ${error.message || "unbekannter Fehler"}`);
    }
  }

  async function handleClickTtSetScoreChange(event) {
    const key = event.target.dataset.clickttSetKey;
    const reverseForDisplay = event.target.dataset.clickttSetReverse === "true";
    const rawValue = event.target.value.trim();

    try {
      const bridge = await loadClickTtBridge();
      const storedValue = reverseForDisplay ? bridge.reverseSetScoreText(rawValue) : bridge.formatSetScoreText(bridge.parseSetScoreText(rawValue));

      updateActiveTournament((tournament) => {
        tournament.clicktt = tournament.clicktt || {};
        tournament.clicktt.setScores = tournament.clicktt.setScores || {};

        if (storedValue) {
          tournament.clicktt.setScores[key] = storedValue;
        } else {
          delete tournament.clicktt.setScores[key];
        }
      }, "click-TT Satzpunkte gespeichert", { checkRoundBackups: true });
    } catch (error) {
      console.error("Satzpunkte konnten nicht gespeichert werden.", error);
      showInfo("Satzpunkte konnten nicht gespeichert werden.");
    }
  }

  function canEditTtRaceRoster() {
    return isTtRaceTournament() && (activeTournament.ttRace?.rounds?.length ?? 0) === 0;
  }

  function handleAddTtRacePlayer() {
    if (!canEditTtRaceRoster()) {
      showInfo("Teilnehmer können nach der ersten Runde nicht mehr geändert werden.");
      return;
    }

    updateActiveTournament((tournament) => {
      const players = Array.isArray(tournament.ttRace?.players) ? tournament.ttRace.players : [];
      const nextNumber = players.length + 1;
      const player = {
        id: createTtRacePlayerId(players),
        name: `Teilnehmer ${nextNumber}`,
        seed: null,
        rating: null,
        status: "active"
      };

      tournament.ttRace.players = [...players, player];
      if (tournament.clicktt?.importedPlayers) {
        tournament.clicktt.importedPlayers = [...tournament.clicktt.importedPlayers, {
          clickttId: player.id,
          name: player.name,
          seed: null,
          rating: null,
          status: "active"
        }];
      }
      if (tournament.clicktt?.playerIdByIndex) {
        tournament.clicktt.playerIdByIndex = [...tournament.clicktt.playerIdByIndex, player.id];
      }
      syncRoundRobinFromTtRacePlayers(tournament);
    }, "TT-Race Teilnehmer hinzugefügt");
  }

  function handleRemoveTtRacePlayer(playerId) {
    if (!playerId) {
      return;
    }

    if (!canEditTtRaceRoster()) {
      showInfo("Teilnehmer können nach der ersten Runde nicht mehr entfernt werden.");
      return;
    }

    updateActiveTournament((tournament) => {
      const players = Array.isArray(tournament.ttRace?.players) ? tournament.ttRace.players : [];
      tournament.ttRace.players = players.filter((player) => player.id !== playerId);
      if (tournament.clicktt?.importedPlayers) {
        tournament.clicktt.importedPlayers = tournament.clicktt.importedPlayers.filter(
          (player) => player.clickttId !== playerId && player.id !== playerId
        );
      }
      if (tournament.clicktt?.playerIdByIndex) {
        tournament.clicktt.playerIdByIndex = tournament.clicktt.playerIdByIndex.filter((id) => id !== playerId);
      }
      syncRoundRobinFromTtRacePlayers(tournament);
    }, "TT-Race Teilnehmer entfernt");
  }

  function handleTtRacePlayerFieldChange(event) {
    if (!canEditTtRaceRoster()) {
      return;
    }

    const playerId =
      event.target.dataset.ttRacePlayerName ||
      event.target.dataset.ttRacePlayerFirst ||
      event.target.dataset.ttRacePlayerLast ||
      event.target.dataset.ttRacePlayerRating ||
      event.target.dataset.ttRacePlayerStatus;

    if (!playerId) {
      return;
    }

    updateActiveTournament((tournament) => {
      const players = Array.isArray(tournament.ttRace?.players) ? tournament.ttRace.players : [];
      tournament.ttRace.players = players.map((player) => {
        if (player.id !== playerId) {
          return player;
        }

        if (event.target.matches("[data-tt-race-player-name]")) {
          return { ...player, name: event.target.value.trim() || player.name || "Teilnehmer" };
        }

        // Vor- und Nachname bleiben getrennt erhalten; der Anzeigename
        // entsteht daraus.
        if (event.target.matches("[data-tt-race-player-first]") || event.target.matches("[data-tt-race-player-last]")) {
          const current = splitParticipantName(player);
          const isFirst = event.target.matches("[data-tt-race-player-first]");
          const firstName = (isFirst ? event.target.value : current.firstName).trim();
          const lastName = (isFirst ? current.lastName : event.target.value).trim();
          const name = [firstName, lastName].filter(Boolean).join(" ");
          return { ...player, firstName, lastName, name: name || player.name || "Teilnehmer" };
        }

        if (event.target.matches("[data-tt-race-player-rating]")) {
          const rating = Number.parseInt(event.target.value, 10);
          return { ...player, rating: Number.isFinite(rating) ? rating : null };
        }

        const status = PLAYER_STATUSES[event.target.value] ? event.target.value : "active";
        return { ...player, status };
      });

      if (tournament.clicktt?.importedPlayers) {
        const playerById = new Map(tournament.ttRace.players.map((player) => [player.id, player]));
        tournament.clicktt.importedPlayers = tournament.clicktt.importedPlayers.map((importedPlayer) => {
          const player = playerById.get(importedPlayer.clickttId || importedPlayer.id);
          return player
            ? {
                ...importedPlayer,
                name: player.name,
                rating: player.rating,
                status: player.status
              }
            : importedPlayer;
        });
      }

      syncRoundRobinFromTtRacePlayers(tournament);
    }, "TT-Race Teilnehmer geändert", { trackHistory: event.type !== "input" });
  }

  function createTtRacePlayerId(players) {
    const usedIds = new Set(players.map((player) => player.id));
    let index = players.length + 1;
    let id = `local-player-${index}`;

    while (usedIds.has(id)) {
      index += 1;
      id = `local-player-${index}`;
    }

    return id;
  }

  function syncRoundRobinFromTtRacePlayers(tournament) {
    const players = Array.isArray(tournament.ttRace?.players) ? tournament.ttRace.players : [];
    tournament.roundRobin.playerCount = players.length;
    tournament.roundRobin.playerNames = players.map((player, index) => player.name || `Teilnehmer ${index + 1}`);
    tournament.roundRobin.playerStatuses = players.map((player) =>
      PLAYER_STATUSES[player.status] ? player.status : "active"
    );
    tournament.roundRobin.results = trimRoundRobinResults(tournament.roundRobin.results || {}, players.length);
    tournament.roundRobin.matchStatuses = trimRoundRobinResults(tournament.roundRobin.matchStatuses || {}, players.length);
  }

  async function handleTtRaceSetScoreChange(event) {
    await commitTtRaceSetScoreInput(event.target, { announceErrors: true });
  }

  /**
   * B131: Während des Tippens wird nichts geschrieben — die Zeile unter dem
   * Feld sagt nur, was der nächste Commit übernehmen würde.
   *
   * Vorher hing an `input` derselbe Commit wie an `change`, und daran zerbrach
   * die ausgeschriebene Satzform, sobald man sie tippte statt einfügte: nach
   * dem ersten Zeichen von „11:8" stand für einen Moment „11:4, 11:6, 1" im
   * Feld — drei lesbare Sätze, ein entschiedenes Match. Der Commit feuerte auf
   * diesen Zwischenstand, zeichnete das Blatt neu und setzte das Feld auf den
   * gespeicherten Wert zurück; der Rest der Eingabe lief in ein anderes Feld
   * und wurde am Ende als Unsinn abgewiesen. Eingefügt kam derselbe Text als
   * ein einziges `input`-Ereignis an und ging durch — daher der Unterschied
   * zwischen Tippen und Einfügen.
   *
   * Die anderen drei Formate hatten ihn nie: dort trägt `input` seit jeher nur
   * den Hinweis (`handleQuickResultInput`), geschrieben wird bei Enter, beim
   * Verlassen des Feldes und bei `change`. Genau das gilt jetzt auch hier.
   */
  async function handleTtRaceSetScoreInput(event) {
    const input = event.target;
    clearTtRaceSetInputError(input);

    const rawValue = input.value.trim();
    if (!rawValue) {
      return;
    }

    let gelesen = null;
    try {
      gelesen = await leseTtRaceSetScoreEingabe(rawValue);
    } catch {
      // Fehlt die Engine, bleibt die Hinweiszeile leer; der Commit meldet es.
      return;
    }

    // Zwischen Lesen und Anzeigen kann weitergetippt worden sein. Ein Hinweis
    // zu einem überholten Text ist schlimmer als gar keiner.
    if (!input.isConnected || input.value.trim() !== rawValue) {
      return;
    }

    setQuickResultNote(input, gelesen.meldung, !gelesen.gueltig);
  }

  /**
   * Enter übernimmt und springt zum nächsten offenen Spiel — dieselbe Kette
   * wie in den anderen Formaten (`CHAIN_FIELD_SELECTOR` führt die
   * TT-Race-Felder längst mit).
   */
  async function handleTtRaceSetScoreKeydown(event) {
    if (event.key !== "Enter") {
      return;
    }

    event.preventDefault();
    const input = event.target;
    pendingChainFocus = describeFocusField(input, tournamentSheet);
    const rendersBefore = sheetRenderCount;

    try {
      const committed = await commitTtRaceSetScoreInput(input, { announceErrors: true });
      // Hat sich nichts geändert, zeichnet niemand neu — dann springt Enter
      // hier selbst weiter, sonst hat es das Neuzeichnen getan.
      if (committed && sheetRenderCount === rendersBefore) {
        applyPendingChainFocus(tournamentSheet);
      }
    } finally {
      pendingChainFocus = null;
    }
  }

  /**
   * Liest den Feldtext, ohne etwas zu speichern: einmal geschrieben für die
   * Hinweiszeile beim Tippen und für den Commit. Zwei getrennte Lesungen wären
   * zwei Regelwerke, die auseinanderlaufen — der Hinweis verspräche dann etwas
   * anderes, als Enter übernimmt.
   */
  async function leseTtRaceSetScoreEingabe(rawValue) {
    // Ein geleertes Feld nimmt das Ergebnis zurück — kein Fehler, kein Hinweis.
    if (rawValue === "") {
      return { gueltig: true, meldung: "", sets: [], setScore: null, kurzform: false };
    }

    const engine = await loadTtRaceEngine();
    const parsed = engine.parseTableTennisSetScoreText(rawValue);

    if (parsed.errors.length > 0) {
      return { gueltig: false, meldung: parsed.errors[0], sets: [], setScore: null, kurzform: false };
    }

    // B129: Die Kurzform „3:1" gilt hier genauso wie in den anderen drei
    // Formaten — sie trägt das Gesamtergebnis ohne Satzdetails.
    if (parsed.matchScore) {
      const gesamt = engine.validateTableTennisMatchScore(parsed.matchScore, {
        settings: activeTournament.ttRace?.settings,
        requireCompleteMatch: true
      });

      return gesamt.valid
        ? {
            gueltig: true,
            meldung: `Enter übernimmt ${gesamt.setScore.a}:${gesamt.setScore.b}`,
            sets: [],
            setScore: gesamt.setScore,
            kurzform: true
          }
        : { gueltig: false, meldung: gesamt.errors[0], sets: [], setScore: null, kurzform: true };
    }

    const validation = engine.validateTableTennisSetScores(parsed.sets, {
      settings: activeTournament.ttRace?.settings,
      requireCompleteMatch: rawValue !== ""
    });

    if (!validation.valid) {
      return { gueltig: false, meldung: validation.errors[0], sets: [], setScore: null, kurzform: false };
    }

    const gesamtText = validation.setScore ? `${validation.setScore.a}:${validation.setScore.b}` : "";
    const satzText = formatSetScoreDisplay(parsed.sets);

    return {
      gueltig: true,
      meldung: gesamtText ? `Enter übernimmt ${gesamtText} · ${satzText}` : `Enter übernimmt ${satzText}`,
      sets: parsed.sets,
      setScore: null,
      kurzform: false
    };
  }

  /** Rückgabe: ob der Wert übernommen wurde — daran hängt die Enter-Kette. */
  async function commitTtRaceSetScoreInput(input, { announceErrors = true } = {}) {
    const matchId = input.dataset.ttRaceSets;
    const rawValue = input.value.trim();
    clearTtRaceSetInputError(input);

    try {
      const engine = await loadTtRaceEngine();
      const gelesen = await leseTtRaceSetScoreEingabe(rawValue);

      if (!gelesen.gueltig) {
        setTtRaceSetInputError(input, gelesen.meldung);
        if (announceErrors) {
          showInfo(gelesen.meldung);
        }
        return false;
      }

      const normalized = engine.normalizeTtRaceTournament(activeTournament.ttRace);
      const nextTournament = gelesen.kurzform
        ? engine.recordSwissMatchResult(normalized, matchId, {
            status: "completed",
            sets: [],
            setScore: gelesen.setScore
          })
        : engine.recordSwissMatchResult(normalized, matchId, {
            status: gelesen.sets.length > 0 ? "completed" : "scheduled",
            sets: gelesen.sets
          });

      updateActiveTournament((tournament) => {
        tournament.ttRace = nextTournament;
      }, "TT-Race Ergebnis gespeichert", { checkRoundBackups: true });
      return true;
    } catch (error) {
      console.error("TT-Race Ergebnis konnte nicht gespeichert werden.", error);
      setTtRaceSetInputError(input, error.message || "Ungültige Satzpunkte.");
      if (announceErrors) {
        showInfo(`TT-Race Ergebnis konnte nicht gespeichert werden: ${error.message || "unbekannter Fehler"}`);
      }
      return false;
    }
  }

  function setTtRaceSetInputError(input, message) {
    input.classList.add("is-invalid");
    input.setAttribute("aria-invalid", "true");

    // In der Spielzeile trägt die Rückmeldezeile unter dem Feld den Hinweis.
    const note = input.parentElement?.querySelector("[data-quick-note]");
    if (note) {
      note.textContent = message;
      note.classList.add("is-error");
      return;
    }

    const field = input.closest(".set-score-field");
    if (!field) {
      return;
    }

    let errorElement = field.querySelector(".set-score-error");
    if (!errorElement) {
      errorElement = document.createElement("span");
      errorElement.className = "set-score-error";
      field.appendChild(errorElement);
    }

    errorElement.textContent = message;
  }

  function clearTtRaceSetInputError(input) {
    input.classList.remove("is-invalid");
    input.removeAttribute("aria-invalid");

    const note = input.parentElement?.querySelector("[data-quick-note]");
    if (note) {
      note.textContent = "";
      note.classList.remove("is-error");
    }

    input.closest(".set-score-field")?.querySelector(".set-score-error")?.remove();
  }

  function handleLoadRaceDayDemo() {
    const shouldLoadDemo = window.confirm(
      "TT-Race Demo in das laufende Turnier laden?\n\n" +
        "Die aktuellen Daten in diesem Turnier werden überschrieben. Über Rückgängig lässt sich die Änderung zurücknehmen."
    );

    if (!shouldLoadDemo) {
      return;
    }

    clickTtImportDraft = {
      fileName: "bttv-tt-race-demo.xml",
      sizeKb: 18,
      detectedEntries: 12,
      loadedAt: new Date().toISOString()
    };

    updateActiveTournament((tournament) => {
      const demoCopy = createTournamentRecord(createRaceDayDemoState(), tournament.id);
      Object.keys(tournament).forEach((key) => {
        delete tournament[key];
      });
      Object.assign(tournament, demoCopy);
    }, "TT-Race Demo geladen");
    showInfo("TT-Race Demo mit 12 Teilnehmern, 6 Tischen und laufender Runde geladen.");
  }

  function createRaceDayDemoState() {
    const playerNames = [
      "Mia Keller",
      "Lukas Braun",
      "Sofia Nguyen",
      "Ben Adler",
      "Tarek Yilmaz",
      "Nora Klein",
      "Emil Hoffmann",
      "Lea Schuster",
      "Jonas Graf",
      "Mara Weber",
      "Noah Fuchs",
      "Clara Roth"
    ];
    const playerRatings = [1748, 1685, 1632, 1588, 1541, 1497, 1464, 1420, 1386, 1344, 1298, 1255];

    return {
      tabName: "TT-Race Demo",
      tournamentName: "BTTV TT-Race Abendturnier",
      mode: "roundRobin",
      matchMode: "win3",
      schedule: {
        fieldCount: 6,
        startTime: "18:30",
        matchDurationMinutes: 18,
        breakMinutes: 2,
        fieldNames: ["Tisch 1", "Tisch 2", "Tisch 3", "Tisch 4", "Tisch 5", "Tisch 6"]
      },
      roundRobin: {
        playerCount: 12,
        currentRound: 3,
        playerNames,
        playerStatuses: Array.from({ length: 12 }, () => "active"),
        results: {
          "0-1": "3:1",
          "2-3": "3:2",
          "4-5": "1:3",
          "6-7": "3:0",
          "8-9": "2:3",
          "10-11": "3:1",
          "0-2": "3:0",
          "1-3": "1:3",
          "4-6": "3:2",
          "5-7": "3:1",
          "8-10": "0:3",
          "9-11": "3:2"
        },
        matchStatuses: {}
      },
      ttRace: {
        id: "tt-race-demo",
        name: "BTTV TT-Race Abendturnier",
        settings: {
          maxRounds: 6,
          bttvRaceRules: true,
          regardTtrValues: true
        },
        players: playerNames.map((name, index) => ({
          id: `demo-player-${index + 1}`,
          name,
          seed: index + 1,
          rating: playerRatings[index],
          status: "active"
        })),
        rounds: []
      }
    };
  }

  function createTtRaceSeedFromActiveTournament(tournament) {
    const names = getRaceDayParticipants();
    const clickttIds = tournament.clicktt?.playerIdByIndex ?? [];
    const importedPlayersById = new Map(
      (tournament.clicktt?.importedPlayers ?? []).map((player) => [player.clickttId, player])
    );

    return {
      id: tournament.clicktt?.tournamentId || tournament.id || "tt-race",
      name: tournament.tournamentName || "TT-Race",
      settings: {
        maxRounds: 6,
        bttvRaceRules: false,
        regardTtrValues: true
      },
      players: names.map((name, index) => {
        const id = clickttIds[index] || `player-${index + 1}`;
        const importedPlayer = importedPlayersById.get(id);

        return {
          id,
          name,
          seed: importedPlayer?.seed ?? index + 1,
          rating: importedPlayer?.rating ?? null,
          status: importedPlayer?.status || "active"
        };
      }),
      rounds: []
    };
  }

  async function handleCopyClickTtXml() {
    if (activeTournament.clicktt?.rawXml && !clickTtBridgeModule) {
      try {
        await loadClickTtBridge();
      } catch (error) {
        // B110: Bisher stand hier nur ein console.warn. Danach fiel
        // `buildClickTtXmlPreview` still in den Demo-Zweig zurück, und die
        // Erfolgsmeldung „wurde in die Zwischenablage kopiert" blieb stehen —
        // in der Zwischenablage lagen Demodaten, die niemand angefordert hat.
        console.warn("click-TT Adapter konnte nicht geladen werden.", error);
        showInfo(
          "click-TT-Adapter konnte nicht geladen werden — es wurde nichts kopiert. Seite neu laden und erneut versuchen."
        );
        return;
      }
    }

    const xml = buildClickTtXmlPreview();

    if (!navigator.clipboard?.writeText) {
      showInfo("Zwischenablage ist in diesem Browser nicht verfügbar. Die XML-Vorschau bleibt sichtbar.");
      return;
    }

    navigator.clipboard
      .writeText(xml)
      .then(() => showInfo("click-TT XML-Vorschau wurde in die Zwischenablage kopiert."))
      .catch((error) => {
        console.warn("XML-Vorschau konnte nicht kopiert werden.", error);
        showInfo("Die XML-Vorschau konnte nicht kopiert werden.");
      });
  }

  async function handleDownloadClickTtXml() {
    const title =
      activeTournament.tournamentName?.trim() ||
      getTournamentLabel(activeTournament, getActiveTournamentIndex());

    if (activeTournament.clicktt?.rawXml) {
      try {
        const exportState = getTtRaceFinalExportState(activeTournament.ttRace);
        if (!exportState.canExport) {
          showInfo(exportState.reason);
          return;
        }
        const bridge = await loadClickTtBridge();
        const result = bridge.exportClickttTournamentResults(activeTournament);
        downloadBlob(
          `${sanitizeFilename(title)}_clicktt_ergebnisse.xml`,
          new Blob([result.xml], { type: "application/xml;charset=utf-8" })
        );
        const warningSuffix = result.warnings.length > 0
          ? ` ${result.warnings.length} Hinweis${result.warnings.length === 1 ? "" : "e"} zur Satzpunkt-Erzeugung.`
          : "";
        showInfo(`click-TT Ergebnis-XML wurde exportiert.${warningSuffix}`);
      } catch (error) {
        console.error("click-TT Ergebnis-XML konnte nicht exportiert werden.", error);
        showInfo(`click-TT Ergebnis-XML konnte nicht exportiert werden: ${error.message || "unbekannter Fehler"}`);
      }
      return;
    }

    downloadBlob(
      `${sanitizeFilename(title)}_clicktt_ergebnisse_demo.xml`,
      new Blob([buildClickTtXmlPreview()], { type: "application/xml;charset=utf-8" })
    );
    showInfo("Demo-XML wurde heruntergeladen. Für einen echten click-TT Export zuerst die Portal-XML importieren.");
  }

  function handleExportCsv() {
    if (activeTournament.mode === "team") {
      exportTeamCsv(analysis);
    } else if (activeTournament.mode === "groupsKnockout") {
      exportGroupsKnockoutCsv(analysis);
    } else {
      exportRoundRobinCsv(analysis);
    }
  }

  function handleExportXlsx() {
    if (activeTournament.mode === "team") {
      exportTeamXlsx(analysis);
    } else if (activeTournament.mode === "groupsKnockout") {
      exportGroupsKnockoutXlsx(analysis);
    } else {
      exportRoundRobinXlsx(analysis);
    }
  }

  function handleExportCurrentRoundCsv() {
    const roundExport = getCurrentRoundExportData();
    if (!roundExport.round) {
      showInfo("Für die aktuelle Runde sind keine Daten verfügbar.");
      return;
    }

    if (activeTournament.mode === "team") {
      exportTeamRoundCsv(roundExport.analysis, roundExport.round, roundExport.currentRoundNumber, roundExport.totalRounds);
    } else if (activeTournament.mode === "groupsKnockout") {
      exportGroupsKnockoutRoundCsv(roundExport.analysis, roundExport.round, roundExport.currentRoundNumber, roundExport.totalRounds);
    } else {
      exportRoundRobinRoundCsv(roundExport.analysis, roundExport.round, roundExport.currentRoundNumber, roundExport.totalRounds);
    }
  }

  function handleExportCurrentRoundXlsx() {
    const roundExport = getCurrentRoundExportData();
    if (!roundExport.round) {
      showInfo("Für die aktuelle Runde sind keine Daten verfügbar.");
      return;
    }

    if (activeTournament.mode === "team") {
      exportTeamRoundXlsx(roundExport.analysis, roundExport.round, roundExport.currentRoundNumber, roundExport.totalRounds);
    } else if (activeTournament.mode === "groupsKnockout") {
      exportGroupsKnockoutRoundXlsx(roundExport.analysis, roundExport.round, roundExport.currentRoundNumber, roundExport.totalRounds);
    } else {
      exportRoundRobinRoundXlsx(roundExport.analysis, roundExport.round, roundExport.currentRoundNumber, roundExport.totalRounds);
    }
  }

  /**
   * Die Dokumentliste je Format. Ein Dokument, das ein Format nicht ehrlich
   * füllen kann, steht dort nicht — für TT-Race gibt es keine Vollmatrix, dafür
   * die Startliste, die dem Knopf endlich entspricht.
   */
  function getPrintDocumentList() {
    const basis = [
      { mode: "schedule", label: "Spielplan", knopf: "Spielplan drucken" },
      { mode: "resultSlips", label: "Leere Ergebniszettel", knopf: "Leere Ergebniszettel drucken" },
      { mode: "resultMatrix", label: "Ergebnismatrix", knopf: "Ergebnismatrix drucken", hatUmfang: true },
      { mode: "ranking", label: "Rangliste", knopf: "Rangliste drucken" },
      { mode: "winners", label: "Siegerliste", knopf: "Siegerliste drucken" },
      { mode: "certificate", label: "Urkunde / Siegerblatt", knopf: "Urkunden drucken" }
    ];

    if (isTtRaceTournament()) {
      return [
        { mode: "startlist", label: "Startliste", knopf: "Startliste drucken" },
        ...basis.filter((dokument) => dokument.mode !== "resultMatrix")
      ];
    }

    return basis;
  }

  function getPrintDocumentDefinition(mode) {
    const liste = getPrintDocumentList();
    return liste.find((dokument) => dokument.mode === mode) || liste[0];
  }

  /** Zeichnet den Randspaltenblock „Drucken / PDF" neu. */
  function renderPrintRail() {
    if (!printRail) {
      return;
    }

    const liste = getPrintDocumentList();
    if (!liste.some((dokument) => dokument.mode === printSelection.mode)) {
      printSelection.mode = liste[0].mode;
    }

    printRail.hidden = false;
    printDocumentButtons.innerHTML = liste
      .map(
        (dokument) => `
          <button
            class="link-button ${dokument.mode === printSelection.mode ? "is-print-selected" : ""}"
            type="button"
            data-print-mode="${escapeHtml(dokument.mode)}"
          >${escapeHtml(dokument.knopf)}</button>
        `
      )
      .join("");

    const zeigtUmfang = liste.some((dokument) => dokument.hatUmfang);
    printScopeRow.hidden = !zeigtUmfang;
    printScopeSelect.value = printSelection.scope;

    // Cmd+P druckt, was zuletzt gewählt wurde — das gehört hingeschrieben,
    // sonst ist die Tastenkombination ein Griff ins Dunkle.
    const gewaehlt = getPrintDocumentDefinition(printSelection.mode);
    printKeyboardNote.textContent = `Cmd+P druckt: ${gewaehlt.label}${
      gewaehlt.hatUmfang && printSelection.scope !== "all"
        ? printSelection.scope === "matrix"
          ? " (nur das Raster)"
          : " (nur die Runden)"
        : ""
    }.`;
  }

  function handlePrintDocument(mode) {
    if (mode) {
      printSelection.mode = mode;
      renderPrintRail();
    }
    preparePrintDocument();
    window.print();
  }

  function preparePrintDocument() {
    if (!printDocument) {
      return;
    }

    const dokument = getPrintDocumentDefinition(printSelection.mode);
    printDocument.innerHTML = renderPrintDocument(dokument.mode, printSelection.scope);
    vereinheitlichePapierlage();
    // Der Fenstertitel ist die Kopfzeile des Ausdrucks: Chrome und Safari
    // setzen ihn oben aufs Blatt und die Seitenzahl darunter. Ohne ihn stand
    // auf jedem Dokument derselbe Text und der Ausdruck sagte nicht, was er
    // ist. Eine eigene mitlaufende Fußzeile ist kein Ersatz — `position: fixed`
    // wird in Chrome nicht je Seite neu positioniert, sie landete quer über dem
    // Text der Folgeseiten (selbst im PDF gesehen).
    document.title = `${getPrintTournamentTitle()} — ${dokument.label} — ${formatPrintDate(new Date())}`;
    document.body.classList.add("is-printing-document");
  }

  /**
   * Ein Dokument hat EINE Papierlage. Gemischt gedruckt legt Chrome den
   * gesamten Inhalt auf die Breite der ersten Seite aus; die Hochformatseiten
   * dahinter werden am rechten Rand abgeschnitten — im PDF nachgesehen: die
   * rechte Spalte der Rundenübersicht endete mitten im Namen. Braucht also das
   * Raster Querformat, geht das ganze Dokument quer.
   */
  function vereinheitlichePapierlage() {
    const quer = Boolean(printDocument.querySelector(".print-page--quer"));
    printDocument.classList.toggle("print-document--quer", quer);
    if (!quer) {
      return;
    }
    // Auch der Dokumentkopf steht außerhalb der Seiten und wäre sonst das
    // einzige Hochformatblatt am Anfang (im PDF nachgemessen).
    printDocument.querySelectorAll(".print-page").forEach((seite) => {
      seite.classList.add("print-page--quer");
    });
  }

  function cleanupPrintDocument() {
    document.body.classList.remove("is-printing-document");
    renderAppTitle();
  }

  function renderPrintDocument(printMode, scope = "all") {
    switch (printMode) {
      case "startlist":
        return renderPrintShell("Startliste", renderPrintStartList());
      case "resultSlips":
        return renderPrintShell("Leere Ergebniszettel", renderPrintResultSlips());
      case "resultMatrix":
        return renderPrintShell("Ergebnismatrix", renderPrintResultMatrix(scope));
      case "ranking":
        return renderPrintShell("Rangliste", renderPrintRanking());
      case "winners":
        return renderPrintShell("Siegerliste", renderPrintWinners());
      case "certificate":
        return renderPrintCertificates();
      case "schedule":
      default:
        return renderPrintShell("Spielplan", renderPrintSchedule());
    }
  }

  function renderPrintShell(documentTitle, content) {
    return `
      <article class="print-document-sheet">
        <header class="print-document-header">
          <div>
            <p class="eyebrow">Turnierblatt</p>
            <h1>${escapeHtml(getPrintTournamentTitle())}</h1>
          </div>
          <div class="print-document-meta">
            <strong>${escapeHtml(documentTitle)}</strong>
            <span>${escapeHtml(analysis.matchModeLabel)}</span>
            <span>${escapeHtml(formatPrintDate(new Date()))}</span>
          </div>
        </header>
        ${content}
      </article>
    `;
  }

  function renderPrintSchedule() {
    // TT-Race zuerst: das Schweizer System kennt keinen Vollplan. Runde 2
    // entsteht erst aus dem Zwischenstand — vorher fiel dieser Zweig auf den
    // aus dem Roster gesyncten Jeder-gegen-jeden-Plan zurück und hängte sieben
    // erfundene Runden aus (B057).
    if (isTtRaceTournament()) {
      return renderPrintTtRaceSchedule();
    }

    if (analysis.schedule) {
      return renderPrintTimedSchedule();
    }

    if (activeTournament.mode === "groupsKnockout") {
      return `
        ${renderPrintRoundGroup("Spielplan Gruppenphase", analysis.groupRoundSchedule || [], "Alle geplanten Gruppenspiele.", false)}
        ${
          analysis.knockoutRounds?.length > 0
            ? renderPrintRoundGroup("Spielplan KO-Runde", analysis.knockoutRounds, "Alle gesetzten KO-Begegnungen.", false)
            : ""
        }
      `;
    }

    if (activeTournament.mode === "team") {
      return `
        ${renderPrintRoundGroup("Spielplan Einzel", analysis.rounds, "Alle geplanten Einzelbegegnungen.", false)}
        ${
          analysis.doubleRounds.length > 0
            ? renderPrintRoundGroup("Spielplan Doppel", analysis.doubleRounds, "Alle geplanten Doppelbegegnungen.", false)
            : ""
        }
      `;
    }

    return renderPrintRoundGroup(
      "Spielplan",
      analysis.rounds,
      "Alle Runden des Jeder-gegen-jeden-Turniers.",
      false
    );
  }

  /**
   * Nur die tatsächlich ausgelosten Schweizer Runden — mit dem Hinweis, warum
   * hier keine weiteren stehen. Ein Turnierleiter, der diesen Zettel aushängt,
   * hängt nichts aus, was noch nicht entschieden ist.
   */
  function renderPrintTtRaceSchedule() {
    const spieler = new Map((activeTournament.ttRace?.players ?? []).map((player) => [player.id, player]));
    const runden = activeTournament.ttRace?.rounds ?? [];

    if (runden.length === 0) {
      return renderPrintEmptyState(
        "Spielplan",
        "Noch keine Schweizer Runde ausgelost. Im TT-Race entsteht jede Runde aus dem aktuellen Zwischenstand."
      );
    }

    const karten = runden.map((runde) => {
      const zeilen = (runde.matches || [])
        .map((match) => {
          const a = spieler.get(match.playerAId)?.name || match.playerAId || "";
          const b = spieler.get(match.playerBId)?.name || match.playerBId || "";
          // Satzstand fett, die einzelnen Sätze klein darunter — dieselbe Form
          // wie in der Rundenübersicht. Die ausgeschriebenen Sätze allein in
          // einer 76-px-Spalte brachen in fünf Zeilen um (im PDF gesehen).
          const summe = formatTtRaceMatchSummary(match);
          const saetze = formatSetScoreDisplay(match.sets);
          return `
            <tr>
              <td>${escapeHtml(String(match.table ?? "-"))}</td>
              <td>${escapeHtml(a)} - ${escapeHtml(b)}</td>
              <td>
                <strong>${escapeHtml(summe || "offen")}</strong>
                ${saetze ? `<small>${escapeHtml(saetze)}</small>` : ""}
              </td>
            </tr>
          `;
        })
        .join("");
      const freilose = (runde.byes || [])
        .map((bye) => {
          const name = spieler.get(bye.playerId)?.name || bye.playerId || "";
          return `
            <tr class="print-bye-row">
              <td>-</td>
              <td>${escapeHtml(name)} spielfrei</td>
              <td><strong>${escapeHtml(formatTtRaceByePoints(getTtRaceByePointValue(bye)))}</strong></td>
            </tr>
          `;
        })
        .join("");

      return `
        <article class="print-round-card">
          <div class="print-round-card-header">
            <div>
              <p>${escapeHtml(getPrintTournamentTitle())}</p>
              <h3>Runde ${escapeHtml(String(runde.roundNumber))}</h3>
            </div>
            <span>${(runde.matches || []).filter((match) => match.status && !["scheduled", "void"].includes(match.status)).length}/${(runde.matches || []).length} erfasst</span>
          </div>
          <table class="print-match-table print-ttrace-schedule-table">
            <thead><tr><th>Tisch</th><th>Begegnung</th><th>Ergebnis</th></tr></thead>
            <tbody>${zeilen}${freilose}</tbody>
          </table>
        </article>
      `;
    });

    return `
      <section class="print-page print-round-group">
        ${renderPrintPageHeader(
          "Spielplan",
          `${runden.length} ausgeloste Schweizer Runde${runden.length === 1 ? "" : "n"}. Die nächste Runde entsteht erst aus dem dann gültigen Zwischenstand.`
        )}
        <div class="print-round-grid">${karten.join("")}</div>
      </section>
    `;
  }

  /**
   * Das siebte Dokument (B057): der Roster mit TTR-Wert und Setzung. Erst
   * damit hält der Knopf „Startliste drucken" sein Versprechen.
   */
  function renderPrintStartList() {
    const spieler = activeTournament.ttRace?.players ?? [];

    if (spieler.length === 0) {
      return renderPrintEmptyState("Startliste", "Noch keine Teilnehmer geladen.");
    }

    const nachSetzung = getTtRaceRegardTtrValues()
      ? [...spieler].sort((a, b) => (Number(b.rating) || 0) - (Number(a.rating) || 0))
      : spieler;

    return `
      <section class="print-page">
        ${renderPrintPageHeader(
          "Startliste",
          getTtRaceRegardTtrValues()
            ? "Nach TTR-Wert gesetzt — die erste Auslosung folgt dieser Reihenfolge."
            : "Ohne TTR-Setzung — die erste Auslosung erfolgt zufällig."
        )}
        <div class="table-wrapper print-table-wrapper">
          <table class="stats-table print-startlist-table">
            <thead>
              <tr>
                <th>${getTtRaceRegardTtrValues() ? "Setzung" : "Nr."}</th>
                <th>Name</th>
                <th>Verein</th>
                <th>TTR</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${nachSetzung
                .map((player, index) => {
                  const status = player.status || "active";
                  return `
                    <tr>
                      <td>${index + 1}</td>
                      <td>${escapeHtml(player.name || player.id || "")}</td>
                      <td>${escapeHtml(player.clubName || player.club || "-")}</td>
                      <td>${hasTtrValue(player.rating) ? escapeHtml(formatTtrValue(player.rating)) : "-"}</td>
                      <td>${escapeHtml(status === "active" ? "aktiv" : PLAYER_STATUSES[status]?.label || status)}</td>
                    </tr>
                  `;
                })
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function renderPrintTimedSchedule() {
    const schedule = analysis.schedule;
    if (!schedule || schedule.matches.length === 0) {
      return renderPrintEmptyState("Spielplan", "Für dieses Turnier sind noch keine Spiele im Zeitplan.");
    }

    const rows = schedule.matches.map((match) => [
      "          <tr>",
      "            <td>" + escapeHtml(match.plannedTime) + "</td>",
      "            <td>" + escapeHtml(match.fieldName) + "</td>",
      "            <td>" + escapeHtml(match.roundLabel) + "</td>",
      "            <td>" + escapeHtml(match.matchLabel) + "</td>",
      "            <td>" + escapeHtml(match.status) + "</td>",
      "          </tr>"
    ].join("")).join("");

    return [
      "      <section class=\"print-page print-round-group print-schedule-page\">",
      renderPrintPageHeader(
        "Spielplan",
        "Start " + schedule.startTime + " · Ende ca. " + schedule.endTime + " · " + schedule.config.fieldCount + " Tisch" + (schedule.config.fieldCount === 1 ? "" : "e")
      ),
      "        <table class=\"stats-table schedule-table print-schedule-table\">",
      "          <thead><tr><th>Uhrzeit</th><th>Tisch</th><th>Runde</th><th>Begegnung</th><th>Status</th></tr></thead>",
      "          <tbody>",
      rows,
      "          </tbody>",
      "        </table>",
      "      </section>"
    ].join("");
  }
  function renderPrintResultSlips() {
    // Auch die Zettel liefen über den RR-Vollplan und trugen Begegnungen, die
    // es nie geben wird (B057, zweiter Weg).
    if (isTtRaceTournament()) {
      const runden = activeTournament.ttRace?.rounds ?? [];
      if (runden.length === 0) {
        return renderPrintEmptyState(
          "Ergebniszettel",
          "Noch keine Schweizer Runde ausgelost — es gibt keine Begegnungen zum Ausfüllen."
        );
      }
      return renderPrintTtRaceResultSlips(runden);
    }

    if (activeTournament.mode === "groupsKnockout") {
      return `
        ${renderPrintRoundGroup("Ergebniszettel Gruppenphase", analysis.groupRoundSchedule || [], "Zum Ausfüllen während der Gruppenspiele.", true)}
        ${
          analysis.knockoutRounds?.length > 0
            ? renderPrintRoundGroup("Ergebniszettel KO-Runde", analysis.knockoutRounds, "Zum Ausfüllen während der KO-Runde.", true)
            : ""
        }
      `;
    }

    if (activeTournament.mode === "team") {
      return `
        ${renderPrintRoundGroup("Ergebniszettel Einzel", analysis.rounds, "Zum Ausfüllen während der Einzelrunden.", true)}
        ${
          analysis.doubleRounds.length > 0
            ? renderPrintRoundGroup("Ergebniszettel Doppel", analysis.doubleRounds, "Zum Ausfüllen während der Doppelrunden.", true)
            : ""
        }
      `;
    }

    return renderPrintRoundGroup(
      "Ergebniszettel",
      analysis.rounds,
      "Zum Ausfüllen während der Runden.",
      true
    );
  }

  function renderPrintTtRaceResultSlips(runden) {
    const spieler = new Map((activeTournament.ttRace?.players ?? []).map((player) => [player.id, player]));

    const karten = runden.map((runde) => {
      const zeilen = (runde.matches || [])
        .map((match, index) => {
          const a = spieler.get(match.playerAId)?.name || match.playerAId || "";
          const b = spieler.get(match.playerBId)?.name || match.playerBId || "";
          return `
            <tr>
              <td>${index + 1}</td>
              <td>${escapeHtml(a)} - ${escapeHtml(b)}</td>
              <td><span class="print-score-line" aria-hidden="true"></span></td>
              <td><span class="print-note-line" aria-hidden="true"></span></td>
            </tr>
          `;
        })
        .join("");

      return `
        <article class="print-round-card">
          <div class="print-round-card-header">
            <div>
              <p>${escapeHtml(getPrintTournamentTitle())}</p>
              <h3>Runde ${escapeHtml(String(runde.roundNumber))}</h3>
            </div>
            <span>Tisch ${escapeHtml(String((runde.matches || [])[0]?.table ?? "-"))} ff.</span>
          </div>
          <table class="print-match-table">
            <thead><tr><th>Nr.</th><th>Begegnung</th><th>Ergebnis</th><th>Notiz / Unterschrift</th></tr></thead>
            <tbody>${zeilen}</tbody>
          </table>
        </article>
      `;
    });

    return `
      <section class="print-page print-round-group">
        ${renderPrintPageHeader(
          "Ergebniszettel",
          `Zum Ausfüllen während der ${runden.length} ausgelosten Schweizer Runde${runden.length === 1 ? "" : "n"}.`
        )}
        <div class="print-round-grid">${karten.join("")}</div>
      </section>
    `;
  }

  /**
   * `scope` steuert Antonios Auswahl: alles, nur das Ergebnisraster oder nur
   * die einzelnen Runden. Dafür stehen Raster und Rundenübersicht als eigene
   * Seiten nebeneinander statt ineinander — vorher hing die Rundenübersicht
   * innerhalb der Rasterseite und ließ sich nicht trennen.
   */
  function renderPrintResultMatrix(scope = "all") {
    if (isTtRaceTournament()) {
      return renderPrintEmptyState(
        "Ergebnismatrix",
        "Für TT-Race gibt es keine Vollmatrix. Nutze hier Spielplan oder Rangliste."
      );
    }

    if (activeTournament.mode === "groupsKnockout") {
      return renderPrintGroupsResultMatrix(scope);
    }

    if (activeTournament.mode === "team") {
      return renderPrintTeamResultMatrix(scope);
    }

    return renderPrintRoundRobinResultMatrix(scope);
  }

  const zeigeRaster = (scope) => scope !== "rounds";
  const zeigeRunden = (scope) => scope !== "matrix";

  /**
   * Ab dieser Spaltenzahl passt die Matrix nicht mehr aufs Hochformat. Gemessen
   * (Prüfer Lauf 004, A4 hoch, 182 mm): 13 Teilnehmer waren der letzte lesbare
   * Stand, ab 14 brach jede Ergebniszelle zu „3:"/„0" um. Der Umschaltpunkt
   * liegt bewusst bei 10 — mit Satzdetails ist die Zelle schon vorher eng, und
   * Querformat kostet nichts außer der Papierlage.
   */
  const QUERFORMAT_AB_SPALTEN = 10;

  function istQuerformat(spaltenZahl) {
    return spaltenZahl >= QUERFORMAT_AB_SPALTEN;
  }

  /**
   * Wenige Spalten lassen der Namensspur mehr Platz. Bei acht Teilnehmern
   * wurde „CHRISTINA BERGMANN" in der 24-%-Spur gekürzt, während rechts neben
   * dem Raster Papier frei blieb — die Kürzung ist nötig gegen den Überdruck
   * (B058), aber sie soll erst greifen, wenn der Platz wirklich knapp ist.
   */
  function matrixNamensSpur(spaltenZahl) {
    return spaltenZahl <= 8 ? "has-wide-names" : "";
  }

  function matrixSeitenKlasse(spaltenZahl) {
    return istQuerformat(spaltenZahl) ? "print-page print-page--quer" : "print-page";
  }

  /**
   * Satzdetails stehen NICHT in der Rasterzelle — auch nicht im Querformat.
   *
   * Gemessen (Chrome, A4, Lauf 004 Welle 4): eine Ergebnisspalte hat bei zwölf
   * Teilnehmern 32 px im Hochformat und 51 px im Querformat. „11:9, 8:11,
   * 11:7, 5:11, 12:10" braucht bei 7 pt rund 126 px. Selbst die Kurzform
   * („9, -11, 7, -11, 10", rund 76 px) passt erst unter fünf Spalten — und so
   * kleine Raster gibt es kaum. Jede Fassung mit Sätzen in der Zelle bricht
   * also, und ein gebrochenes Raster ist unlesbar (B022).
   *
   * Verloren geht dabei nichts: die Rundenübersicht im selben Dokument
   * schreibt jeden Satz aus, und der Untertitel sagt, wo sie stehen.
   */
  function matrixZeigtSatzdetails() {
    return false;
  }

  function matrixUntertitel(basis, spaltenZahl) {
    return istQuerformat(spaltenZahl)
      ? `${basis} Querformat wegen ${spaltenZahl} Spalten; die Sätze stehen ausgeschrieben in der Rundenübersicht.`
      : `${basis} Die Sätze stehen ausgeschrieben in der Rundenübersicht.`;
  }

  function renderPrintRoundRobinResultMatrix(scope = "all") {
    const spalten = analysis.players.length;
    const mitSaetzen = matrixZeigtSatzdetails();

    const raster = `
      <section class="${matrixSeitenKlasse(spalten)}">
        ${renderPrintPageHeader(
          "Ergebnismatrix",
          matrixUntertitel("Aktueller Stand aller Jeder-gegen-jeden-Begegnungen.", spalten)
        )}
        <div class="table-wrapper print-table-wrapper">
          <table class="stats-table print-result-matrix-table has-summary ${matrixNamensSpur(spalten)}">
            ${renderPrintMatrixColGroup(spalten, true)}
            <thead>
              <tr>
                <th>Spieler</th>
                ${renderPrintMatrixColumnHeaders(spalten)}
                <th>Sätze</th>
                <th>Platz</th>
              </tr>
            </thead>
            <tbody>
              ${analysis.players.map((player, rowIndex) => `
                <tr>
                  ${renderPrintMatrixPlayerHeading(player, rowIndex)}
                  ${analysis.players.map((_, columnIndex) => renderPrintRoundRobinMatrixCell(rowIndex, columnIndex, mitSaetzen)).join("")}
                  ${renderPrintRoundRobinMatrixSummaryCells(rowIndex)}
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
        ${renderPrintMatrixLegend(analysis.players)}
      </section>
    `;

    return `
      ${zeigeRaster(scope) ? raster : ""}
      ${
        zeigeRunden(scope)
          ? renderPrintCompactRoundOverview(
              "Rundenübersicht",
              analysis.rounds,
              "Alle Einzelrunden ohne Uhrzeit und Tisch, mit ausgeschriebenen Sätzen.",
              "",
              true
            )
          : ""
      }
    `;
  }

  /**
   * Namenslegende unter dem Raster. Bei Jeder-gegen-jeden ist sie Komfort
   * (die Nummer steht auch links in der Zeile), beim Teamwettbewerb ist sie
   * Pflicht: Zeilen und Spalten sind dort zwei verschiedene Mannschaften, und
   * ohne Legende gehört jedes Ergebnis einem unbekannten Gegner (B060).
   */
  function renderPrintMatrixLegend(namen, titel = "Spalten") {
    if (!Array.isArray(namen) || namen.length === 0) {
      return "";
    }

    return `
      <p class="print-matrix-legend">
        <strong>${escapeHtml(titel)}:</strong>
        ${namen.map((name, index) => `<span>${index + 1} ${escapeHtml(typeof name === "string" ? name : name?.name || "")}</span>`).join(" · ")}
      </p>
    `;
  }

  function renderPrintMatrixColGroup(entryCount, includeSummary = false) {
    return `
      <colgroup>
        <col class="print-result-matrix-name-col" />
        ${Array.from({ length: entryCount }, () => '<col class="print-result-matrix-score-col" />').join("")}
        ${includeSummary ? '<col class="print-result-matrix-summary-col" /><col class="print-result-matrix-summary-col" />' : ""}
      </colgroup>
    `;
  }

  function renderPrintMatrixColumnHeaders(entryCount) {
    return Array.from(
      { length: entryCount },
      (_, index) => `<th class="print-result-matrix-number-heading">${index + 1}</th>`
    ).join("");
  }

  function renderPrintMatrixPlayerHeading(player, index) {
    return `
      <th class="print-result-matrix-player-heading">
        <span class="print-matrix-player-number">${index + 1}</span><span class="print-result-matrix-player-name">${escapeHtml(player)}</span>
      </th>
    `;
  }

  function renderPrintRoundRobinMatrixCell(rowIndex, columnIndex, mitSaetzen = true) {
    if (rowIndex === columnIndex) {
      return '<td class="diagonal-cell">X</td>';
    }

    const isMirrored = rowIndex > columnIndex;
    const key = isMirrored ? `${columnIndex}-${rowIndex}` : `${rowIndex}-${columnIndex}`;
    const result = analysis.results?.[key] || "";
    const setScore = activeTournament.roundRobin?.setScores?.[key] || "";
    return renderPrintStaticMatrixScoreCell(
      isMirrored && result ? reverseScore(result) : result,
      isMirrored && setScore ? reverseNormalSetScoreText(setScore) : setScore,
      mitSaetzen
    );
  }

  function renderPrintRoundRobinMatrixSummaryCells(rowIndex) {
    const standing = getRoundRobinStandingForPlayer(rowIndex);

    if (!standing) {
      return '<td class="print-result-matrix-summary-cell">-</td><td class="print-result-matrix-summary-cell">-</td>';
    }

    return `
      <td class="print-result-matrix-summary-cell">
        <strong>${standing.setsWon}:${standing.setsLost}</strong>
        <small>Diff. ${formatSignedValue(standing.setDiff)}</small>
      </td>
      <td class="print-result-matrix-summary-cell">
        <strong>${standing.place}.</strong>
        ${standing.sharedPlace ? "<small>geteilt</small>" : ""}
      </td>
    `;
  }

  function renderPrintTeamResultMatrix(scope = "all") {
    const spalten = analysis.teamBPlayers.length;
    const mitSaetzen = matrixZeigtSatzdetails();

    const raster = `
      <section class="${matrixSeitenKlasse(spalten)}">
        ${renderPrintPageHeader(
          "Einzelmatrix",
          matrixUntertitel(`${analysis.teamAName} stehen in den Zeilen, ${analysis.teamBName} in den Spalten.`, spalten)
        )}
        <div class="table-wrapper print-table-wrapper">
          <table class="stats-table print-result-matrix-table ${matrixNamensSpur(spalten)}">
            ${renderPrintMatrixColGroup(spalten)}
            <thead>
              <tr>
                <th>${escapeHtml(analysis.teamAName)} / ${escapeHtml(analysis.teamBName)}</th>
                ${renderPrintMatrixColumnHeaders(spalten)}
              </tr>
            </thead>
            <tbody>
              ${analysis.teamAPlayers.map((player, rowIndex) => `
                <tr>
                  ${renderPrintMatrixPlayerHeading(player, rowIndex)}
                  ${analysis.teamBPlayers.map((_, columnIndex) => {
                    const key = `${rowIndex}-${columnIndex}`;
                    return renderPrintStaticMatrixScoreCell(
                      activeTournament.team?.results?.[key] || "",
                      activeTournament.team?.setScores?.[key] || "",
                      mitSaetzen
                    );
                  }).join("")}
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
        ${renderPrintMatrixLegend(analysis.teamBPlayers, `Spalten (${analysis.teamBName})`)}
      </section>
    `;

    return `
      ${zeigeRaster(scope) ? raster : ""}
      ${
        zeigeRunden(scope)
          ? `
            ${renderPrintCompactRoundOverview(
              "Einzelrunden",
              analysis.rounds,
              "Alle Einzelrunden ohne Uhrzeit und Tisch, mit ausgeschriebenen Sätzen.",
              "",
              true
            )}
            ${
              analysis.doubleRounds?.length > 0
                ? renderPrintCompactRoundOverview(
                    "Doppelrunden",
                    analysis.doubleRounds,
                    "Alle Doppelrunden ohne Uhrzeit und Tisch.",
                    "double",
                    true
                  )
                : ""
            }
          `
          : ""
      }
    `;
  }

  function renderPrintGroupsResultMatrix(scope = "all") {
    // Die Gruppengröße bestimmt die Spaltenzahl, nicht die Teilnehmerzahl:
    // acht Gruppen à vier Spieler bleiben im Hochformat lesbar.
    const spalten = Math.max(0, ...(analysis.groups || []).map((group) => group.players.length));
    const mitSaetzen = matrixZeigtSatzdetails();

    const raster = `
      <section class="${matrixSeitenKlasse(spalten)}">
        ${renderPrintPageHeader(
          "Gruppen-Ergebnismatrix",
          matrixUntertitel("Aktueller Stand der Gruppenphase.", spalten)
        )}
        <div class="print-group-ranking-stack">
          ${(analysis.groups || []).map((group) => `
            <article class="print-round-card">
              <div class="print-round-card-header">
                <div>
                  <p>${escapeHtml(getPrintTournamentTitle())}</p>
                  <h3>${escapeHtml(group.name)}</h3>
                </div>
                <span>${group.completedMatches}/${group.totalMatches} fertig</span>
              </div>
              <div class="table-wrapper print-table-wrapper">
                <table class="stats-table print-result-matrix-table ${matrixNamensSpur(group.players.length)}">
                  ${renderPrintMatrixColGroup(group.players.length)}
                  <thead>
                    <tr>
                      <th>Teilnehmer</th>
                      ${renderPrintMatrixColumnHeaders(group.players.length)}
                    </tr>
                  </thead>
                  <tbody>
                    ${group.players.map((player, rowIndex) => `
                      <tr>
                        ${renderPrintMatrixPlayerHeading(player.name, rowIndex)}
                        ${group.players.map((_, columnIndex) => renderPrintGroupMatrixCell(group, rowIndex, columnIndex, mitSaetzen)).join("")}
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              </div>
              ${renderPrintMatrixLegend(group.players, "Teilnehmer")}
            </article>
          `).join("")}
        </div>
      </section>
    `;

    return `
      ${zeigeRaster(scope) ? raster : ""}
      ${
        zeigeRunden(scope)
          ? `
            ${renderPrintCompactRoundOverview(
              "Gruppenrunden",
              analysis.groupRoundSchedule || [],
              "Alle Gruppenrunden ohne Uhrzeit und Tisch, mit ausgeschriebenen Sätzen.",
              "group",
              true
            )}
            ${
              analysis.knockoutRounds?.length > 0
                ? renderPrintCompactRoundOverview(
                    "KO-Runden",
                    analysis.knockoutRounds,
                    "Alle KO-Runden ohne Uhrzeit und Tisch.",
                    "knockout",
                    true
                  )
                : ""
            }
          `
          : ""
      }
    `;
  }

  function renderPrintGroupMatrixCell(group, rowIndex, columnIndex, mitSaetzen = true) {
    if (rowIndex === columnIndex) {
      return '<td class="diagonal-cell">X</td>';
    }

    const isMirrored = rowIndex > columnIndex;
    const key = isMirrored
      ? `group-${group.groupIndex}-${columnIndex}-${rowIndex}`
      : `group-${group.groupIndex}-${rowIndex}-${columnIndex}`;
    const result = activeTournament.groupsKnockout?.groupResults?.[key] || "";
    const setScore = activeTournament.groupsKnockout?.groupSetScores?.[key] || "";
    return renderPrintStaticMatrixScoreCell(
      isMirrored && result ? reverseScore(result) : result,
      isMirrored && setScore ? reverseNormalSetScoreText(setScore) : setScore,
      mitSaetzen
    );
  }

  function renderPrintStaticMatrixScoreCell(result, setScore, mitSaetzen = true) {
    return `
      <td>
        <strong>${escapeHtml(result || "-")}</strong>
        ${mitSaetzen && setScore ? `<small>${escapeHtml(setScore)}</small>` : ""}
      </td>
    `;
  }

  function renderPrintCompactRoundOverview(title, rounds, subtitle, resultScope = "", eigeneSeite = false) {
    if (!Array.isArray(rounds) || rounds.length === 0) {
      return "";
    }

    const inhalt = `
      <section class="print-compact-round-section">
        <header>
          <h3>${escapeHtml(title)}</h3>
          <p>${escapeHtml(subtitle)}</p>
        </header>
        <div class="print-compact-round-grid">
          ${rounds.map((round) => renderPrintCompactRoundCard(round, resultScope)).join("")}
        </div>
      </section>
    `;

    // Als eigene Seite, damit „Nur die einzelnen Runden" ein vollständiges
    // Dokument ergibt und nicht ein Rest ohne Kopf.
    return eigeneSeite ? `<section class="print-page">${inhalt}</section>` : inhalt;
  }

  function renderPrintCompactRoundCard(round, resultScope = "") {
    const byePlayers = getRoundByePlayers(round);
    const roundTitle = round.roundName || `${round.roundNumber}. Runde`;

    return `
      <article class="print-compact-round-card">
        <h4>${escapeHtml(roundTitle)}</h4>
        <table class="print-compact-round-table">
          <tbody>
            ${(round.pairings || [])
              .map((pairing) => renderPrintCompactRoundRow(pairing, resultScope))
              .join("")}
            ${byePlayers.map((player) => renderPrintCompactByeRow(player)).join("")}
          </tbody>
        </table>
      </article>
    `;
  }

  function renderPrintCompactRoundRow(pairing, resultScope = "") {
    const setScore = pairing.matchKey
      ? getNormalSetScoreValue(activeTournament, resultScope, pairing.matchKey)
      : "";
    const displaySetScore = pairing.displayReversed && setScore
      ? reverseNormalSetScoreText(setScore)
      : setScore;
    const result = pairing.score || (
      pairing.matchStatus && pairing.matchStatus !== "normal"
        ? pairing.matchStatusLabel
        : "offen"
    );

    return `
      <tr>
        <td>${pairing.contextLabel ? `${escapeHtml(pairing.contextLabel)}: ` : ""}${escapeHtml(pairing.playerA || "")} - ${escapeHtml(pairing.playerB || "")}</td>
        <td>
          <strong>${escapeHtml(result)}</strong>
          ${displaySetScore ? `<small>${escapeHtml(displaySetScore)}</small>` : ""}
        </td>
      </tr>
    `;
  }

  function renderPrintCompactByeRow(player) {
    return `
      <tr class="print-bye-row">
        <td>${renderByePlayerName(player)} spielfrei</td>
        <td><strong>Pause</strong></td>
      </tr>
    `;
  }

  function renderPrintRoundGroup(title, rounds, subtitle, emptyScores) {
    if (!rounds.length) {
      return renderPrintEmptyState(title, "Für dieses Dokument sind keine Runden verfügbar.");
    }

    return `
      <section class="print-page print-round-group">
        ${renderPrintPageHeader(title, subtitle)}
        <div class="print-round-grid">
          ${rounds.map((round) => renderPrintRoundCard(round, emptyScores)).join("")}
        </div>
      </section>
    `;
  }

  function renderPrintRoundCard(round, emptyScores) {
    const byePlayers = getRoundByePlayers(round);
    const status = getRoundStatus(round);

    return `
      <article class="print-round-card">
        <div class="print-round-card-header">
          <div>
            <p>${escapeHtml(getPrintTournamentTitle())}</p>
            <h3>${round.roundNumber}. Runde</h3>
          </div>
          ${emptyScores ? "" : `<span>${escapeHtml(status.label)}</span>`}
        </div>
        <table class="print-match-table">
          <thead>
            <tr>
              <th>Nr.</th>
              <th>Begegnung</th>
              <th>${emptyScores ? "Ergebnis" : "Stand"}</th>
              ${emptyScores ? "<th>Notiz / Unterschrift</th>" : ""}
            </tr>
          </thead>
          <tbody>
            ${(round.pairings || [])
              .map((pairing, index) => renderPrintMatchRow(pairing, index, emptyScores))
              .join("")}
            ${byePlayers.map((player) => renderPrintByeRow(player, emptyScores)).join("")}
          </tbody>
        </table>
      </article>
    `;
  }

  function renderPrintMatchRow(pairing, index, emptyScores) {
    return `
      <tr>
        <td>${index + 1}</td>
        <td>${escapeHtml(pairing.playerA)} - ${escapeHtml(pairing.playerB)}</td>
        <td>
          ${
            emptyScores
              ? '<span class="print-score-box" aria-hidden="true"></span>'
              : escapeHtml(pairing.score || "offen")
          }
        </td>
        ${emptyScores ? '<td><span class="print-note-line" aria-hidden="true"></span></td>' : ""}
      </tr>
    `;
  }

  function renderPrintByeRow(player, emptyScores) {
    return `
      <tr class="print-bye-row">
        <td>-</td>
        <td>${renderByePlayerName(player)} spielfrei</td>
        <td>Pause</td>
        ${emptyScores ? "<td></td>" : ""}
      </tr>
    `;
  }

  function renderPrintRanking() {
    if (isTtRaceTournament()) {
      const ranking = getTtRacePrintRanking();
      if (ranking.length === 0) {
        return renderPrintEmptyState("Rangliste", "Noch keine Schweizer Runde gespielt.");
      }
      return `
        <section class="print-page">
          ${renderPrintPageHeader("Rangliste", "Schweizer-System-Wertung nach Punkten, Siegen und Gegnerpunkten.")}
          <div class="table-wrapper print-table-wrapper">
            ${renderTtRacePrintRankingTable(ranking)}
          </div>
        </section>
      `;
    }

    if (activeTournament.mode === "groupsKnockout") {
      return `
        <section class="print-page">
          ${renderPrintPageHeader("Gruppen-Ranglisten", "Aktueller Stand je Gruppe.")}
          <div class="print-group-ranking-stack">
            ${(analysis.groups || []).map((group) => `
              <article class="print-round-card">
                <div class="print-round-card-header">
                  <div>
                    <p>${escapeHtml(getPrintTournamentTitle())}</p>
                    <h3>${escapeHtml(group.name)}</h3>
                  </div>
                </div>
                <div class="table-wrapper print-table-wrapper">
                  ${renderGroupRankingTable(group.ranking)}
                </div>
              </article>
            `).join("")}
          </div>
        </section>
        ${analysis.finalStandings?.length > 0 ? `
          <section class="print-page">
            ${renderPrintPageHeader("Finalstand", "Endplatzierung aus der KO-Runde.")}
            <div class="table-wrapper print-table-wrapper">
              ${renderFinalStandingsTable(analysis.finalStandings)}
            </div>
          </section>
        ` : ""}
      `;
    }

    if (activeTournament.mode === "team") {
      return `
        <section class="print-page">
          ${renderPrintPageHeader("Teamwertung", "Zusammenfassung der Team-Ergebnisse.")}
          ${renderPrintTeamSummaryTable()}
        </section>
        <section class="print-page">
          ${renderPrintPageHeader("Spieler-Rangliste", "Einzel- und Doppelwertung der Spieler.")}
          <div class="table-wrapper print-table-wrapper">
            ${renderTeamRankingTable(analysis.playerRanking)}
          </div>
        </section>
      `;
    }

    return `
      <section class="print-page">
        ${renderPrintPageHeader("Rangliste", "Aktueller Stand der Spielerwertung.")}
        <div class="table-wrapper print-table-wrapper">
          ${renderRoundRobinRankingTable(analysis.ranking)}
        </div>
      </section>
    `;
  }

  /**
   * Gedruckte TT-Race-Rangliste. Sie führt „Gegner" (Buchholz) mit, weil im
   * Schweizer System dieser Wert bei gleicher Punktzahl entscheidet — eine
   * Rangliste ohne ihn ließe die Reihenfolge unerklärt.
   */
  function renderTtRacePrintRankingTable(ranking) {
    return `
      <table class="stats-table">
        <thead>
          <tr>
            <th>Platz</th>
            <th>Spieler</th>
            <th>Punkte</th>
            <th>Bilanz</th>
            <th>Gegner</th>
            <th>Sätze&nbsp;+</th>
            <th>Sätze&nbsp;−</th>
            <th>Differenz</th>
          </tr>
        </thead>
        <tbody>
          ${ranking
            .map(
              (player) => `
                <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
                  <td>${escapeHtml(formatPrintPlace(player))}</td>
                  <td>${escapeHtml(player.name)}</td>
                  <td>${formatStandingNumber(player.points)}</td>
                  <td>${player.wins}/${player.losses}</td>
                  <td>${formatStandingNumber(player.buchholz)}</td>
                  <td>${player.setsWon}</td>
                  <td>${player.setsLost}</td>
                  <td>${formatSignedValue(player.setDiff)}</td>
                </tr>
              `
            )
            .join("")}
        </tbody>
      </table>
    `;
  }

  function renderPrintTeamSummaryTable() {
    const rows = [
      ["Gewonnene Spiele", analysis.teamSummary.teamA.matchesWon, analysis.teamSummary.teamB.matchesWon],
      ["Unentschiedene Spiele", analysis.teamSummary.teamA.matchesDrawn, analysis.teamSummary.teamB.matchesDrawn],
      ["Verlorene Spiele", analysis.teamSummary.teamA.matchesLost, analysis.teamSummary.teamB.matchesLost],
      ["Sätze +", analysis.teamSummary.teamA.setsWon, analysis.teamSummary.teamB.setsWon],
      ["Sätze −", analysis.teamSummary.teamA.setsLost, analysis.teamSummary.teamB.setsLost],
      ["Differenz", analysis.teamSummary.teamA.setDiff, analysis.teamSummary.teamB.setDiff]
    ];

    if (analysis.teamSummary.hasDoubles) {
      rows.splice(
        3,
        0,
        ["Gewonnene Einzel", analysis.teamSummary.teamA.singlesWon, analysis.teamSummary.teamB.singlesWon],
        ["Gewonnene Doppel", analysis.teamSummary.teamA.doublesWon, analysis.teamSummary.teamB.doublesWon]
      );
    }

    return `
      <div class="table-wrapper print-table-wrapper">
        <table class="stats-table">
          <thead>
            <tr>
              <th>Wertung</th>
              <th>${escapeHtml(analysis.teamAName)}</th>
              <th>${escapeHtml(analysis.teamBName)}</th>
            </tr>
          </thead>
          <tbody>
            ${rows
              .map(
                ([label, teamAValue, teamBValue]) => `
                  <tr>
                    <td>${escapeHtml(label)}</td>
                    <td>${teamAValue}</td>
                    <td>${teamBValue}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      </div>
    `;
  }

  function renderPrintWinners() {
    // Dieselbe Wahrheitsprüfung wie bei den Urkunden (B059): eine Siegerliste
    // über einem unfertigen Turnier nennt Sieger, die es noch nicht gibt.
    if (!istPrintEndstand()) {
      return renderPrintNochOffen("Siegerliste");
    }

    if (isTtRaceTournament()) {
      return `
        <section class="print-page">
          ${renderPrintPageHeader("Siegerliste", "Podestplätze der Schweizer-System-Wertung.")}
          ${renderPrintPodiumTable(getTtRacePrintRanking())}
        </section>
      `;
    }

    if (activeTournament.mode === "groupsKnockout") {
      return `
        <section class="print-page">
          ${renderPrintPageHeader("Siegerliste", "Finale Platzierungen der Gruppen- und KO-Wertung.")}
          <div class="print-winner-grid">
            ${renderPrintWinnerCard("Turniersieger", getPrintChampionName())}
          </div>
          ${analysis.finalStandings?.length > 0 ? renderFinalStandingsTable(analysis.finalStandings.filter((player) => player.place <= 3)) : ""}
        </section>
      `;
    }

    if (activeTournament.mode === "team") {
      return `
        <section class="print-page">
          ${renderPrintPageHeader("Siegerliste Teamwertung", "Gewinner nach Gesamtwertung, Sätzen und Spielen.")}
          <div class="print-winner-grid">
            ${renderPrintWinnerCard("Gesamtsieger", analysis.teamSummary.winner)}
            ${renderPrintWinnerCard("Nach Sätzen", analysis.teamSummary.bySets.winner)}
            ${renderPrintWinnerCard("Nach Spielen", analysis.teamSummary.byMatches.winner)}
          </div>
        </section>
        <section class="print-page">
          ${renderPrintPageHeader("Siegerliste Spieler", "Podestplätze der Spielerwertung.")}
          ${renderPrintPodiumTable(analysis.playerRanking)}
        </section>
      `;
    }

    return `
      <section class="print-page">
        ${renderPrintPageHeader("Siegerliste", "Podestplätze der Spielerwertung.")}
        ${renderPrintPodiumTable(analysis.ranking)}
      </section>
    `;
  }

  function renderPrintWinnerCard(label, winner) {
    return `
      <article class="print-winner-card">
        <span>${escapeHtml(label)}</span>
        <strong>${escapeHtml(winner)}</strong>
      </article>
    `;
  }

  function renderPrintPodiumTable(ranking) {
    const podiumRows = getPrintPodiumRows(ranking);

    if (!podiumRows.length) {
      return renderPrintEmptyState("Siegerliste", "Noch keine Rangliste verfügbar.");
    }

    return `
      <div class="table-wrapper print-table-wrapper">
        <table class="stats-table">
          <thead>
            <tr>
              <th>Platz</th>
              <th>Name</th>
              <th>Bilanz</th>
              <th>Sätze</th>
              <th>Differenz</th>
            </tr>
          </thead>
          <tbody>
            ${podiumRows
              .map(
                (player) => `
                  <tr class="${placeClass(player.place)} ${player.sharedPlace ? "is-tied" : ""}">
                    <td>${escapeHtml(formatPrintPlace(player))}</td>
                    <td>${escapeHtml(player.name)}</td>
                    <td>${getPrintPlayerBalance(player)}</td>
                    <td>${player.setsWon}/${player.setsLost}</td>
                    <td>${player.setDiff}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      </div>
    `;
  }

  /**
   * Ein Endstand ist erst einer, wenn nichts mehr offen ist. Vorher teilten
   * sich vor dem ersten Ergebnis alle Platz 1, und der Urkundendruck warf für
   * jeden Teilnehmer eine „1. geteilt"-Urkunde aus (B059). Gruppen + KO
   * brauchen zusätzlich einen Finalstand — die Gruppenphase allein entscheidet
   * dort nichts.
   */
  function istPrintEndstand() {
    if (activeTournament.mode === "groupsKnockout") {
      return (analysis.finalStandings?.length ?? 0) > 0;
    }

    if (isTournamentClosed()) {
      return true;
    }

    const { gesamt, offen } = getMatchProgress();
    return gesamt > 0 && offen === 0;
  }

  function renderPrintNochOffen(titel) {
    const fortschritt = getMatchProgress();
    const { gesamt, erfasst, offen, einheit } = fortschritt;
    const grund =
      activeTournament.mode === "groupsKnockout"
        ? "Die KO-Runde ist noch nicht entschieden."
        : einheit === "runden"
          ? `Noch ${offen} von ${fortschritt.maxRunden} Runden ausstehend (${fortschritt.gespielteRunden} ausgelost, ${erfasst} Spiele erfasst).`
          : gesamt > 0
            ? `Noch ${offen} von ${gesamt} Spielen offen (${erfasst} erfasst).`
            : "Es ist noch kein Spiel angesetzt.";

    return renderPrintEmptyState(
      titel,
      `Noch offen — ${grund} Erst nach dem letzten Ergebnis steht fest, wer auf die Urkunde gehört.`
    );
  }

  function renderPrintCertificates() {
    if (!istPrintEndstand()) {
      return renderPrintShell("Urkunde / Siegerblatt", renderPrintNochOffen("Urkunde / Siegerblatt"));
    }

    const certificateEntries = getPrintCertificateEntries();

    if (!certificateEntries.length) {
      return renderPrintShell(
        "Urkunde / Siegerblatt",
        renderPrintEmptyState("Urkunde / Siegerblatt", "Noch keine Platzierungen verfügbar.")
      );
    }

    return `
      <article class="print-document-sheet print-certificate-document">
        ${certificateEntries.map((entry) => renderPrintCertificate(entry)).join("")}
      </article>
    `;
  }

  function renderPrintCertificate(entry) {
    return `
      <section class="print-certificate-page">
        <div class="print-certificate-frame">
          <p class="eyebrow">Turnierblatt</p>
          <h1>Urkunde</h1>
          <p class="print-certificate-tournament">${escapeHtml(getPrintTournamentTitle())}</p>
          <div class="print-certificate-placement">${escapeHtml(entry.placeLabel)}</div>
          <strong>${escapeHtml(entry.name)}</strong>
          <p>${escapeHtml(entry.context)}</p>
          <footer>
            <span>Datum: ${escapeHtml(formatPrintDate(new Date()))}</span>
            <span>Unterschrift</span>
          </footer>
        </div>
      </section>
    `;
  }

  function getPrintCertificateEntries() {
    if (isTtRaceTournament()) {
      return getPrintPodiumRows(getTtRacePrintRanking()).map((player) => ({
        placeLabel: formatPrintPlace(player),
        name: player.name,
        context: "TT-Race Schweizer System"
      }));
    }

    if (activeTournament.mode === "groupsKnockout") {
      return (analysis.finalStandings || [])
        .filter((player) => player.place <= 3)
        .map((player) => ({
          placeLabel: `${player.place}. Platz`,
          name: player.name,
          context: "Gruppen- und KO-Wertung"
        }));
    }

    if (activeTournament.mode === "team") {
      const entries = [];
      if (analysis.teamSummary.winner && analysis.teamSummary.winner !== "Unentschieden") {
        entries.push({
          placeLabel: "1. Platz Teamwertung",
          name: analysis.teamSummary.winner,
          context: "Siegerteam"
        });
      }

      return [
        ...entries,
        ...getPrintPodiumRows(analysis.playerRanking).map((player) => ({
          placeLabel: formatPrintPlace(player),
          name: player.name,
          context: `Spielerwertung - ${player.team}`
        }))
      ];
    }

    return getPrintPodiumRows(analysis.ranking).map((player) => ({
      placeLabel: formatPrintPlace(player),
      name: player.name,
      context: "Spielerwertung"
    }));
  }

  function getPrintPodiumRows(ranking) {
    return ranking.filter((player) => player.place <= 3);
  }

  function getPrintPlayerBalance(player) {
    // Im TT-Race steht die Bilanz auch bei fester Satzzahl (win3) fest — sie
    // kommt aus der Schweizer Wertung, nicht aus der Satzrechnung.
    if (isTtRaceTournament()) {
      return `${player.wins}/${player.losses}`;
    }

    if (activeTournament.mode === "groupsKnockout" && player.seedLabel) {
      return player.seedLabel;
    }

    if (isFixedSetMatchMode(analysis.matchMode)) {
      return "-";
    }

    if (activeTournament.mode === "team") {
      return `${player.matchesWon}/${player.matchesLost}`;
    }

    return `${player.wins}/${player.losses}`;
  }

  function getPrintChampionName() {
    if (!analysis.champion) {
      return "Noch offen";
    }

    return typeof analysis.champion === "string" ? analysis.champion : analysis.champion.name;
  }

  function formatPrintPlace(player) {
    return `${player.place}.${player.sharedPlace ? " geteilt" : ""}`;
  }

  function renderPrintPageHeader(title, subtitle) {
    return `
      <header class="print-page-header">
        <div>
          <p class="eyebrow">${escapeHtml(getPrintTournamentTitle())}</p>
          <h2>${escapeHtml(title)}</h2>
        </div>
        <p>${escapeHtml(subtitle)}</p>
      </header>
    `;
  }

  function renderPrintEmptyState(title, message) {
    return `
      <section class="print-page">
        ${renderPrintPageHeader(title, message)}
      </section>
    `;
  }

  function getPrintTournamentTitle() {
    return (
      analysis.tournamentName ||
      activeTournament.tournamentName?.trim() ||
      getTournamentLabel(activeTournament, getActiveTournamentIndex())
    );
  }

  function formatPrintDate(date) {
    return date.toLocaleDateString("de-DE", {
      day: "2-digit",
      month: "long",
      year: "numeric"
    });
  }

  function handleParticipantImportTextInput(event) {
    const targetKey = event.target.dataset.importText;
    const draft = getParticipantImportDraft(activeTournament.id)[targetKey];
    if (!draft) {
      return;
    }

    draft.text = event.target.value;
    const parsed = parseParticipantImportText(draft.text);
    if (isTeamImportTarget(targetKey) && parsed.teamName && !draft.teamName.trim()) {
      draft.teamName = parsed.teamName;
    }
    refreshParticipantImportPreview(targetKey);
  }

  async function handleParticipantImportFileSelection(event) {
    const targetKey = event.target.dataset.importFile;
    const draft = getParticipantImportDraft(activeTournament.id)[targetKey];
    const file = event.target.files?.[0];
    event.target.value = "";

    if (!draft || !file) {
      return;
    }

    try {
      draft.text = await file.text();
      draft.fileName = file.name;
      const parsed = parseParticipantImportText(draft.text);
      if (isTeamImportTarget(targetKey) && parsed.teamName) {
        draft.teamName = parsed.teamName;
      }

      const panel = configDetails.querySelector('[data-import-panel="' + targetKey + '"]');
      const textarea = panel?.querySelector('[data-import-text="' + targetKey + '"]');
      const teamNameInput = panel?.querySelector('[data-import-team-name="' + targetKey + '"]');
      if (textarea) {
        textarea.value = draft.text;
      }
      if (teamNameInput) {
        teamNameInput.value = draft.teamName;
      }
      refreshParticipantImportPreview(targetKey);
      showInfo(file.name + " wurde geladen. Prüfe die Vorschau und übernimm die Teilnehmer danach.");
    } catch (error) {
      console.error("Teilnehmerdatei konnte nicht gelesen werden.", error);
      showInfo("Die Datei konnte nicht gelesen werden. Bitte eine CSV- oder Textdatei wählen.");
    }
  }

  function handleParticipantImportTeamNameInput(event) {
    const targetKey = event.target.dataset.importTeamName;
    const draft = getParticipantImportDraft(activeTournament.id)[targetKey];
    if (!draft) {
      return;
    }

    draft.teamName = event.target.value;
    refreshParticipantImportPreview(targetKey);
  }

  function handleParticipantImportDuplicateOption(event) {
    const targetKey = event.target.dataset.importNumberDuplicates;
    const draft = getParticipantImportDraft(activeTournament.id)[targetKey];
    if (!draft) {
      return;
    }

    draft.numberDuplicates = event.target.checked;
    refreshParticipantImportPreview(targetKey);
  }

  function handleClearParticipantImport(event) {
    const targetKey = event.currentTarget.dataset.importClear;
    const draft = getParticipantImportDraft(activeTournament.id)[targetKey];
    if (!draft) {
      return;
    }

    Object.assign(draft, createParticipantImportTargetDraft());
    renderConfig();
  }

  function handleApplyParticipantImport(event) {
    const targetKey = event.currentTarget.dataset.importApply;
    const preview = getParticipantImportPreview(targetKey);

    if (preview.applyNames.length === 0) {
      showInfo("Bitte zuerst Namen einfügen oder eine CSV-Datei laden.");
      return;
    }

    if (activeTournamentHasStoredResults()) {
      const shouldContinue = window.confirm(
        "Im aktiven Turnier sind bereits Ergebnisse eingetragen.\n\n" +
          "Beim Teilnehmer-Import werden diese Ergebnisse gelöscht, damit keine alten Resultate falschen Namen zugeordnet werden. Fortfahren?"
      );

      if (!shouldContinue) {
        showInfo("Import abgebrochen. Die vorhandenen Ergebnisse bleiben erhalten.");
        return;
      }
    }

    const importedNames = preview.applyNames;
    updateActiveTournament((tournament) => {
      if (targetKey === "roundRobin") {
        const count = clampCount(importedNames.length);
        tournament.roundRobin.playerCount = count;
        tournament.roundRobin.playerNames = ensureLength(importedNames.slice(0, count), count, "Spieler");
        tournament.roundRobin.playerStatuses = ensureLength([], count, "active");
        tournament.roundRobin.currentRound = clampPositiveInteger(
          tournament.roundRobin.currentRound,
          1,
          getRoundRobinRoundCount(count)
        );
        tournament.roundRobin.results = {};
        tournament.roundRobin.setScores = {};
        tournament.roundRobin.matchStatuses = {};
        return;
      }

      const count = clampCount(importedNames.length);
      if (targetKey === "teamA") {
        tournament.team.teamACount = count;
        tournament.team.teamAPlayers = ensureLength(importedNames.slice(0, count), count, "Spieler A");
        tournament.team.teamAPlayerStatuses = ensureLength([], count, "active");
        if (preview.teamName) {
          tournament.team.teamAName = preview.teamName;
        }
      }

      if (targetKey === "teamB") {
        tournament.team.teamBCount = count;
        tournament.team.teamBPlayers = ensureLength(importedNames.slice(0, count), count, "Spieler B");
        tournament.team.teamBPlayerStatuses = ensureLength([], count, "active");
        if (preview.teamName) {
          tournament.team.teamBName = preview.teamName;
        }
      }

      tournament.team.results = {};
      tournament.team.setScores = {};
      tournament.team.matchStatuses = {};
      tournament.team.doubleResults = {};
      tournament.team.doubleSetScores = {};
      tournament.team.doubleMatchStatuses = {};
      tournament.team.doubleRoundStates = [];
      tournament.team.currentRound = clampPositiveInteger(
        tournament.team.currentRound,
        1,
        getTeamRoundCount(tournament.team.teamACount, tournament.team.teamBCount)
      );
      tournament.team.currentDoubleRound = 1;
    }, "Teilnehmer importiert");

    showInfo(preview.applyNames.length + " Teilnehmer wurden übernommen.");
  }

  /**
   * Drei Einstellungen bei Gruppen + KO werfen die erfassten Ergebnisse weg,
   * weil sich mit ihnen die Gruppenzugehörigkeit ändert und alte Resultate
   * sonst falschen Paarungen zugeordnet würden. Das ist richtig — aber bisher
   * geschah es ohne ein Wort, beim bloßen Klick auf den Pfeil eines
   * Zahlenfeldes. Der Import fragt an derselben Stelle längst nach; hier zieht
   * dieselbe Regel ein, plus eine Sicherung, die das Neuladen überlebt.
   */
  const DESTRUCTIVE_CONFIG_ACTIONS = {
    groupsKnockoutCount: "die Teilnehmerzahl",
    groupsKnockoutGroupCount: "die Anzahl der Gruppen",
    groupsKnockoutQualifiers: "die Zahl der Qualifikanten"
  };

  /**
   * B107/B108-Randfund: Auch im Jeder-gegen-jeden schneidet ein kleinerer
   * Teilnehmerwert Namen UND Ergebnisse weg. Bisher passierte das
   * kommentarlos; gewarnt wurde nur in Gruppen + KO.
   */
  function confirmShrinkingRoundRobinCount(action, feld) {
    if (action !== "roundRobinCount" || activeTournament.mode !== "roundRobin") {
      return true;
    }

    const nextCount = clampCount(feld?.value);
    const currentCount = clampCount(activeTournament.roundRobin.playerCount);
    if (nextCount >= currentCount || !activeTournamentHasStoredResults()) {
      return true;
    }

    const entfallen = currentCount - nextCount;
    const shouldContinue = window.confirm(
      `Es sind bereits Ergebnisse eingetragen.\n\n` +
        `Von ${currentCount} auf ${nextCount} Teilnehmer zu gehen entfernt ${entfallen} ` +
        `Teilnehmer samt ihren Ergebnissen.\n\nVorher wird eine Sicherung des jetzigen ` +
        `Standes abgelegt. Fortfahren?`
    );

    if (!shouldContinue) {
      showInfo("Änderung abgebrochen. Die eingetragenen Ergebnisse bleiben erhalten.");
      return false;
    }

    storeRoundCheckpoint("Vor Verkleinerung des Teilnehmerfelds");
    return true;
  }

  function confirmDestructiveConfigChange(action) {
    const label = DESTRUCTIVE_CONFIG_ACTIONS[action];
    if (!label || activeTournament.mode !== "groupsKnockout") {
      return true;
    }
    if (!activeTournamentHasStoredResults()) {
      return true;
    }

    const shouldContinue = window.confirm(
      `Es sind bereits Ergebnisse eingetragen.\n\n` +
        `Wenn du ${label} änderst, werden die Gruppen neu gebildet und die erfassten ` +
        `Ergebnisse gelöscht — sonst hingen sie an Paarungen, die es nicht mehr gibt.\n\n` +
        `Vorher wird eine Sicherung des jetzigen Standes abgelegt. Fortfahren?`
    );

    if (!shouldContinue) {
      showInfo("Änderung abgebrochen. Die eingetragenen Ergebnisse bleiben erhalten.");
      return false;
    }

    storeRoundCheckpoint("Vor Änderung der Gruppeneinteilung");
    return true;
  }

  function handleConfigInput(event) {
    const action = event.target.dataset.action;
    if (!action) {
      return;
    }

    const duplicateError = validateUniquePlayerNameChange(action, event.target);
    if (duplicateError) {
      renderConfig();
      showInfo(duplicateError);
      return;
    }

    if (!confirmDestructiveConfigChange(action)) {
      renderConfig();
      return;
    }

    if (!confirmShrinkingRoundRobinCount(action, event.target)) {
      renderConfig();
      return;
    }

    let feedbackMessage = "";
    updateActiveTournament((tournament) => {
      switch (action) {
        case "tournamentName":
          tournament.tournamentName = event.target.value;
          tournament.tabName = event.target.value;
          break;
        case "roundRobinCount": {
          const rawValue = Number.parseInt(event.target.value, 10);
          const nextCount = clampCount(event.target.value);
          tournament.roundRobin.playerCount = nextCount;
          // B107: Als einziger der vier Modi zog dieser Zweig die Namensliste
          // nicht mit. Die Anzeige klammerte das ab, die Neuauslosung nicht:
          // `shuffleRoundRobinDraw` mischte die alte, längere Liste — ein
          // entfernter Teilnehmer kehrte zurück, ein echter verschwand.
          tournament.roundRobin.playerNames = ensureLength(
            tournament.roundRobin.playerNames,
            nextCount,
            "Spieler"
          );
          tournament.roundRobin.playerStatuses = ensureLength(
            tournament.roundRobin.playerStatuses,
            nextCount,
            "active"
          );
          tournament.roundRobin.currentRound = clampPositiveInteger(
            tournament.roundRobin.currentRound,
            1,
            getRoundRobinRoundCount(nextCount)
          );
          tournament.roundRobin.results = trimRoundRobinResults(tournament.roundRobin.results || {}, nextCount);
          tournament.roundRobin.setScores = trimRoundRobinResults(tournament.roundRobin.setScores || {}, nextCount);
          tournament.roundRobin.matchStatuses = trimRoundRobinResults(tournament.roundRobin.matchStatuses || {}, nextCount);
          if (rawValue !== nextCount) {
            feedbackMessage = "Die Teilnehmerzahl wurde auf den erlaubten Bereich von 2 bis 100 gesetzt.";
          }
          break;
        }
        case "groupsKnockoutCount": {
          const rawValue = Number.parseInt(event.target.value, 10);
          const nextCount = clampCount(event.target.value, 4, 100);
          tournament.groupsKnockout.playerCount = nextCount;
          tournament.groupsKnockout.playerNames = ensureLength(
            tournament.groupsKnockout.playerNames,
            nextCount,
            "Spieler"
          );
          tournament.groupsKnockout.groupCount = clampPositiveInteger(
            tournament.groupsKnockout.groupCount,
            2,
            Math.max(2, Math.floor(nextCount / 2))
          );
          tournament.groupsKnockout.qualifiersPerGroup = clampPositiveInteger(
            tournament.groupsKnockout.qualifiersPerGroup,
            1,
            Math.max(1, Math.floor(nextCount / tournament.groupsKnockout.groupCount))
          );
          tournament.groupsKnockout.currentGroupRound = clampPositiveInteger(
            tournament.groupsKnockout.currentGroupRound,
            1,
            getGroupsKnockoutGroupRoundCount(nextCount, tournament.groupsKnockout.groupCount)
          );
          tournament.groupsKnockout.currentKnockoutRound = 1;
          tournament.groupsKnockout.groupResults = {};
          tournament.groupsKnockout.groupSetScores = {};
          tournament.groupsKnockout.knockoutResults = {};
          tournament.groupsKnockout.knockoutSetScores = {};
          if (rawValue !== nextCount) {
            feedbackMessage = "Die Teilnehmerzahl wurde auf den erlaubten Bereich von 4 bis 100 gesetzt.";
          }
          break;
        }
        case "groupsKnockoutGroupCount": {
          const maxGroups = Math.max(2, Math.floor(tournament.groupsKnockout.playerCount / 2));
          const nextCount = clampPositiveInteger(event.target.value, 2, maxGroups);
          tournament.groupsKnockout.groupCount = nextCount;
          tournament.groupsKnockout.qualifiersPerGroup = clampPositiveInteger(
            tournament.groupsKnockout.qualifiersPerGroup,
            1,
            Math.max(1, Math.floor(tournament.groupsKnockout.playerCount / nextCount))
          );
          tournament.groupsKnockout.currentGroupRound = clampPositiveInteger(
            tournament.groupsKnockout.currentGroupRound,
            1,
            getGroupsKnockoutGroupRoundCount(tournament.groupsKnockout.playerCount, nextCount)
          );
          tournament.groupsKnockout.currentKnockoutRound = 1;
          tournament.groupsKnockout.groupResults = {};
          tournament.groupsKnockout.groupSetScores = {};
          tournament.groupsKnockout.knockoutResults = {};
          tournament.groupsKnockout.knockoutSetScores = {};
          break;
        }
        case "groupsKnockoutQualifiers": {
          const maxQualifiers = Math.max(
            1,
            Math.floor(tournament.groupsKnockout.playerCount / tournament.groupsKnockout.groupCount)
          );
          tournament.groupsKnockout.qualifiersPerGroup = clampPositiveInteger(
            event.target.value,
            1,
            maxQualifiers
          );
          tournament.groupsKnockout.currentKnockoutRound = 1;
          tournament.groupsKnockout.knockoutResults = {};
          tournament.groupsKnockout.knockoutSetScores = {};
          break;
        }
        case "groupsKnockoutPlacement":
          // Segmentschalter liefert einen Wert, die frühere Checkbox checked.
          tournament.groupsKnockout.placementMatchesEnabled =
            event.target.type === "checkbox" ? Boolean(event.target.checked) : event.target.value === "yes";
          break;
        case "groupsKnockoutName":
          tournament.groupsKnockout.playerNames[Number(event.target.dataset.index)] = event.target.value;
          if (!event.target.value.trim()) {
            feedbackMessage = "Ein leerer Name wurde automatisch durch einen Platzhalter ersetzt.";
          }
          break;
        case "matchMode":
          tournament.matchMode = event.target.value;
          tournament.roundRobin.setScores = {};
          tournament.team.setScores = {};
          tournament.team.doubleSetScores = {};
          tournament.groupsKnockout.groupSetScores = {};
          tournament.groupsKnockout.knockoutSetScores = {};
          break;
        case "scheduleFieldCount": {
          const rawValue = Number.parseInt(event.target.value, 10);
          const nextCount = clampPositiveInteger(event.target.value, 1, 20);
          tournament.schedule.fieldCount = nextCount;
          tournament.schedule.fieldNames = ensureLength(
            tournament.schedule.fieldNames,
            nextCount,
            "Tisch"
          );
          if (rawValue !== nextCount) {
            feedbackMessage = "Die Tischanzahl wurde auf den erlaubten Bereich von 1 bis 20 gesetzt.";
          }
          break;
        }
        case "scheduleStartTime":
          tournament.schedule.startTime = event.target.value;
          break;
        case "scheduleMatchDuration": {
          const rawValue = Number.parseInt(event.target.value, 10);
          const nextDuration = clampPositiveInteger(event.target.value, 1, 240);
          tournament.schedule.matchDurationMinutes = nextDuration;
          if (rawValue !== nextDuration) {
            feedbackMessage = "Die Spieldauer wurde auf den erlaubten Bereich von 1 bis 240 Minuten gesetzt.";
          }
          break;
        }
        case "scheduleBreak": {
          const rawValue = Number.parseInt(event.target.value, 10);
          const nextBreak = clampPositiveInteger(event.target.value, 0, 120);
          tournament.schedule.breakMinutes = nextBreak;
          if (rawValue !== nextBreak) {
            feedbackMessage = "Der Puffer wurde auf den erlaubten Bereich von 0 bis 120 Minuten gesetzt.";
          }
          break;
        }
        case "scheduleFieldName":
          tournament.schedule.fieldNames[Number(event.target.dataset.index)] = event.target.value;
          if (!event.target.value.trim()) {
            feedbackMessage = "Ein leerer Tischname wurde automatisch durch einen Platzhalter ersetzt.";
          }
          break;
        case "scoringWinPoints":
          tournament.scoring.winPoints = event.target.value;
          break;
        case "scoringDrawPoints":
          tournament.scoring.drawPoints = event.target.value;
          break;
        case "scoringLossPoints":
          tournament.scoring.lossPoints = event.target.value;
          break;
        case "scoringTieBreak":
          setTieBreakCriterion(tournament.scoring, Number(event.target.dataset.index), event.target.value);
          break;
        case "roundRobinName":
          tournament.roundRobin.playerNames[Number(event.target.dataset.index)] = event.target.value;
          if (!event.target.value.trim()) {
            feedbackMessage = "Ein leerer Name wurde automatisch durch einen Platzhalter ersetzt.";
          }
          break;
        case "roundRobinStatus":
          tournament.roundRobin.playerStatuses[Number(event.target.dataset.index)] = event.target.value;
          break;
        case "teamAName":
          tournament.team.teamAName = event.target.value;
          break;
        case "teamBName":
          tournament.team.teamBName = event.target.value;
          break;
        case "teamACount": {
          const rawValue = Number.parseInt(event.target.value, 10);
          const nextCount = clampCount(event.target.value);
          tournament.team.teamACount = nextCount;
          tournament.team.teamAPlayers = ensureLength(
            tournament.team.teamAPlayers,
            nextCount,
            "Spieler A"
          );
          tournament.team.teamAPlayerStatuses = ensureLength(
            tournament.team.teamAPlayerStatuses,
            nextCount,
            "active"
          );
          tournament.team.results = trimTeamResults(
            tournament.team.results,
            tournament.team.teamACount,
            tournament.team.teamBCount
          );
          tournament.team.setScores = trimTeamResults(
            tournament.team.setScores || {},
            tournament.team.teamACount,
            tournament.team.teamBCount
          );
          tournament.team.matchStatuses = trimTeamResults(
            tournament.team.matchStatuses,
            tournament.team.teamACount,
            tournament.team.teamBCount
          );
          tournament.team.currentRound = clampPositiveInteger(
            tournament.team.currentRound,
            1,
            getTeamRoundCount(tournament.team.teamACount, tournament.team.teamBCount)
          );
          if (rawValue !== nextCount) {
            feedbackMessage = "Die Teamgröße von Team A wurde auf den erlaubten Bereich von 2 bis 100 gesetzt.";
          }
          break;
        }
        case "teamBCount": {
          const rawValue = Number.parseInt(event.target.value, 10);
          const nextCount = clampCount(event.target.value);
          tournament.team.teamBCount = nextCount;
          tournament.team.teamBPlayers = ensureLength(
            tournament.team.teamBPlayers,
            nextCount,
            "Spieler B"
          );
          tournament.team.teamBPlayerStatuses = ensureLength(
            tournament.team.teamBPlayerStatuses,
            nextCount,
            "active"
          );
          tournament.team.results = trimTeamResults(
            tournament.team.results,
            tournament.team.teamACount,
            tournament.team.teamBCount
          );
          tournament.team.setScores = trimTeamResults(
            tournament.team.setScores || {},
            tournament.team.teamACount,
            tournament.team.teamBCount
          );
          tournament.team.matchStatuses = trimTeamResults(
            tournament.team.matchStatuses,
            tournament.team.teamACount,
            tournament.team.teamBCount
          );
          tournament.team.currentRound = clampPositiveInteger(
            tournament.team.currentRound,
            1,
            getTeamRoundCount(tournament.team.teamACount, tournament.team.teamBCount)
          );
          if (rawValue !== nextCount) {
            feedbackMessage = "Die Teamgröße von Team B wurde auf den erlaubten Bereich von 2 bis 100 gesetzt.";
          }
          break;
        }
        case "teamAPlayer":
          tournament.team.teamAPlayers[Number(event.target.dataset.index)] = event.target.value;
          if (!event.target.value.trim()) {
            feedbackMessage = "Ein leerer Name in Team A wurde automatisch durch einen Platzhalter ersetzt.";
          }
          break;
        case "teamAPlayerStatus":
          tournament.team.teamAPlayerStatuses[Number(event.target.dataset.index)] = event.target.value;
          break;
        case "teamBPlayer":
          tournament.team.teamBPlayers[Number(event.target.dataset.index)] = event.target.value;
          if (!event.target.value.trim()) {
            feedbackMessage = "Ein leerer Name in Team B wurde automatisch durch einen Platzhalter ersetzt.";
          }
          break;
        case "teamBPlayerStatus":
          tournament.team.teamBPlayerStatuses[Number(event.target.dataset.index)] = event.target.value;
          break;
        case "doubleTeamAPlayer1":
        case "doubleTeamAPlayer2":
        case "doubleTeamBPlayer1":
        case "doubleTeamBPlayer2": {
          const entry = tournament.team.doubles.find(
            (doubleEntry) => doubleEntry.id === event.target.dataset.doubleId
          );
          if (entry) {
            const field =
              action === "doubleTeamAPlayer1"
                ? "teamAPlayer1"
                : action === "doubleTeamAPlayer2"
                  ? "teamAPlayer2"
                  : action === "doubleTeamBPlayer1"
                    ? "teamBPlayer1"
                    : "teamBPlayer2";
            entry[field] = event.target.value;
          }
          break;
        }
        default:
          break;
      }
    }, "Konfiguration gespeichert");

    if (feedbackMessage) {
      showInfo(feedbackMessage);
    }
  }

  function getMatchSetRequirement(matchMode) {
    const modeId = MATCH_MODES[matchMode] ? matchMode : "win3";
    if (modeId.startsWith("fixed")) {
      return {
        type: "fixed",
        totalSets: clampPositiveInteger(modeId.slice(5), 1, 9)
      };
    }
    return {
      type: "winning",
      setsToWin: clampPositiveInteger(modeId.slice(3), 1, 9)
    };
  }

  function expandShortSetScoreToken(token) {
    const match = String(token).trim().match(/^([+-]?)(\d+)$/);
    if (!match) {
      return null;
    }

    const sign = match[1];
    const loserScore = Number(match[2]);
    const winnerScore = loserScore >= 10 ? loserScore + 2 : 11;
    return sign === "-" ? [loserScore, winnerScore] : [winnerScore, loserScore];
  }

  function parseNormalSetScoreText(value) {
    const text = String(value ?? "").trim();
    const errors = [];
    const sets = [];

    if (!text) {
      return { sets, errors };
    }

    const tokenPattern = /(\d+\s*[:-]\s*\d+|[+-]?\d+)/g;
    let cursor = 0;
    let match = tokenPattern.exec(text);

    while (match) {
      const separator = text.slice(cursor, match.index);
      if ((cursor > 0 && !separator) || (separator && !/^[\s,;|/]+$/.test(separator))) {
        errors.push(NORMAL_SET_SCORE_INPUT_HINT);
        break;
      }

      const token = match[0].trim();
      const scoreMatch = token.match(/^(\d+)\s*[:-]\s*(\d+)$/);
      const parsedSet = scoreMatch
        ? [Number(scoreMatch[1]), Number(scoreMatch[2])]
        : expandShortSetScoreToken(token);

      if (!parsedSet) {
        errors.push(NORMAL_SET_SCORE_INPUT_HINT);
        break;
      }

      sets.push({ a: parsedSet[0], b: parsedSet[1] });
      cursor = tokenPattern.lastIndex;
      match = tokenPattern.exec(text);
    }

    const tail = text.slice(cursor);
    if (tail && !/^[\s,;|/]+$/.test(tail)) {
      errors.push(NORMAL_SET_SCORE_INPUT_HINT);
    }

    if (sets.length === 0 && errors.length === 0) {
      errors.push("Bitte mindestens einen Satz als 11:7 oder kurz 7 eingeben.");
    }

    return { sets, errors: [...new Set(errors)] };
  }

  function validateNormalSingleSet(set, setNumber) {
    const errors = [];
    const left = set.a;
    const right = set.b;
    const winnerScore = Math.max(left, right);
    const loserScore = Math.min(left, right);

    if (!Number.isInteger(left) || !Number.isInteger(right) || left < 0 || right < 0) {
      errors.push(`Satz ${setNumber}: Nur ganze, positive Punktzahlen sind erlaubt.`);
      return errors;
    }

    if (left === right) {
      errors.push(`Satz ${setNumber}: Ein Satz darf nicht unentschieden enden.`);
      return errors;
    }

    if (winnerScore < 11) {
      errors.push(`Satz ${setNumber}: Ein Satz endet frühestens bei 11 Punkten.`);
    }

    if (winnerScore - loserScore < 2) {
      errors.push(`Satz ${setNumber}: Ein Satz muss mit mindestens zwei Punkten Abstand enden.`);
    }

    if (winnerScore > 11 && loserScore !== winnerScore - 2) {
      errors.push(`Satz ${setNumber}: ${left}:${right} ist kein gültiger Satz. Ab 12 Punkten sind nur 12:10, 13:11 usw. erlaubt.`);
    }

    return errors;
  }

  function deriveMatchScoreFromSetScoreText(value, matchMode, options = {}) {
    const parsed = parseNormalSetScoreText(value);
    const errors = [...parsed.errors];
    const requirement = getMatchSetRequirement(matchMode);
    let leftSets = 0;
    let rightSets = 0;
    let matchEndedAfterSet = 0;

    parsed.sets.forEach((set, index) => {
      const setNumber = index + 1;
      if (matchEndedAfterSet > 0 && requirement.type === "winning") {
        errors.push(`Nach Satz ${matchEndedAfterSet} war das Match bereits entschieden.`);
        return;
      }

      errors.push(...validateNormalSingleSet(set, setNumber));
      if (set.a > set.b) {
        leftSets += 1;
      } else if (set.b > set.a) {
        rightSets += 1;
      }

      if (
        requirement.type === "winning" &&
        (leftSets === requirement.setsToWin || rightSets === requirement.setsToWin)
      ) {
        matchEndedAfterSet = setNumber;
      }
    });

    if (requirement.type === "winning") {
      const maxSets = requirement.setsToWin * 2 - 1;
      if (parsed.sets.length > maxSets) {
        errors.push(`Ein Match auf ${requirement.setsToWin} Gewinnsätze hat maximal ${maxSets} Sätze.`);
      }
      if (leftSets !== requirement.setsToWin && rightSets !== requirement.setsToWin) {
        errors.push(`Bitte das komplette Match bis ${requirement.setsToWin} Gewinnsätze eingeben.`);
      }
    } else if (parsed.sets.length !== requirement.totalSets) {
      errors.push(`Bitte genau ${requirement.totalSets} Sätze eingeben.`);
    }

    const matchScore = `${leftSets}:${rightSets}`;
    if (options.disallowDraw && leftSets === rightSets) {
      errors.push("KO-Spiele dürfen nicht unentschieden enden.");
    }
    if (!isScoreCompatibleWithMode(matchScore, matchMode)) {
      errors.push(`Das berechnete Ergebnis ${matchScore} passt nicht zum gewählten Spielmodus.`);
    }

    return {
      valid: errors.length === 0,
      errors: [...new Set(errors)],
      matchScore,
      normalizedText: formatNormalSetScoreText(parsed.sets)
    };
  }

  function formatNormalSetScoreText(sets) {
    return (sets || []).map((set) => `${set.a}:${set.b}`).join(", ");
  }

  function reverseNormalSetScoreText(value) {
    const parsed = parseNormalSetScoreText(value);
    if (parsed.errors.length > 0) {
      return value || "";
    }
    return formatNormalSetScoreText(parsed.sets.map((set) => ({ a: set.b, b: set.a })));
  }

  function getNormalSetScorePlaceholder() {
    const requirement = getMatchSetRequirement(activeTournament.matchMode);
    if (requirement.type === "fixed") {
      return requirement.totalSets === 3 ? "7, -9, 8" : "7, -9";
    }
    return "7, 9, 5";
  }

  function getNormalSetScoreValue(tournament, resultScope, key) {
    return getNormalSetScoreMap(tournament, resultScope)?.[key] || "";
  }

  function getNormalSetScoreMap(tournament, resultScope) {
    if (!tournament) {
      return {};
    }

    if (tournament.mode === "team") {
      return resultScope === "double"
        ? tournament.team.doubleSetScores || {}
        : tournament.team.setScores || {};
    }

    if (tournament.mode === "groupsKnockout") {
      return resultScope === "knockout"
        ? tournament.groupsKnockout.knockoutSetScores || {}
        : tournament.groupsKnockout.groupSetScores || {};
    }

    return tournament.roundRobin.setScores || {};
  }

  function ensureNormalSetScoreMap(tournament, resultScope) {
    if (tournament.mode === "team") {
      if (resultScope === "double") {
        tournament.team.doubleSetScores = tournament.team.doubleSetScores || {};
        return tournament.team.doubleSetScores;
      }
      tournament.team.setScores = tournament.team.setScores || {};
      return tournament.team.setScores;
    }

    if (tournament.mode === "groupsKnockout") {
      if (resultScope === "knockout") {
        tournament.groupsKnockout.knockoutSetScores = tournament.groupsKnockout.knockoutSetScores || {};
        return tournament.groupsKnockout.knockoutSetScores;
      }
      tournament.groupsKnockout.groupSetScores = tournament.groupsKnockout.groupSetScores || {};
      return tournament.groupsKnockout.groupSetScores;
    }

    tournament.roundRobin.setScores = tournament.roundRobin.setScores || {};
    return tournament.roundRobin.setScores;
  }

  function getResultMapForScope(tournament, resultScope) {
    if (tournament.mode === "team") {
      return resultScope === "double" ? tournament.team.doubleResults : tournament.team.results;
    }

    if (tournament.mode === "groupsKnockout") {
      return resultScope === "knockout"
        ? tournament.groupsKnockout.knockoutResults
        : tournament.groupsKnockout.groupResults;
    }

    return tournament.roundRobin.results;
  }

  /**
   * B106: Für Gruppen + KO gab es hier keinen Zweig — `null` kam zurück und
   * jede Sonderstatus-Wahl in einem Gruppen- oder KO-Spiel starb still an einem
   * TypeError. Die beiden Karten heißen wie ihre Ergebnis-Geschwister und
   * entstehen beim ersten Schreiben, falls ein alter Stand sie nicht kennt.
   */
  function getStatusMapForScope(tournament, resultScope) {
    if (!tournament) {
      return null;
    }

    if (tournament.mode === "team") {
      return resultScope === "double" ? tournament.team.doubleMatchStatuses : tournament.team.matchStatuses;
    }

    if (tournament.mode === "roundRobin") {
      return tournament.roundRobin.matchStatuses;
    }

    if (tournament.mode === "groupsKnockout") {
      if (resultScope === "knockout") {
        tournament.groupsKnockout.knockoutMatchStatuses = tournament.groupsKnockout.knockoutMatchStatuses || {};
        return tournament.groupsKnockout.knockoutMatchStatuses;
      }
      tournament.groupsKnockout.groupMatchStatuses = tournament.groupsKnockout.groupMatchStatuses || {};
      return tournament.groupsKnockout.groupMatchStatuses;
    }

    return null;
  }

  /** Lesende Fassung: legt nichts an, damit ein Blick den Stand nicht ändert. */
  function readMatchStatusValue(tournament, resultScope, key) {
    if (!tournament || !key) {
      return "normal";
    }

    const maps = {
      team: resultScope === "double" ? tournament.team?.doubleMatchStatuses : tournament.team?.matchStatuses,
      roundRobin: tournament.roundRobin?.matchStatuses,
      groupsKnockout:
        resultScope === "knockout"
          ? tournament.groupsKnockout?.knockoutMatchStatuses
          : tournament.groupsKnockout?.groupMatchStatuses
    };

    return maps[tournament.mode]?.[key] || "normal";
  }

  function deleteNormalSetScore(tournament, resultScope, key) {
    const setScores = ensureNormalSetScoreMap(tournament, resultScope);
    delete setScores[key];
  }

  function handleNormalSetScoreInput(event) {
    event.target.setCustomValidity("");
    const parsed = parseNormalSetScoreText(event.target.value);
    const errors = [...parsed.errors];

    parsed.sets.forEach((set, index) => {
      errors.push(...validateNormalSingleSet(set, index + 1));
    });

    if (errors.length > 0) {
      event.target.setCustomValidity([...new Set(errors)][0]);
    }
  }

  function handleNormalSetScoreChange(event) {
    const key = event.target.dataset.normalSetKey;
    const resultScope = event.target.dataset.normalSetScope || "";
    const reverseForDisplay = event.target.dataset.normalSetReverse === "true";
    const rawValue = event.target.value.trim();
    event.target.setCustomValidity("");

    if (!key) {
      return;
    }

    if (!rawValue) {
      updateActiveTournament((tournament) => {
        deleteNormalSetScore(tournament, resultScope, key);
      }, "Satzpunkte gelöscht", { checkRoundBackups: true });
      return;
    }

    const parsed = deriveMatchScoreFromSetScoreText(rawValue, activeTournament.matchMode, {
      disallowDraw: resultScope === "knockout"
    });

    if (!parsed.valid) {
      const message = parsed.errors[0] || NORMAL_SET_SCORE_INPUT_HINT;
      event.target.setCustomValidity(message);
      event.target.reportValidity?.();
      showInfo(message);
      return;
    }

    const storedSetScore = reverseForDisplay
      ? reverseNormalSetScoreText(parsed.normalizedText)
      : parsed.normalizedText;
    const storedMatchScore = reverseForDisplay ? reverseScore(parsed.matchScore) : parsed.matchScore;

    updateActiveTournament((tournament) => {
      const setScores = ensureNormalSetScoreMap(tournament, resultScope);
      const results = getResultMapForScope(tournament, resultScope);
      const statuses = getStatusMapForScope(tournament, resultScope);

      setScores[key] = storedSetScore;
      results[key] = storedMatchScore;
      if (statuses) {
        delete statuses[key];
      }
    }, "Satzpunkte gespeichert", { checkRoundBackups: true });

    showInfo(`Satzpunkte gespeichert. Ergebnis wurde automatisch auf ${parsed.matchScore} gesetzt.`);
  }

  function handleResultChange(event) {
    const key = event.target.dataset.resultKey;
    const reverseForDisplay = event.target.dataset.resultReverse === "true";
    const resultScope = event.target.dataset.resultScope;
    const value = reverseForDisplay && event.target.value ? reverseScore(event.target.value) : event.target.value;

    updateActiveTournament((tournament) => {
      const results = getResultMapForScope(tournament, resultScope);
      deleteNormalSetScore(tournament, resultScope, key);
      if (value) {
        results[key] = value;
      } else {
        delete results[key];
      }
    }, "Ergebnis gespeichert", { checkRoundBackups: true });
  }

  function handleMatchStatusChange(event) {
    const key = event.target.dataset.matchStatusKey;
    const reverseForDisplay = event.target.dataset.matchStatusReverse === "true";
    const resultScope = event.target.dataset.matchStatusScope;
    const status = MATCH_STATUSES[event.target.value] ? event.target.value : "normal";

    updateActiveTournament((tournament) => {
      const statusMap = getStatusMapForScope(tournament, resultScope);
      const results = getResultMapForScope(tournament, resultScope);
      // B106: Ohne diese Wache stirbt jede Statuswahl in einem unbekannten
      // Bereich still — der Leiter sieht eine Auswahl, die nichts tut.
      if (!statusMap || !results) {
        showInfo("Für dieses Spiel lässt sich kein Sonderstatus speichern.");
        return;
      }
      deleteNormalSetScore(tournament, resultScope, key);

      if (status === "normal") {
        delete statusMap[key];
      } else {
        statusMap[key] = status;
      }

      if ((status === "walkover" || status === "retired") && !results[key]) {
        const defaultScore = getDefaultWinScore(tournament.matchMode);
        results[key] = reverseForDisplay ? reverseScore(defaultScore) : defaultScore;
      }
    }, "Sonderstatus gespeichert", { checkRoundBackups: true });
  }

  function handleAddDouble() {
    updateActiveTournament((tournament) => {
      tournament.team.doubles.push({
        id: createDoubleId(),
        teamAPlayer1: "",
        teamAPlayer2: "",
        teamBPlayer1: "",
        teamBPlayer2: ""
      });
      tournament.team.currentDoubleRound = 1;
      tournament.team.doubleRoundStates = [];
      tournament.team.doubleResults = {};
      tournament.team.doubleSetScores = {};
      tournament.team.doubleMatchStatuses = {};
    }, "Doppel hinzugefügt");
  }

  function handleRemoveDouble(event) {
    const doubleId = event.currentTarget.dataset.doubleId;
    if (!doubleId) {
      return;
    }

    updateActiveTournament((tournament) => {
      tournament.team.doubles = tournament.team.doubles.filter((entry) => entry.id !== doubleId);
      tournament.team.currentDoubleRound = 1;
      tournament.team.doubleRoundStates = [];
      tournament.team.doubleResults = {};
      tournament.team.doubleSetScores = {};
      tournament.team.doubleMatchStatuses = {};
    }, "Doppel entfernt");
  }

  function setTieBreakCriterion(scoring, index, nextCriterion) {
    const currentScoring = normalizeScoringRules(scoring);
    const order = [...currentScoring.tieBreakOrder];
    const safeIndex = Number.isInteger(index)
      ? Math.max(0, Math.min(order.length - 1, index))
      : 0;
    const existingIndex = order.indexOf(nextCriterion);

    if (existingIndex !== -1 && existingIndex !== safeIndex) {
      order[existingIndex] = order[safeIndex];
    }

    order[safeIndex] = nextCriterion;
    scoring.tieBreakOrder = order;
  }

  function handleSheetInput(event) {
    const action = event.target.dataset.sheetAction;
    if (!action) {
      return;
    }

    if (action === "scheduleEnabled") {
      updateActiveTournament((tournament) => {
        tournament.schedule.enabled = Boolean(event.target.checked);
      }, event.target.checked ? "Spielplan aktiviert" : "Spielplan deaktiviert");
      return;
    }

    if (action === "scheduleFieldCount") {
      updateActiveTournament((tournament) => {
        const nextCount = clampPositiveInteger(event.target.value, 1, 20);
        tournament.schedule.fieldCount = nextCount;
        tournament.schedule.fieldNames = ensureLength(
          tournament.schedule.fieldNames,
          nextCount,
          "Tisch"
        );
      }, "Spielplan-Tische geändert");
      return;
    }

    if (action === "scheduleStartTime") {
      updateActiveTournament((tournament) => {
        tournament.schedule.startTime = event.target.value;
      }, "Spielplan-Startzeit geändert");
      return;
    }

    if (action === "scheduleMatchDuration") {
      updateActiveTournament((tournament) => {
        tournament.schedule.matchDurationMinutes = clampPositiveInteger(event.target.value, 1, 240);
      }, "Spielplan-Spieldauer geändert");
      return;
    }

    if (action === "scheduleBreak") {
      updateActiveTournament((tournament) => {
        tournament.schedule.breakMinutes = clampPositiveInteger(event.target.value, 0, 120);
      }, "Spielplan-Puffer geändert");
      return;
    }

    if (action === "scheduleFieldName") {
      updateActiveTournament((tournament) => {
        tournament.schedule.fieldNames[Number(event.target.dataset.index)] = event.target.value;
      }, "Spielplan-Tischname geändert");
      return;
    }

    if (action === "roundRobinCurrentRound") {
      updateActiveTournament((tournament) => {
        tournament.roundRobin.currentRound = clampPositiveInteger(
          event.target.value,
          1,
          getRoundRobinRoundCount(tournament.roundRobin.playerCount)
        );
      }, "Aktuelle Runde geändert", { trackHistory: false });
      return;
    }

    if (action === "teamCurrentRound") {
      updateActiveTournament((tournament) => {
        tournament.team.currentRound = clampPositiveInteger(
          event.target.value,
          1,
          getTeamRoundCount(tournament.team.teamACount, tournament.team.teamBCount)
        );
      }, "Teamrunde geändert", { trackHistory: false });
      return;
    }

    if (action === "groupsCurrentRound") {
      updateActiveTournament((tournament) => {
        tournament.groupsKnockout.currentGroupRound = clampPositiveInteger(
          event.target.value,
          1,
          analysis.groupRoundSchedule.length
        );
      }, "Gruppenrunde geändert", { trackHistory: false });
      return;
    }

    if (action === "knockoutCurrentRound") {
      updateActiveTournament((tournament) => {
        tournament.groupsKnockout.currentKnockoutRound = clampPositiveInteger(
          event.target.value,
          1,
          Math.max(1, analysis.knockoutRounds.length)
        );
      }, "KO-Runde geändert", { trackHistory: false });
      return;
    }

    if (action === "doubleCurrentRound") {
      updateActiveTournament((tournament) => {
        tournament.team.currentDoubleRound = clampPositiveInteger(
          event.target.value,
          1,
          Math.max(1, tournament.team.doubles.length)
        );
      }, "Doppelrunde geändert", { trackHistory: false });
      return;
    }

    if (action === "doubleRoundManual") {
      updateActiveTournament((tournament) => {
        const roundNumber = tournament.team.currentDoubleRound;
        const sourceRound = analysis.doubleRounds.find((entry) => entry.roundNumber === roundNumber);
        const roundState = ensureDoubleRoundState(tournament.team, roundNumber, sourceRound);
        roundState.manual = Boolean(event.target.checked);
      }, "Doppelrunde umgestellt", { trackHistory: false });
      return;
    }

    if (action === "doubleRoundPairTeamA" || action === "doubleRoundPairTeamB") {
      updateActiveTournament((tournament) => {
        const pairingId = event.target.dataset.doublePairingId;
        const roundNumber = tournament.team.currentDoubleRound;
        const sourceRound = analysis.doubleRounds.find((entry) => entry.roundNumber === roundNumber);
        const roundState = ensureDoubleRoundState(tournament.team, roundNumber, sourceRound);
        const pairing = roundState.matchups.find((entry) => entry.id === pairingId);
        if (!pairing) {
          return;
        }

        roundState.manual = true;

        if (action === "doubleRoundPairTeamA") {
          pairing.teamADoubleId = event.target.value;
        } else {
          pairing.teamBDoubleId = event.target.value;
        }
      }, "Doppel-Paarung geändert");
    }
  }

  function handlePlayerStatsFontSizeAdjust(event) {
    const step = Number(event.currentTarget.dataset.fontSizeStep);
    if (!Number.isFinite(step) || step === 0) {
      return;
    }

    const currentIndex = PLAYER_STATS_FONT_SIZES.indexOf(playerStatsFontSize);
    const nextIndex = Math.min(
      PLAYER_STATS_FONT_SIZES.length - 1,
      Math.max(0, currentIndex + step)
    );

    if (nextIndex === currentIndex) {
      applyPlayerStatsFontSizeUI();
      return;
    }

    playerStatsFontSize = PLAYER_STATS_FONT_SIZES[nextIndex];
    savePlayerStatsFontSize();
    applyPlayerStatsFontSizeUI();
  }

  function handleRoundShift(event) {
    const delta = Number.parseInt(event.currentTarget.dataset.roundShift, 10);
    const target = event.currentTarget.dataset.targetRound;

    if (target === "roundRobin") {
      updateActiveTournament((tournament) => {
        tournament.roundRobin.currentRound = clampPositiveInteger(
          tournament.roundRobin.currentRound + delta,
          1,
          getRoundRobinRoundCount(tournament.roundRobin.playerCount)
        );
      }, "Aktuelle Runde geändert", { trackHistory: false });
      return;
    }

    if (target === "team") {
      updateActiveTournament((tournament) => {
        tournament.team.currentRound = clampPositiveInteger(
          tournament.team.currentRound + delta,
          1,
          getTeamRoundCount(tournament.team.teamACount, tournament.team.teamBCount)
        );
      }, "Teamrunde geändert", { trackHistory: false });
      return;
    }

    if (target === "groupStage") {
      updateActiveTournament((tournament) => {
        tournament.groupsKnockout.currentGroupRound = clampPositiveInteger(
          tournament.groupsKnockout.currentGroupRound + delta,
          1,
          analysis.groupRoundSchedule.length
        );
      }, "Gruppenrunde geändert", { trackHistory: false });
      return;
    }

    if (target === "knockout") {
      updateActiveTournament((tournament) => {
        tournament.groupsKnockout.currentKnockoutRound = clampPositiveInteger(
          tournament.groupsKnockout.currentKnockoutRound + delta,
          1,
          Math.max(1, analysis.knockoutRounds.length)
        );
      }, "KO-Runde geändert", { trackHistory: false });
      return;
    }

    if (target === "double") {
      updateActiveTournament((tournament) => {
        tournament.team.currentDoubleRound = clampPositiveInteger(
          tournament.team.currentDoubleRound + delta,
          1,
          Math.max(1, tournament.team.doubles.length)
        );
      }, "Doppelrunde geändert", { trackHistory: false });
    }
  }


  function getParticipantImportSettings(targetKey) {
    if (targetKey === "teamA") {
      return {
        description: "Namen für Team A einfügen oder als CSV laden.",
        textareaLabel: "Team-A-Teilnehmer einfügen",
        placeholder: "Teamname: Team Rot\nAnna\nBen\nCara",
        hasTeamName: true,
        teamNamePlaceholder: activeTournament.team.teamAName || "Team A"
      };
    }

    if (targetKey === "teamB") {
      return {
        description: "Namen für Team B einfügen oder als CSV laden.",
        textareaLabel: "Team-B-Teilnehmer einfügen",
        placeholder: "Teamname: Team Blau\nDina\nEmil\nFinn",
        hasTeamName: true,
        teamNamePlaceholder: activeTournament.team.teamBName || "Team B"
      };
    }

    return {
      description: "Kopiere Namen aus Excel, Numbers oder einer Textliste. Trennzeichen wie Zeilenumbruch, Semikolon, Komma und Tab werden erkannt.",
      textareaLabel: "Namen eintragen — ein Name pro Zeile",
      placeholder: "Tobi\nMia\nLukas Berger\nSofia\nTarek",
      hasTeamName: false,
      teamNamePlaceholder: ""
    };
  }

  function createParticipantImportTargetDraft() {
    return {
      text: "",
      teamName: "",
      numberDuplicates: false,
      fileName: ""
    };
  }

  function getParticipantImportDraft(tournamentId) {
    if (!participantImportDrafts.has(tournamentId)) {
      participantImportDrafts.set(tournamentId, {
        roundRobin: createParticipantImportTargetDraft(),
        teamA: createParticipantImportTargetDraft(),
        teamB: createParticipantImportTargetDraft()
      });
    }

    return participantImportDrafts.get(tournamentId);
  }

  function getParticipantImportPreview(targetKey) {
    const draft = getParticipantImportDraft(activeTournament.id)[targetKey] || createParticipantImportTargetDraft();
    const parsed = parseParticipantImportText(draft.text);
    const comparisonNames = getParticipantImportComparisonNames(targetKey);
    const duplicateKeys = getDuplicateNameKeys([...parsed.names, ...comparisonNames]);
    const displayNames = parsed.names.map((name) => ({
      name,
      isDuplicate: duplicateKeys.has(normalizeNameKey(name))
    }));
    const nextNames = draft.numberDuplicates
      ? numberDuplicateNames(parsed.names, comparisonNames)
      : parsed.names;
    const maxCount = nextNames.length > 0 ? clampCount(nextNames.length) : 0;
    const applyNames = nextNames.slice(0, maxCount);

    return {
      hasInput: draft.text.trim().length > 0,
      names: parsed.names,
      displayNames,
      applyNames,
      duplicateCount: displayNames.filter((entry) => entry.isDuplicate).length,
      ignoredCount: Math.max(0, nextNames.length - applyNames.length),
      teamName: (draft.teamName.trim() || parsed.teamName).trim()
    };
  }

  function refreshParticipantImportPreview(targetKey) {
    const panel = configDetails.querySelector('[data-import-panel="' + targetKey + '"]');
    if (!panel) {
      return;
    }

    const preview = getParticipantImportPreview(targetKey);
    const previewElement = panel.querySelector('[data-import-preview="' + targetKey + '"]');
    const applyButton = panel.querySelector('[data-import-apply="' + targetKey + '"]');
    const teamNameInput = panel.querySelector('[data-import-team-name="' + targetKey + '"]');
    const countHeading = panel.querySelector("[data-import-count]");

    if (previewElement) {
      // Beim Tippen zeigt die rechte Spalte die erkannten Namen, sonst die
      // bereits übernommene Startliste.
      const rows = preview.hasInput
        ? preview.displayNames.map((entry, index) => ({ name: preview.applyNames[index] || entry.name, index }))
        : getEntryRoster(targetKey).map((name, index) => ({ name, index }));
      previewElement.innerHTML = renderEntryRows(rows, targetKey, preview.hasInput);

      previewElement.querySelectorAll("[data-entry-remove]").forEach((button) => {
        button.addEventListener("click", () =>
          handleRemoveEntry(button.dataset.entryRemove, Number(button.dataset.index))
        );
      });
      previewElement.querySelectorAll("[data-draft-remove]").forEach((button) => {
        button.addEventListener("click", () =>
          handleRemoveDraftLine(button.dataset.draftRemove, Number(button.dataset.index))
        );
      });
    }
    if (countHeading) {
      countHeading.textContent = preview.hasInput
        ? formatImportCountHeading(preview.applyNames.length)
        : `Startliste · ${getEntryRoster(targetKey).length} Teilnehmer`;
    }

    const hint = panel.querySelector("[data-import-hint]");
    if (hint) {
      hint.textContent = preview.hasInput
        ? "Danach folgt die Auslosung der ersten Runde."
        : "Namen eintragen, dann übernehmen.";
    }
    if (applyButton) {
      applyButton.disabled = preview.applyNames.length === 0;
    }
    if (teamNameInput && !teamNameInput.value && preview.teamName) {
      teamNameInput.value = preview.teamName;
    }
  }

  function parseParticipantImportText(rawText) {
    const rows = parseDelimitedRows(rawText);
    const contentRows = [];
    let teamName = "";

    rows.forEach((row) => {
      const detectedTeamName = getTeamNameFromImportRow(row);
      if (detectedTeamName) {
        if (!teamName) {
          teamName = detectedTeamName;
        }
        return;
      }
      contentRows.push(row);
    });

    const headerNameColumn = getHeaderNameColumn(contentRows[0]);
    if (headerNameColumn >= 0) {
      const dataRows = contentRows.slice(1);
      const names = dataRows.map((row) => row[headerNameColumn] || "");
      const headerTeamName = getSingleColumnImportValue(
        dataRows,
        getHeaderTeamColumn(contentRows[0])
      );
      return { names: cleanImportedNames(names), teamName: teamName || headerTeamName };
    }

    const repeatedTeamColumn = getRepeatedTeamColumnImport(contentRows);
    if (repeatedTeamColumn) {
      return {
        names: cleanImportedNames(repeatedTeamColumn.names),
        teamName: teamName || repeatedTeamColumn.teamName
      };
    }

    return {
      names: cleanImportedNames(contentRows.flatMap((row) => row)),
      teamName
    };
  }

  function parseDelimitedRows(rawText) {
    const rows = [[]];
    let currentValue = "";
    let isQuoted = false;
    const text = String(rawText || "");

    for (let index = 0; index < text.length; index += 1) {
      const character = text[index];
      const nextCharacter = text[index + 1];

      if (isQuoted) {
        if (character === '"' && nextCharacter === '"') {
          currentValue += '"';
          index += 1;
        } else if (character === '"') {
          isQuoted = false;
        } else {
          currentValue += character;
        }
        continue;
      }

      if (character === '"') {
        isQuoted = true;
        continue;
      }

      if ([",", ";", "\t"].includes(character)) {
        rows[rows.length - 1].push(currentValue.trim());
        currentValue = "";
        continue;
      }

      if (character === "\n" || character === "\r") {
        rows[rows.length - 1].push(currentValue.trim());
        currentValue = "";
        if (character === "\r" && nextCharacter === "\n") {
          index += 1;
        }
        rows.push([]);
        continue;
      }

      currentValue += character;
    }

    rows[rows.length - 1].push(currentValue.trim());
    return rows.filter((row) => row.some((cell) => cell.trim()));
  }

  function getTeamNameFromImportRow(row) {
    if (!Array.isArray(row) || row.length === 0) {
      return "";
    }

    if (row.length === 1) {
      const match = row[0].match(/^(?:team(?:\s+[ab])?|teamname|mannschaft|gruppe)\s*[:=-]\s*(.+)$/i);
      return match?.[1]?.trim() || "";
    }

    const label = normalizeNameKey(row[0]);
    if (["teamname", "mannschaft", "gruppe"].includes(label) && row[1]) {
      return row[1].trim();
    }

    return "";
  }

  function getHeaderNameColumn(row) {
    if (!Array.isArray(row)) {
      return -1;
    }

    return row.findIndex((cell) => /^(name|spieler|spielername|teilnehmer|person)$/i.test(cell.trim()));
  }

  function getHeaderTeamColumn(row) {
    if (!Array.isArray(row)) {
      return -1;
    }

    return row.findIndex((cell) => /^(team|teamname|mannschaft|gruppe)$/i.test(cell.trim()));
  }

  function getSingleColumnImportValue(rows, columnIndex) {
    if (columnIndex < 0) {
      return "";
    }

    const values = rows.map((row) => row[columnIndex]?.trim()).filter(Boolean);
    if (values.length === 0) {
      return "";
    }

    const firstValue = values[0];
    return values.every((value) => normalizeNameKey(value) === normalizeNameKey(firstValue))
      ? firstValue
      : "";
  }

  function getRepeatedTeamColumnImport(rows) {
    const candidateRows = rows.filter((row) => row.length >= 2 && row[0]?.trim() && row[1]?.trim());
    if (candidateRows.length < 2) {
      return null;
    }

    const teamName = candidateRows[0][0].trim();
    const normalizedTeamName = normalizeNameKey(teamName);
    const hasSingleTeamColumn = candidateRows.every(
      (row) => normalizeNameKey(row[0]) === normalizedTeamName
    );

    if (!hasSingleTeamColumn || getHeaderNameColumn(candidateRows[0]) >= 0) {
      return null;
    }

    return {
      teamName,
      names: candidateRows.map((row) => row[1])
    };
  }

  function cleanImportedNames(names) {
    return names.map((name) => String(name || "").trim()).filter(Boolean);
  }

  function getParticipantImportComparisonNames(targetKey) {
    if (targetKey === "teamA") {
      return ensureLength(
        activeTournament.team.teamBPlayers,
        activeTournament.team.teamBCount,
        "Spieler B"
      );
    }

    if (targetKey === "teamB") {
      return ensureLength(
        activeTournament.team.teamAPlayers,
        activeTournament.team.teamACount,
        "Spieler A"
      );
    }

    return [];
  }

  function getDuplicateNameKeys(names) {
    const counts = new Map();
    names.forEach((name) => {
      const key = normalizeNameKey(name);
      if (!key) {
        return;
      }
      counts.set(key, (counts.get(key) || 0) + 1);
    });

    return new Set([...counts.entries()].filter(([, count]) => count > 1).map(([key]) => key));
  }

  function numberDuplicateNames(names, reservedNames = []) {
    const usedCounts = new Map();
    reservedNames.forEach((name) => {
      const key = normalizeNameKey(name);
      if (key) {
        usedCounts.set(key, (usedCounts.get(key) || 0) + 1);
      }
    });

    return names.map((name) => {
      const baseName = name.trim();
      let candidateName = baseName;
      let candidateKey = normalizeNameKey(candidateName);
      let nextIndex = usedCounts.get(candidateKey) || 0;

      while (candidateKey && usedCounts.has(candidateKey)) {
        nextIndex += 1;
        candidateName = baseName + " (" + nextIndex + ")";
        candidateKey = normalizeNameKey(candidateName);
      }

      if (candidateKey) {
        usedCounts.set(candidateKey, 1);
      }
      return candidateName;
    });
  }

  function normalizeNameKey(name) {
    return String(name || "").trim().toLocaleLowerCase("de-DE");
  }

  function isTeamImportTarget(targetKey) {
    return targetKey === "teamA" || targetKey === "teamB";
  }

  function hasEnteredValues(values, ignoredValues = []) {
    const ignored = new Set(ignoredValues);
    return Object.values(values || {}).some((value) => {
      if (value === undefined || value === null || value === "") {
        return false;
      }
      return !ignored.has(value);
    });
  }

  function hasRoundRobinDrawStarted(tournament) {
    return (
      hasEnteredValues(tournament?.roundRobin?.results) ||
      hasEnteredValues(tournament?.roundRobin?.setScores) ||
      hasEnteredValues(tournament?.roundRobin?.matchStatuses, ["normal"]) ||
      (tournament?.ttRace?.rounds?.length ?? 0) > 0 ||
      hasEnteredValues(tournament?.clicktt?.setScores)
    );
  }

  function hasGroupsKnockoutDrawStarted(tournament) {
    return (
      hasEnteredValues(tournament?.groupsKnockout?.groupResults) ||
      hasEnteredValues(tournament?.groupsKnockout?.groupSetScores) ||
      hasEnteredValues(tournament?.groupsKnockout?.knockoutSetScores) ||
      hasEnteredValues(tournament?.groupsKnockout?.knockoutResults)
    );
  }

  function activeTournamentHasStoredResults() {
    if (activeTournament.mode === "team") {
      return (
        hasEnteredValues(activeTournament.team.results) ||
        hasEnteredValues(activeTournament.team.setScores) ||
        hasEnteredValues(activeTournament.team.matchStatuses, ["normal"]) ||
        hasEnteredValues(activeTournament.team.doubleResults) ||
        hasEnteredValues(activeTournament.team.doubleSetScores) ||
        hasEnteredValues(activeTournament.team.doubleMatchStatuses, ["normal"])
      );
    }

    if (activeTournament.mode === "groupsKnockout") {
      return hasGroupsKnockoutDrawStarted(activeTournament);
    }

    return hasRoundRobinDrawStarted(activeTournament);
  }

  function trimRoundRobinResults(results, count) {
    const trimmed = {};
    Object.entries(results).forEach(([key, value]) => {
      const [row, column] = key.split("-").map(Number);
      if (row < count && column < count) {
        trimmed[key] = value;
      }
    });
    return trimmed;
  }

  function trimTeamResults(results, teamACount, teamBCount) {
    const trimmed = {};
    Object.entries(results).forEach(([key, value]) => {
      const [row, column] = key.split("-").map(Number);
      if (row < teamACount && column < teamBCount) {
        trimmed[key] = value;
      }
    });
    return trimmed;
  }

  function ensureLength(list, count, fallbackLabel) {
    return Array.from({ length: count }, (_, index) => list?.[index] || `${fallbackLabel} ${index + 1}`);
  }

  function ensureDoubleRoundState(teamState, roundNumber, fallbackRound = null) {
    if (!Array.isArray(teamState.doubleRoundStates)) {
      teamState.doubleRoundStates = [];
    }

    let roundState = teamState.doubleRoundStates.find((entry) => entry.roundNumber === roundNumber);
    if (!roundState) {
      roundState = {
        roundNumber,
        manual: false,
        matchups: []
      };
      teamState.doubleRoundStates.push(roundState);
    }

    if (!Array.isArray(roundState.matchups)) {
      roundState.matchups = [];
    }

    if (roundState.matchups.length === 0 && Array.isArray(fallbackRound?.pairings)) {
      roundState.matchups = fallbackRound.pairings.map((entry) => ({
        id: entry.id,
        teamADoubleId: entry.teamADoubleId || "",
        teamBDoubleId: entry.teamBDoubleId || ""
      }));
    }

    return roundState;
  }

  /**
   * B104: Der Gruppen+KO-Zweig war in den Team-Zweig hineingerutscht — eine
   * Bedingung, die nie wahr werden kann. Der Rundenexport nahm für Gruppen+KO
   * deshalb den Jeder-gegen-jeden-Weg und griff auf `analysis.rounds` zu, das
   * dieses Format nicht führt: TypeError, abgefangen von niemandem. Solange
   * die Export-Knöpfe im `hidden`-Block lagen, fiel es nicht auf; seit Welle 4
   * sind sie sichtbar.
   */
  function getCurrentRoundExportData() {
    if (activeTournament.mode === "groupsKnockout") {
      const totalRounds = analysis.groupRoundSchedule.length;
      const currentRoundNumber = getCurrentGroupsRoundNumber(totalRounds);
      return {
        analysis,
        round: analysis.groupRoundSchedule[currentRoundNumber - 1],
        currentRoundNumber,
        totalRounds
      };
    }

    if (activeTournament.mode === "team") {
      const totalRounds = analysis.rounds.length;
      const currentRoundNumber = getCurrentTeamRoundNumber(totalRounds);
      return {
        analysis,
        round: analysis.rounds[currentRoundNumber - 1],
        currentRoundNumber,
        totalRounds
      };
    }

    const totalRounds = analysis.rounds.length;
    const currentRoundNumber = getCurrentRoundNumber(totalRounds);
    return {
      analysis,
      round: analysis.rounds[currentRoundNumber - 1],
      currentRoundNumber,
      totalRounds
    };
  }

  function getRoundStatus(round) {
    const matches = Array.isArray(round?.matches) ? round.matches : null;
    const totalMatches = matches ? matches.length : round?.pairings?.length ?? 0;
    const completedMatches = matches
      ? matches.filter((match) => isTtRaceMatchComplete(match)).length
      : round?.pairings?.filter(
          (pairing) => pairing.score || (pairing.matchStatus && pairing.matchStatus !== "normal")
        ).length ?? 0;
    const isComplete = totalMatches > 0 && completedMatches === totalMatches;

    if (isComplete) {
      return {
        isComplete: true,
        className: "is-complete",
        label: "Fertig",
        completedMatches,
        totalMatches
      };
    }

    if (completedMatches > 0) {
      return {
        isComplete: false,
        className: "is-progress",
        label: `${completedMatches}/${totalMatches} fertig`,
        completedMatches,
        totalMatches
      };
    }

    return {
      isComplete: false,
      className: "is-pending",
      label: "Offen",
      completedMatches,
      totalMatches
    };
  }

  function renderProgressSummary(rounds, currentRoundNumber, completedMatches, totalMatches, matchLabel) {
    const currentRound = rounds[currentRoundNumber - 1];
    const roundStatus = getRoundStatus(currentRound);

    return `
      <div class="progress-strip">
        <span class="progress-pill">Runde ${currentRoundNumber} von ${rounds.length}</span>
        <span class="progress-pill">${completedMatches} von ${totalMatches} ${escapeHtml(matchLabel)} eingetragen</span>
        <span class="progress-pill ${roundStatus.className}">
          Aktuelle Runde: ${escapeHtml(roundStatus.label)}
        </span>
      </div>
    `;
  }

  // B048: Gruppen + KO trug dasselbe Knopfpaar zweimal — im Blatt gesperrt mit
  // Erklärung, in der Randspalte immer aktiv und stumm. Es bleibt eines: das
  // der Randspalte, das jetzt für alle vier Formate gleich arbeitet. Und
  // „Zurück" hieß hier dasselbe wie „Zurück zu Gruppenrunde 1" direkt darüber.

  function findDuplicateNames(names) {
    const seen = new Map();

    for (const rawName of names) {
      const trimmedName = rawName.trim();
      if (!trimmedName) {
        continue;
      }

      const normalizedName = trimmedName.toLocaleLowerCase("de-DE");
      if (seen.has(normalizedName)) {
        return trimmedName;
      }

      seen.set(normalizedName, trimmedName);
    }

    return "";
  }

  function validateUniquePlayerNameChange(action, target) {
    const nextValue = target.value;
    const index = Number(target.dataset.index);

    if (action === "roundRobinName") {
      const candidateNames = ensureLength(
        activeTournament.roundRobin.playerNames,
        activeTournament.roundRobin.playerCount,
        "Spieler"
      );
      candidateNames[index] = nextValue;
      const duplicateName = findDuplicateNames(candidateNames);
      return duplicateName
        ? `Der Spielername „${duplicateName}“ ist in diesem Turnier bereits vergeben.`
        : "";
    }

    if (action === "groupsKnockoutName") {
      const candidateNames = ensureLength(
        activeTournament.groupsKnockout.playerNames,
        activeTournament.groupsKnockout.playerCount,
        "Spieler"
      );
      candidateNames[index] = nextValue;
      const duplicateName = findDuplicateNames(candidateNames);
      return duplicateName
        ? `Der Teilnehmername „${duplicateName}“ ist in diesem Turnier bereits vergeben.`
        : "";
    }

    if (action === "teamAPlayer" || action === "teamBPlayer") {
      const teamANames = ensureLength(
        activeTournament.team.teamAPlayers,
        activeTournament.team.teamACount,
        "Spieler A"
      );
      const teamBNames = ensureLength(
        activeTournament.team.teamBPlayers,
        activeTournament.team.teamBCount,
        "Spieler B"
      );

      if (action === "teamAPlayer") {
        teamANames[index] = nextValue;
      } else {
        teamBNames[index] = nextValue;
      }

      const duplicateName = findDuplicateNames([...teamANames, ...teamBNames]);
      return duplicateName
        ? `Der Spielername „${duplicateName}“ ist in diesem Turnier bereits vergeben.`
        : "";
    }

    return "";
  }

  function getActiveTournamentIndex() {
    return workspace.tournaments.findIndex((entry) => entry.id === workspace.activeTournamentId);
  }

  function getTournamentLabel(tournament, index) {
    return tournament.tabName?.trim() || tournament.tournamentName?.trim() || `Turnier ${index + 1}`;
  }

  function getCurrentRoundNumber(totalRounds) {
    return clampPositiveInteger(activeTournament.roundRobin.currentRound, 1, Math.max(1, totalRounds));
  }

  function getCurrentTeamRoundNumber(totalRounds) {
    return clampPositiveInteger(activeTournament.team.currentRound, 1, Math.max(1, totalRounds));
  }

  function getCurrentDoubleRoundNumber(totalRounds) {
    return clampPositiveInteger(activeTournament.team.currentDoubleRound, 1, Math.max(1, totalRounds));
  }

  function getCurrentGroupsRoundNumber(totalRounds) {
    return clampPositiveInteger(
      activeTournament.groupsKnockout.currentGroupRound,
      1,
      Math.max(1, totalRounds)
    );
  }

  function getCurrentKnockoutRoundNumber(totalRounds) {
    return clampPositiveInteger(
      activeTournament.groupsKnockout.currentKnockoutRound,
      1,
      Math.max(1, totalRounds)
    );
  }

  function renderTabToolIcon(kind) {
    if (kind === "drag") {
      return `
        <svg class="tab-tool-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
          <path d="M9 6h.01" />
          <path d="M9 12h.01" />
          <path d="M9 18h.01" />
          <path d="M15 6h.01" />
          <path d="M15 12h.01" />
          <path d="M15 18h.01" />
        </svg>
      `;
    }

    if (kind === "rename") {
      return `
        <svg class="tab-tool-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
          <path d="M12 20h9" />
          <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" />
        </svg>
      `;
    }

    return `
      <svg class="tab-tool-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true" focusable="false">
        <path d="M6 6l12 12" />
        <path d="M18 6L6 18" />
      </svg>
    `;
  }

  function showInfo(message) {
    // Solange nicht gespeichert werden kann, bleibt die Warnung stehen. Eine
    // vorbeihuschende Erfolgsmeldung darf sie nicht verdecken.
    if (storageFailed || externalWorkspaceChange) {
      return;
    }

    if (infoMessageTimeoutId) {
      window.clearTimeout(infoMessageTimeoutId);
      infoMessageTimeoutId = null;
    }

    messageArea.innerHTML = `<div class="message info">${escapeHtml(message)}</div>`;

    infoMessageTimeoutId = window.setTimeout(() => {
      infoMessageTimeoutId = null;
      // B120: Der Timer einer früheren Erfolgsmeldung darf eine inzwischen
      // erschienene Warnleiste nicht wegwischen — er räumt nur ab, was er
      // selbst hingelegt hat.
      if (messageArea.querySelector(".storage-alert, .external-change-alert")) {
        return;
      }
      messageArea.innerHTML = "";
    }, INFO_MESSAGE_DURATION_MS);
  }

  function placeClass(place) {
    if (place === 1) {
      return "place-first";
    }
    if (place === 2) {
      return "place-second";
    }
    if (place === 3) {
      return "place-third";
    }
    return "";
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }
})();
