import { parseTournamentPortalXml, validateTournamentPortal } from "./clicktt.js";

export function compareClickttResultXml(expectedXml, actualXml, options = {}) {
  const expectedPortal = parseTournamentPortalXml(expectedXml);
  const actualPortal = parseTournamentPortalXml(actualXml);
  const expectedIssues = validateTournamentPortal(expectedPortal);
  const actualIssues = validateTournamentPortal(actualPortal);
  const expectedCompetition = selectComparableCompetition(expectedPortal, options.expectedCompetitionSelector);
  const actualCompetition = selectComparableCompetition(actualPortal, options.actualCompetitionSelector);
  const issues = [];
  const warnings = [];

  addValidationIssues(issues, "expected", expectedIssues);
  addValidationIssues(issues, "actual", actualIssues);

  if (!expectedCompetition) {
    issues.push(createDifference("missing-expected-competition", "Die Referenz-XML enthält keinen vergleichbaren Wettbewerb."));
  }

  if (!actualCompetition) {
    issues.push(createDifference("missing-actual-competition", "Die Ist-XML enthält keinen vergleichbaren Wettbewerb."));
  }

  if (!expectedCompetition || !actualCompetition) {
    return createComparisonResult(issues, warnings);
  }

  compareCompetitionMetadata(issues, warnings, expectedCompetition, actualCompetition);
  comparePlayers(issues, warnings, expectedCompetition, actualCompetition, options);
  compareMatches(issues, warnings, expectedCompetition.matches, actualCompetition.matches, options);

  return createComparisonResult(issues, warnings);
}

export function summarizeClickttResultXml(xml, options = {}) {
  const portal = parseTournamentPortalXml(xml);
  const competition = selectComparableCompetition(portal, options.competitionSelector);

  if (!competition) {
    return {
      tournamentName: portal.tournament.name,
      competition: null,
      players: 0,
      matches: 0,
      rounds: []
    };
  }

  return {
    tournamentName: portal.tournament.name,
    competition: getCompetitionName(competition),
    players: competition.players.length,
    matches: competition.matches.length,
    rounds: summarizeRounds(competition.matches)
  };
}

function createComparisonResult(issues, warnings) {
  return {
    ok: issues.length === 0,
    issues,
    warnings
  };
}

function createDifference(code, message, details = {}) {
  return { code, message, details };
}

function addValidationIssues(comparisonIssues, side, validationIssues) {
  validationIssues.forEach((issue) => {
    comparisonIssues.push(
      createDifference("validation-issue", `${side} XML hat eine Validator-Meldung: ${issue.message}`, {
        side,
        path: issue.path,
        code: issue.code
      })
    );
  });
}

function selectComparableCompetition(portal, selector) {
  if (typeof selector === "number") {
    return portal.competitions[selector] ?? null;
  }

  if (selector) {
    const byId = portal.competitions.find((competition) => competition.id === selector);
    if (byId) {
      return byId;
    }
  }

  return (
    portal.competitions.find((competition) => competition.matches.length > 0) ||
    portal.competitions.find((competition) => competition.players.length > 0) ||
    portal.competitions[0] ||
    null
  );
}

function getCompetitionName(competition) {
  return [competition.ageGroup, competition.type].filter(Boolean).join(" ") || competition.id || "Wettbewerb";
}

function compareCompetitionMetadata(issues, warnings, expectedCompetition, actualCompetition) {
  if (expectedCompetition.players.length !== actualCompetition.players.length) {
    issues.push(
      createDifference("player-count-mismatch", "Die Spieleranzahl unterscheidet sich.", {
        expected: expectedCompetition.players.length,
        actual: actualCompetition.players.length
      })
    );
  }

  if (expectedCompetition.matches.length !== actualCompetition.matches.length) {
    issues.push(
      createDifference("match-count-mismatch", "Die Matchanzahl unterscheidet sich.", {
        expected: expectedCompetition.matches.length,
        actual: actualCompetition.matches.length
      })
    );
  }

  if (getCompetitionName(expectedCompetition) !== getCompetitionName(actualCompetition)) {
    warnings.push(
      createDifference("competition-label-mismatch", "Der Wettbewerbsname unterscheidet sich.", {
        expected: getCompetitionName(expectedCompetition),
        actual: getCompetitionName(actualCompetition)
      })
    );
  }
}

function comparePlayers(issues, warnings, expectedCompetition, actualCompetition, options) {
  const actualPlayers = new Map(actualCompetition.players.map((player) => [player.id, player]));
  const expectedPlayers = new Map(expectedCompetition.players.map((player) => [player.id, player]));

  expectedCompetition.players.forEach((expectedPlayer) => {
    const actualPlayer = actualPlayers.get(expectedPlayer.id);
    if (!actualPlayer) {
      issues.push(
        createDifference("missing-player", "Ein Spieler fehlt in der Ist-XML.", {
          playerId: expectedPlayer.id,
          name: expectedPlayer.displayName
        })
      );
      return;
    }

    if (expectedPlayer.displayName && actualPlayer.displayName && expectedPlayer.displayName !== actualPlayer.displayName) {
      warnings.push(
        createDifference("player-name-mismatch", "Der Spielername unterscheidet sich.", {
          playerId: expectedPlayer.id,
          expected: expectedPlayer.displayName,
          actual: actualPlayer.displayName
        })
      );
    }

    if (options.comparePlacements !== false && expectedPlayer.placement !== actualPlayer.placement) {
      issues.push(
        createDifference("placement-mismatch", "Die Endplatzierung unterscheidet sich.", {
          playerId: expectedPlayer.id,
          expected: expectedPlayer.placement,
          actual: actualPlayer.placement
        })
      );
    }
  });

  actualCompetition.players.forEach((actualPlayer) => {
    if (!expectedPlayers.has(actualPlayer.id)) {
      issues.push(
        createDifference("extra-player", "Ein zusätzlicher Spieler steht nur in der Ist-XML.", {
          playerId: actualPlayer.id,
          name: actualPlayer.displayName
        })
      );
    }
  });
}

function compareMatches(issues, warnings, expectedMatches, actualMatches, options) {
  const actualByIdentity = createMatchMap(actualMatches, issues, "actual");
  createMatchMap(expectedMatches, issues, "expected");
  const usedActualKeys = new Set();

  expectedMatches.forEach((expectedMatch, index) => {
    const expectedComparable = normalizeComparableMatch(expectedMatch);
    const actualMatch = actualByIdentity.get(expectedComparable.identity);

    if (!actualMatch) {
      issues.push(
        createDifference("missing-match", "Ein Referenzspiel fehlt in der Ist-XML.", {
          identity: expectedComparable.identity,
          group: expectedMatch.group,
          playerA: expectedMatch.playerA,
          playerB: expectedMatch.playerB
        })
      );
      return;
    }

    usedActualKeys.add(expectedComparable.identity);
    const actualComparable = normalizeComparableMatch(actualMatch);

    if (
      options.compareOrder !== false &&
      (expectedComparable.sequence.nr !== actualComparable.sequence.nr ||
        expectedComparable.sequence.index !== actualComparable.sequence.index)
    ) {
      warnings.push(
        createDifference("match-order-mismatch", "Das Spiel steht an einer anderen Position.", {
          identity: expectedComparable.identity,
          expected: expectedComparable.sequence,
          actual: actualComparable.sequence
        })
      );
    }

    if (expectedComparable.group !== actualComparable.group) {
      issues.push(
        createDifference("group-mismatch", "Das Rundenlabel unterscheidet sich.", {
          identity: expectedComparable.identity,
          expected: expectedComparable.group,
          actual: actualComparable.group
        })
      );
    }

    if (expectedComparable.winnerId !== actualComparable.winnerId) {
      issues.push(
        createDifference("winner-mismatch", "Der Sieger unterscheidet sich.", {
          identity: expectedComparable.identity,
          expected: expectedComparable.winnerId,
          actual: actualComparable.winnerId
        })
      );
    }

    if (expectedComparable.retiredPlayerId !== actualComparable.retiredPlayerId) {
      issues.push(
        createDifference("retirement-mismatch", "Die Aufgabe/Retirement-Zuordnung unterscheidet sich.", {
          identity: expectedComparable.identity,
          expected: expectedComparable.retiredPlayerId,
          actual: actualComparable.retiredPlayerId
        })
      );
    }

    if (JSON.stringify(expectedComparable.sets) !== JSON.stringify(actualComparable.sets)) {
      issues.push(
        createDifference("set-score-mismatch", "Die Satzpunkte unterscheiden sich.", {
          identity: expectedComparable.identity,
          expected: expectedComparable.sets,
          actual: actualComparable.sets
        })
      );
    }

    if (expectedComparable.index !== index) {
      warnings.push(
        createDifference("reference-index-mismatch", "Die Referenzdatei enthält eine unerwartete Match-Reihenfolge.", {
          identity: expectedComparable.identity,
          expectedIndex: index,
          parsedIndex: expectedComparable.index
        })
      );
    }
  });

  actualMatches.forEach((actualMatch) => {
    const actualComparable = normalizeComparableMatch(actualMatch);
    if (!usedActualKeys.has(actualComparable.identity)) {
      issues.push(
        createDifference("extra-match", "Ein zusätzliches Spiel steht nur in der Ist-XML.", {
          identity: actualComparable.identity,
          group: actualMatch.group,
          playerA: actualMatch.playerA,
          playerB: actualMatch.playerB
        })
      );
    }
  });
}

function createMatchMap(matches, issues = [], side = "actual") {
  const map = new Map();

  matches.forEach((match) => {
    const comparable = normalizeComparableMatch(match);
    if (!map.has(comparable.identity)) {
      map.set(comparable.identity, match);
    } else {
      issues.push(
        createDifference("duplicate-match", "Eine Datei enthält dieselbe Paarung in derselben Runde mehrfach.", {
          side,
          identity: comparable.identity,
          group: match.group,
          playerA: match.playerA,
          playerB: match.playerB
        })
      );
    }
  });

  return map;
}

function normalizeComparableMatch(match) {
  const players = [match.playerA, match.playerB].sort();
  const isOriginalOrder = match.playerA === players[0];
  const sets = extractPlayedSets(match).map(([left, right]) =>
    isOriginalOrder ? [left, right] : [right, left]
  );
  const winnerId = match.matchesA === 1 ? match.playerA : match.matchesB === 1 ? match.playerB : "";
  const retiredPlayerId =
    match.state === "retired-a" ? match.playerA : match.state === "retired-b" ? match.playerB : "";

  return {
    identity: `${normalizeGroup(match.group)}::${players[0]}::${players[1]}`,
    group: normalizeGroup(match.group),
    playerIds: players,
    sets,
    winnerId,
    retiredPlayerId,
    sequence: {
      nr: normalizeNumber(match.nr),
      index: match.index
    },
    index: match.index
  };
}

function normalizeGroup(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function normalizeNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function extractPlayedSets(match) {
  return match.setPoints
    .map((set) => [Number(set.a), Number(set.b)])
    .filter(([left, right]) => left > 0 || right > 0);
}

function summarizeRounds(matches) {
  const rounds = [];
  const byGroup = new Map();

  matches.forEach((match) => {
    const group = normalizeGroup(match.group) || "Ergebnisse";
    if (!byGroup.has(group)) {
      byGroup.set(group, {
        group,
        matches: 0
      });
      rounds.push(byGroup.get(group));
    }

    byGroup.get(group).matches += 1;
  });

  return rounds;
}
